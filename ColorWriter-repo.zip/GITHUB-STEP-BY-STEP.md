# ColorWriter: step-by-step setup (for complete beginners)

You will do three things:
1. Put the app files on GitHub (your online storage).
2. Turn the files into a website, so the Huawei tablet can install it as an app.
3. Let GitHub build a real Windows 11 installer (.exe) for you.

You already have a GitHub account (Jeep01-01). Everything below can be done on the tablet.
Tip: if a GitHub page looks cramped, open the browser menu (⋮) and tick **Desktop site**.

---
## PART 1: Create the repository (the "folder" on GitHub)
1. Open **github.com/new** in your browser. Log in if asked.
2. **Repository name**: type `colorwriter`
3. Keep **Public** selected.
4. Turn **Add README** to **On**.
5. Tap **Create repository**.

## PART 2: Upload the app files
You need the file `ColorWriter-repo.zip` that I gave you. Extract it first:
Files app → long-press the zip → **Extract** → a folder opens with these files:
`index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, icon.ico, package.json, main.js, preload.js, GITHUB-STEP-BY-STEP.md`

1. In your repository tap **Add file** → **Upload files**.
2. Tap **choose your files** and select ALL 9 app files above (not the zip itself).
   If the picker only lets you pick one at a time, repeat the upload; you can do it in several rounds.
3. Wait until every file shows in the list.
4. Scroll down, tap the green **Commit changes** button.

## PART 3: Add the Windows-builder file (create it by typing)
The folder named `.github` is hidden on Android, so we create this file on the GitHub website:
1. In the repository tap **Add file** → **Create new file**.
2. In the name box type exactly: `.github/workflows/windows.yml`
   (when you type each `/`, GitHub turns the word before it into a folder).
3. In the big text box paste this text exactly:

```yaml
name: Build Windows installer

on:
  workflow_dispatch:
  push:
    branches: [main]

jobs:
  build:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm install
      - run: npx electron-builder --win nsis --publish never
      - uses: actions/upload-artifact@v4
        with:
          name: ColorWriter-Windows-Installer
          path: dist/*.exe
```
4. Tap **Commit changes…** → **Commit changes**.

## PART 4: Turn on the website (GitHub Pages)
1. Tap the **Settings** tab (top menu; it may be under "…").
2. Left menu → **Pages**.
3. **Source**: Deploy from a branch.  **Branch**: `main`, folder `/ (root)`. Tap **Save**.
4. Wait 1–2 minutes, refresh. Your link appears:
   `https://jeep01-01.github.io/colorwriter/`

## PART 5: Install on the Huawei tablet
1. Open the link above in **Huawei Browser** (or Chrome).
2. Wait until the page is fully loaded.
3. Open the browser menu → **Add to home screen / Add to Desktop** (or **Install app**).
4. Open the new ColorWriter icon once while online. After that it also works offline.

## PART 6: Windows 11, the easy way (no installer needed)
1. On the PC open **Microsoft Edge** and go to your link.
2. Click the **⋯** menu → **Apps** → **Install this site as an app**.
3. ColorWriter now appears in the Start menu and works offline. It can even open .docx files via "Open with".

## PART 7: Windows 11, a real installer (.exe)
1. In your repository tap the **Actions** tab.
2. If asked, tap **I understand my workflows, go ahead and enable them**.
3. Tap **Build Windows installer** (left list) → **Run workflow** → green **Run workflow**.
4. Wait about 3–6 minutes until the run shows a green ✓. (Red ✗ means an error: open it and send me a screenshot.)
5. Tap the finished run → scroll to **Artifacts** → tap **ColorWriter-Windows-Installer**. A zip downloads.
6. Extract the zip. Copy the `.exe` (named like `ColorWriter Setup 1.0.0.exe`) to the PC by USB, Google Drive, WhatsApp-to-self, etc.
7. On the PC double-click the .exe. If Windows shows a blue "Windows protected your PC" screen, tap **More info** → **Run anyway**
   (this appears because the installer is not paid-for "signed"; it is normal for free apps).
8. Choose the install folder, finish, and open ColorWriter from the Desktop or Start menu.

## PART 8: Updating the app later
Open the file in your repository → pencil icon ✏ (edit) → change → **Commit changes**,
or **Add file → Upload files** with the same file names (they replace the old ones).
Then, on the tablet, close the app fully and reopen. To rebuild the Windows installer repeat Part 7
(it also rebuilds by itself every time you commit).

## Troubleshooting
* Page says 404 → wait 5 minutes; check Settings → Pages shows a green "Your site is live".
* App looks old after an update → clear the site data in the browser settings, or change `colorwriter-v1` to `colorwriter-v2` inside `sw.js`.
* No "Install" option on the tablet → use Huawei Browser or Chrome, and open the https link (not a file).
* Actions tab missing a "Build Windows installer" item → Part 3 file name was typed wrong; it must be `.github/workflows/windows.yml`.
