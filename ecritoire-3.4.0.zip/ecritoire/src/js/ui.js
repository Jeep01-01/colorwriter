/* Écritoire — UI primitives: popovers, menus, modals, toasts, color palette. */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { esc } = Lb.util;
  const ui = {};
  Lb.menus = Object.create(null);

  /* ---------- element helper ---------- */
  ui.h = function h(tag, attrs, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) {
      if (c == null || c === false) continue;
      el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  };
  const h = ui.h;

  ui.icon = (name) => {
    const span = document.createElement('span');
    span.innerHTML = window.LbIcons[name] || '';
    return span.firstElementChild || span;
  };
  /** Icon wrapped in the rounded tile used by large toolbar buttons. */
  ui.tile = (name) => {
    const t = document.createElement('span');
    t.className = 'tile';
    t.append(ui.icon(name));
    return t;
  };
  ui.hydrateIcons = (root) => {
    for (const el of (root || document).querySelectorAll('[data-icon]')) {
      if (el.dataset.iconDone) continue;
      const svg = window.LbIcons[el.dataset.icon];
      if (svg) el.insertAdjacentHTML('afterbegin', el.classList.contains('big') ? `<span class="tile">${svg}</span>` : svg);
      el.dataset.iconDone = '1';
    }
  };

  /* ---------- popovers ---------- */
  let current = null;
  ui.closePopover = () => {
    if (!current) return;
    const c = current; current = null;
    c.el.remove();
    if (c.anchor) c.anchor.classList.remove('on-menu');
    document.removeEventListener('mousedown', c.outside, true);
    if (c.onClose) c.onClose();
  };
  ui.popover = (anchor, content, opts) => {
    const o = opts || {};
    const reopen = current && current.anchor === anchor;
    ui.closePopover();
    if (reopen && !o.force) return null;
    const el = h('div', { class: 'popover ' + (o.className || '') });
    el.append(content);
    document.getElementById('popoverRoot').append(el);
    const ar = anchor.getBoundingClientRect();
    const pr = el.getBoundingClientRect();
    let left = o.alignRight ? ar.right - pr.width : ar.left;
    let top = ar.bottom + 4;
    // menus of the docked left pane open to its right, level with the button
    if (anchor.closest && anchor.closest('.leftpane') && window.innerWidth > 820) {
      left = ar.right + 6;
      top = Math.min(ar.top, innerHeight - pr.height - 8);
    }
    if (left + pr.width > innerWidth - 8) left = innerWidth - pr.width - 8;
    if (top + pr.height > innerHeight - 8) top = Math.max(8, ar.top - pr.height - 4);
    el.style.left = Math.max(8, left) + 'px';
    el.style.top = top + 'px';
    const outside = (e) => { if (!el.contains(e.target) && !anchor.contains(e.target)) ui.closePopover(); };
    document.addEventListener('mousedown', outside, true);
    current = { el, anchor, outside, onClose: o.onClose };
    // keep editor selection when clicking inside menus (but allow inputs)
    el.addEventListener('mousedown', (e) => {
      if (!e.target.closest('input,select,textarea,label')) e.preventDefault();
    });
    return el;
  };
  ui.openMenu = (name, anchor) => {
    const build = Lb.menus[name];
    if (!build) return;
    Lb.sel.save();
    const content = build(anchor);
    if (content) ui.popover(anchor, content, { className: 'menu-' + name });
  };

  ui.menuItem = (label, onClick, opts) => {
    const o = opts || {};
    const b = h('button', { class: 'menu-item' + (o.checkable ? ' checkable' : '') + (o.checked ? ' checked' : ''), title: o.title || null, style: o.style || null });
    if (o.icon) b.append(ui.icon(o.icon));
    b.append(h('span', { style: o.labelStyle || null }, label));
    if (o.sub) b.append(h('span', { class: 'mi-sub' }, o.sub));
    b.addEventListener('click', () => { ui.closePopover(); onClick(); });
    return b;
  };
  ui.menuSep = () => h('div', { class: 'menu-sep' });
  ui.menuTitle = (t) => h('div', { class: 'menu-title' }, t);

  /* ---------- color palette ---------- */
  const BASE = ['#000000', '#ffffff', '#374151', '#f59e0b', '#b45309', '#dc2626', '#16a34a', '#2563eb', '#7c3aed', '#db2777'];
  const STD = ['#c00000', '#ff0000', '#ffc000', '#ffff00', '#92d050', '#00b050', '#00b0f0', '#0070c0', '#002060', '#7030a0'];
  const mix = (hex, target, t) => {
    const a = parseInt(hex.slice(1), 16), b = parseInt(target.slice(1), 16);
    const c = [16, 8, 0].map((s) => Math.round(((a >> s) & 255) * (1 - t) + ((b >> s) & 255) * t));
    return '#' + c.map((v) => v.toString(16).padStart(2, '0')).join('');
  };
  // colours picked lately, shared by every palette (kept on this device only)
  const RECENT_KEY = 'ecritoire.recentColors';
  let recent = [];
  try { recent = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]').filter((c) => /^#[0-9a-f]{6}$/i.test(c)).slice(0, 10); } catch (_) { recent = []; }
  ui.rememberColor = (c) => {
    if (!/^#[0-9a-f]{6}$/i.test(c || '')) return;
    c = c.toLowerCase();
    recent = [c, ...recent.filter((x) => x !== c)].slice(0, 10);
    try { localStorage.setItem(RECENT_KEY, JSON.stringify(recent)); } catch (_) { /* private mode */ }
  };
  ui.recentColors = () => recent.slice();

  /**
   * The system colour picker: the Windows colour dialog in the desktop app,
   * the Android or iOS picker in the phone apps. Resolves with '#rrggbb', or null when cancelled.
   */
  let sysInput = null;
  ui.systemColor = (current) => new Promise((resolve) => {
    if (!sysInput) {
      sysInput = h('input', { type: 'color', tabindex: '-1', 'aria-hidden': 'true', style: { position: 'fixed', left: '50%', top: '40%', width: '1px', height: '1px', opacity: '0', pointerEvents: 'none' } });
      document.body.append(sysInput);
    }
    const inp = sysInput;
    inp.value = /^#[0-9a-f]{6}$/i.test(current || '') ? current : '#f59e0b';
    let done = false;
    const finish = (v) => { if (done) return; done = true; inp.removeEventListener('change', onChange); resolve(v); };
    const onChange = () => finish(inp.value);
    inp.addEventListener('change', onChange);
    // some systems never report a cancel: drop the listener the next time the page gets focus
    window.addEventListener('focus', () => setTimeout(() => finish(null), 400), { once: true });
    inp.click();
  });
  /** Pick a colour anywhere on the screen (desktop browsers that support it). */
  ui.canEyedrop = () => typeof window.EyeDropper === 'function';
  ui.eyedrop = async () => {
    try { return (await new window.EyeDropper().open()).sRGBHex; } catch (_) { return null; }
  };

  ui.palette = (onPick, opts) => {
    const o = opts || {};
    const pick = (c) => { ui.closePopover(); if (c) ui.rememberColor(c); onPick(c); };
    const swatch = (c) => h('button', { style: { background: c }, title: c, class: o.current && c.toLowerCase() === String(o.current).toLowerCase() ? 'on' : null, onclick: () => pick(c) });
    const wrap = h('div', { class: 'palette-wrap' });
    if (o.autoLabel) wrap.append(ui.menuItem(o.autoLabel, () => onPick(null), { icon: o.autoIcon || 'reset' }));
    wrap.append(ui.menuTitle('Theme colors'));
    const grid = h('div', { class: 'palette' });
    const rows = [BASE];
    const blackRamp = ['#7f7f7f', '#595959', '#3f3f3f', '#262626', '#0d0d0d'];
    const whiteRamp = ['#f2f2f2', '#d9d9d9', '#bfbfbf', '#a6a6a6', '#7f7f7f'];
    [[0.8, '#ffffff'], [0.6, '#ffffff'], [0.4, '#ffffff'], [0.25, '#000000'], [0.5, '#000000']].forEach(([t, tg], r) => rows.push(BASE.map((c, i) => (i === 0 ? blackRamp[r] : i === 1 ? whiteRamp[r] : mix(c, tg, t)))));
    for (const row of rows) for (const c of row) grid.append(swatch(c));
    wrap.append(grid);
    wrap.append(ui.menuTitle('Standard colors'));
    const std = h('div', { class: 'palette' });
    for (const c of STD) std.append(swatch(c));
    wrap.append(std);
    if (recent.length) {
      wrap.append(ui.menuTitle('Recent colors'));
      const rc = h('div', { class: 'palette' });
      for (const c of recent) rc.append(swatch(c));
      wrap.append(rc);
    }
    wrap.append(ui.menuSep());
    // the system picker opens from the click itself (phones require that), then the menu closes
    const more = h('button', { class: 'menu-item' }, ui.icon('palette'), h('span', null, 'More Colors…'));
    more.addEventListener('click', () => {
      const p = ui.systemColor(o.current);
      ui.closePopover();
      p.then((c) => { if (c) { ui.rememberColor(c); onPick(c); } });
    });
    wrap.append(more);
    if (ui.canEyedrop()) {
      wrap.append(ui.menuItem('Pick from Screen', async () => {
        const c = await ui.eyedrop();
        if (c) { ui.rememberColor(c); onPick(c); }
      }, { icon: 'eyedropper' }));
    }
    if (o.extra) for (const item of o.extra) wrap.append(item);
    return wrap;
  };

  /* ---------- toasts ---------- */
  ui.toast = (msg, kind, ms) => {
    const t = h('div', { class: 'toast ' + (kind || '') }, msg);
    document.getElementById('toasts').append(t);
    setTimeout(() => { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 320); }, ms || (kind === 'error' ? 6000 : 3200));
  };

  /* ---------- modal ---------- */
  ui.modal = (opts) => new Promise((resolve) => {
    const o = opts || {};
    const root = document.getElementById('modalRoot');
    const body = h('div', { class: 'modal-body' });
    if (typeof o.body === 'string') body.innerHTML = o.body; else if (o.body) body.append(o.body);
    const footer = h('footer');
    const dlg = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', style: o.width ? { width: `min(${o.width}px, calc(100vw - 40px))` } : null },
      h('header', null, h('h2', null, o.title || 'Écritoire')), body, footer);
    const backdrop = h('div', { class: 'modal-backdrop' }, dlg);
    let done = false;
    const close = (value) => {
      if (done) return;
      if (value !== undefined && value !== 'cancel' && o.validate && o.validate(value, dlg) === false) return;
      done = true;
      backdrop.remove();
      document.removeEventListener('keydown', onKey, true);
      resolve({ value: value === undefined ? 'cancel' : value, root: dlg });
    };
    const buttons = o.buttons || [{ label: 'OK', value: 'ok', primary: true }];
    let primary = null;
    for (const b of buttons) {
      const btn = h('button', { class: 'btn' + (b.primary ? ' primary' : '') + (b.danger ? ' danger' : '') + (b.left ? ' left' : ''), type: 'button' }, b.label);
      btn.addEventListener('click', () => close(b.value));
      footer.append(btn);
      if (b.primary) primary = b;
    }
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close('cancel'); }
      else if (e.key === 'Enter' && primary && !e.shiftKey && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON') { e.preventDefault(); close(primary.value); }
    };
    document.addEventListener('keydown', onKey, true);
    backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop && o.dismissable !== false) close('cancel'); });
    root.append(backdrop);
    if (o.init) o.init(dlg);
    const first = dlg.querySelector('input,select,textarea') || dlg.querySelector('.btn.primary');
    if (first) setTimeout(() => { first.focus(); if (first.select) first.select(); }, 0);
  });

  ui.alert = (title, msg) => ui.modal({ title, body: `<p>${esc(msg)}</p>`, buttons: [{ label: 'OK', value: 'ok', primary: true }] });
  ui.confirm = async (title, msg, okLabel) => (await ui.modal({
    title, body: `<p>${esc(msg)}</p>`,
    buttons: [{ label: 'Cancel', value: 'cancel' }, { label: okLabel || 'OK', value: 'ok', primary: true }]
  })).value === 'ok';
  ui.confirmUnsaved = async (name) => (await ui.modal({
    title: 'Save changes?',
    body: `<p>Do you want to save the changes you made to <b style="color:var(--text)">${esc(name)}</b>?</p><p>Your changes will be lost if you don't save them.</p>`,
    buttons: [{ label: "Don't Save", value: 'discard', left: true, danger: true }, { label: 'Cancel', value: 'cancel' }, { label: 'Save', value: 'save', primary: true }]
  })).value;

  Lb.ui = ui;
})();
