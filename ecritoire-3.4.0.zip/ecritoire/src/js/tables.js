/* Écritoire — tables: insert, rows/columns, merge/split, shading, borders. */
(function () {
  'use strict';
  const Lb = window.Lb;
  const T = {};
  let activeCell = null;

  T.activeCell = () => {
    const el = Lb.sel.focusElement();
    if (!el || !Lb.els.editor.contains(el)) return null;
    const c = el.closest('td,th');
    return c && Lb.els.editor.contains(c) ? c : null;
  };
  T.activeTable = () => { const c = T.activeCell(); return c ? c.closest('table') : null; };

  function selectedCells() {
    const r = Lb.sel.range();
    const cell = T.activeCell();
    if (!cell) return [];
    if (!r || r.collapsed) return [cell];
    const table = cell.closest('table');
    const out = [...table.querySelectorAll('td,th')].filter((c) => r.intersectsNode(c) && c.closest('table') === table);
    return out.length ? out : [cell];
  }

  function newCell(tag) {
    const c = document.createElement(tag || 'td');
    c.innerHTML = '<br>';
    return c;
  }

  function placeIn(cell) {
    const r = document.createRange();
    r.selectNodeContents(cell);
    r.collapse(true);
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    Lb.sel.save();
  }

  /* ---------- insert ---------- */
  T.insert = (rows, cols) => {
    rows = Math.max(1, Math.min(200, rows | 0)); cols = Math.max(1, Math.min(40, cols | 0));
    const range = Lb.sel.restore();
    Lb.history.checkpoint();
    const ed = Lb.els.editor;
    const table = document.createElement('table');
    table.className = 'lb-table';
    const tb = document.createElement('tbody');
    for (let r = 0; r < rows; r++) {
      const tr = document.createElement('tr');
      for (let c = 0; c < cols; c++) tr.append(newCell());
      tb.append(tr);
    }
    table.append(tb);
    // place after the current top-level block (or replace it if empty)
    let top = range ? (range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement) : null;
    if (top === ed) top = ed.childNodes[range.startOffset] || ed.lastElementChild;
    while (top && top.parentElement !== ed) top = top.parentElement;
    const after = document.createElement('p');
    after.innerHTML = '<br>';
    if (top && /^(P|H\d|DIV)$/.test(top.tagName) && !top.textContent.replace(/​/g, '').trim() && !top.querySelector('img') && !top.classList.contains('lb-page-break')) {
      top.replaceWith(table);
      table.after(after);
    } else if (top) {
      top.after(table, after);
    } else ed.append(table, after);
    Lb.history.commit();
    Lb.layout.refresh();
    placeIn(table.rows[0].cells[0]);
    T.update();
  };

  /* ---------- geometry helpers (colspan aware) ---------- */
  const colIndex = (cell) => {
    let i = 0;
    for (let c = cell.parentElement.firstElementChild; c && c !== cell; c = c.nextElementSibling) i += c.colSpan || 1;
    return i;
  };
  const cellAt = (row, idx) => {
    let i = 0;
    for (const c of row.cells) { const span = c.colSpan || 1; if (idx >= i && idx < i + span) return c; i += span; }
    return null;
  };
  const dropColgroup = (table) => { const cg = table.querySelector('colgroup'); if (cg) cg.remove(); };

  function op(fn) {
    const cell = T.activeCell();
    if (!cell) { Lb.ui.toast('Place the cursor inside a table first.'); return; }
    Lb.history.checkpoint();
    const target = fn(cell, cell.closest('table'));
    Lb.history.commit();
    Lb.layout.refresh();
    if (target && target.isConnected) placeIn(target);
    T.update();
  }

  T.insertRow = (below) => op((cell) => {
    const row = cell.parentElement;
    const tr = document.createElement('tr');
    let n = 0;
    for (const c of row.cells) n += c.colSpan || 1;
    for (let i = 0; i < n; i++) tr.append(newCell(row.cells[0].tagName.toLowerCase() === 'th' && !below ? 'th' : 'td'));
    if (below) row.after(tr); else row.before(tr);
    return tr.cells[Math.min(colIndex(cell), tr.cells.length - 1)];
  });

  T.insertCol = (right) => op((cell, table) => {
    const idx = colIndex(cell) + (right ? (cell.colSpan || 1) - 1 : 0);
    let target = null;
    for (const row of table.rows) {
      const ref = cellAt(row, idx);
      const nc = newCell(ref ? ref.tagName.toLowerCase() : 'td');
      if (!ref) row.append(nc);
      else if (right) ref.after(nc); else ref.before(nc);
      if (row === cell.parentElement) target = nc;
    }
    dropColgroup(table);
    return target;
  });

  T.deleteRow = () => op((cell, table) => {
    const row = cell.parentElement;
    const next = row.nextElementSibling || row.previousElementSibling;
    row.remove();
    if (!table.rows.length) return removeTable(table);
    return next ? next.cells[0] : null;
  });

  T.deleteCol = () => op((cell, table) => {
    const idx = colIndex(cell);
    for (const row of [...table.rows]) {
      const c = cellAt(row, idx);
      if (!c) continue;
      if ((c.colSpan || 1) > 1) c.colSpan -= 1; else c.remove();
      if (!row.cells.length) row.remove();
    }
    dropColgroup(table);
    if (!table.rows.length) return removeTable(table);
    const row = table.rows[Math.min(cell.parentElement.rowIndex >= 0 ? cell.parentElement.rowIndex : 0, table.rows.length - 1)];
    return row ? row.cells[Math.min(idx, row.cells.length - 1)] : null;
  });

  function removeTable(table) {
    const p = document.createElement('p');
    p.innerHTML = '<br>';
    table.replaceWith(p);
    const r = document.createRange(); r.setStart(p, 0); r.collapse(true);
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    return null;
  }
  T.deleteTable = () => op((cell, table) => removeTable(table));

  T.mergeRight = () => op((cell) => {
    const next = cell.nextElementSibling;
    if (!next) { Lb.ui.toast('There is no cell to the right to merge.'); return cell; }
    const hasText = (c) => c.textContent.replace(/​/g, '').trim() || c.querySelector('img');
    if (hasText(next)) {
      if (!hasText(cell)) cell.innerHTML = '';
      else cell.append(document.createElement('br'));
      while (next.firstChild) cell.append(next.firstChild);
    }
    cell.colSpan = (cell.colSpan || 1) + (next.colSpan || 1);
    next.remove();
    return cell;
  });

  T.split = () => op((cell) => {
    if ((cell.colSpan || 1) < 2) { Lb.ui.toast('Only merged cells can be split.'); return cell; }
    cell.colSpan -= 1;
    cell.after(newCell(cell.tagName.toLowerCase()));
    return cell;
  });

  T.shade = (color) => {
    const cells = selectedCells();
    if (!cells.length) return;
    Lb.history.checkpoint();
    for (const c of cells) { c.style.backgroundColor = color || ''; if (!c.getAttribute('style')) c.removeAttribute('style'); }
    Lb.history.commit();
  };
  T.borderColor = (color) => {
    const table = T.activeTable();
    if (!table) return;
    Lb.history.checkpoint();
    for (const c of table.querySelectorAll('td,th')) c.style.borderColor = color || '';
    Lb.history.commit();
  };

  /* ---------- keyboard: Tab moves between cells ---------- */
  T.onTab = (e) => {
    const cell = T.activeCell();
    if (!cell) return false;
    e.preventDefault();
    const cells = [...cell.closest('table').querySelectorAll('td,th')].filter((c) => c.closest('table') === cell.closest('table'));
    const i = cells.indexOf(cell);
    if (e.shiftKey) { if (i > 0) placeIn(cells[i - 1]); return true; }
    if (i < cells.length - 1) { placeIn(cells[i + 1]); return true; }
    T.insertRow(true);
    return true;
  };

  /* ---------- active cell highlight + contextual tab ---------- */
  T.update = () => {
    const cell = T.activeCell();
    if (cell !== activeCell) {
      if (activeCell) activeCell.classList.remove('lb-cell-active');
      activeCell = cell;
      if (cell) cell.classList.add('lb-cell-active');
    }
    const tab = document.getElementById('formatTab');
    if (Lb.objects.selected()) return;
    if (cell) {
      tab.hidden = false;
      tab.textContent = 'Table Layout';
      Lb.setFormatPanel('table');
    } else {
      if (!tab.hidden && tab.textContent === 'Table Layout') {
        tab.hidden = true;
        if (tab.classList.contains('active')) Lb.switchTab('home');
      }
    }
  };

  /* ---------- menus ---------- */
  Lb.menus.tableMenu = () => {
    const h = Lb.ui.h;
    const wrap = h('div', { class: 'table-grid' });
    const label = h('div', { class: 'tg-label' }, 'Insert Table');
    const grid = h('div', { class: 'tg' });
    const COLS = 10, ROWS = 8;
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      const i = h('i', { dataset: { r: r + 1, c: c + 1 } });
      grid.append(i);
    }
    grid.addEventListener('mouseover', (e) => {
      const t = e.target.closest('i');
      if (!t) return;
      const R = +t.dataset.r, Cc = +t.dataset.c;
      for (const i of grid.children) i.classList.toggle('on', +i.dataset.r <= R && +i.dataset.c <= Cc);
      label.textContent = `${Cc} × ${R} Table`;
    });
    grid.addEventListener('click', (e) => {
      const t = e.target.closest('i');
      if (!t) return;
      Lb.ui.closePopover();
      T.insert(+t.dataset.r, +t.dataset.c);
    });
    wrap.append(label, grid, Lb.ui.menuSep(), Lb.ui.menuItem('Insert Table…', () => T.dialog(), { icon: 'table' }));
    return wrap;
  };
  Lb.menus.shadeMenu = () => Lb.ui.palette((c) => T.shade(c), { autoLabel: 'No Color', autoIcon: 'close' });
  Lb.menus.borderMenu = () => Lb.ui.palette((c) => T.borderColor(c), { autoLabel: 'Automatic (black)' });

  T.dialog = async () => {
    Lb.sel.save();
    const res = await Lb.ui.modal({
      title: 'Insert Table', width: 380,
      body: `<div class="mrow"><label>Columns</label><input type="number" id="tdCols" min="1" max="40" value="3"></div>
             <div class="mrow"><label>Rows</label><input type="number" id="tdRows" min="1" max="200" value="3"></div>`,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Insert', value: 'ok', primary: true }]
    });
    if (res.value !== 'ok') return;
    T.insert(+res.root.querySelector('#tdRows').value, +res.root.querySelector('#tdCols').value);
  };

  T.buildPanel = () => {
    const h = Lb.ui.h;
    const big = (cmd, icon, label, title) => {
      const b = h('button', { class: 'rb big', title: title || label, 'data-cmd': cmd });
      b.append(Lb.ui.tile(icon), h('span', null, label));
      return b;
    };
    const small = (cmd, icon, label) => {
      const b = h('button', { class: 'rb', title: label, 'data-cmd': cmd, style: { justifyContent: 'flex-start', width: '128px', gap: '8px' } });
      b.append(Lb.ui.icon(icon), h('span', null, label));
      return b;
    };
    const group = (label, ...kids) => h('div', { class: 'group' }, h('div', { class: 'group-body' }, ...kids), h('div', { class: 'group-label' }, label));
    const frag = document.createDocumentFragment();
    frag.append(
      group('Rows & Columns',
        big('tableRowAbove', 'rowAbove', 'Insert Above'), big('tableRowBelow', 'rowBelow', 'Insert Below'),
        big('tableColLeft', 'colLeft', 'Insert Left'), big('tableColRight', 'colRight', 'Insert Right')),
      group('Delete',
        h('div', { class: 'stack' }, small('tableDelRow', 'delRow', 'Delete Row'), small('tableDelCol', 'delCol', 'Delete Column'), small('tableDelete', 'trash', 'Delete Table'))),
      group('Merge', big('tableMerge', 'merge', 'Merge Right'), big('tableSplit', 'split', 'Split Cell')),
      group('Style', (() => { const b = big('', 'fill', 'Shading'); b.removeAttribute('data-cmd'); b.dataset.menu = 'shadeMenu'; b.classList.add('has-menu'); return b; })(),
        (() => { const b = big('', 'table', 'Border Color'); b.removeAttribute('data-cmd'); b.dataset.menu = 'borderMenu'; b.classList.add('has-menu'); return b; })())
    );
    return frag;
  };

  T.init = () => {
    document.addEventListener('selectionchange', () => T.update());
  };

  Lb.tables = T;
})();
