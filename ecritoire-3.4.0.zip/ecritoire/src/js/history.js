/* Écritoire — undo / redo.
 * Snapshot based: every change stores the editor HTML plus the caret position
 * (as text offsets). Large embedded images are interned so that snapshots stay
 * small in memory.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const MAX = 150;
  let stack = [];
  let index = -1;
  let restoring = false;

  // ----- image interning -----
  const blobs = new Map(); // key -> data url
  const keys = new Map();  // data url -> key
  let seq = 0;
  const intern = (html) => html.replace(/(src|poster)="(data:[^"]{1500,})"/g, (m, a, d) => {
    let k = keys.get(d);
    if (!k) { k = 'lbimg:' + (++seq); keys.set(d, k); blobs.set(k, d); }
    return `${a}="${k}"`;
  });
  const extern = (html) => html.replace(/(src|poster)="(lbimg:\d+)"/g, (m, a, k) => `${a}="${blobs.get(k) || ''}"`);

  // ----- caret as text offsets -----
  function textOffset(container, offset) {
    const ed = Lb.els.editor;
    const r = document.createRange();
    r.selectNodeContents(ed);
    try { r.setEnd(container, offset); } catch (_) { return 0; }
    return r.toString().length;
  }
  function pointAt(pos) {
    const ed = Lb.els.editor;
    const walker = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
    let n; let acc = 0; let last = null;
    while ((n = walker.nextNode())) {
      const len = n.nodeValue.length;
      if (acc + len >= pos) return { node: n, offset: pos - acc };
      acc += len; last = n;
    }
    return last ? { node: last, offset: last.nodeValue.length } : { node: ed, offset: ed.childNodes.length };
  }
  function caret() {
    const r = Lb.sel.range();
    if (!r || !Lb.sel.inEditor(r)) return null;
    return { s: textOffset(r.startContainer, r.startOffset), e: textOffset(r.endContainer, r.endOffset) };
  }
  function setCaret(c) {
    if (!c) return;
    try {
      const a = pointAt(c.s); const b = pointAt(c.e);
      const r = document.createRange();
      r.setStart(a.node, a.offset); r.setEnd(b.node, b.offset);
      const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    } catch (_) { /* ignore */ }
  }

  function currentHtml() {
    return intern(Lb.layout ? Lb.layout.cleanEditorHtml() : Lb.els.editor.innerHTML);
  }

  function push() {
    if (restoring) return false;
    const html = currentHtml();
    if (index >= 0 && stack[index].html === html) { stack[index].caret = caret(); return false; }
    stack = stack.slice(0, index + 1);
    stack.push({ html, caret: caret() });
    if (stack.length > MAX) stack.shift();
    index = stack.length - 1;
    return true;
  }

  const pending = Lb.util.debounce(() => { if (push()) Lb.emit('changed'); }, 450);

  function restore(entry) {
    restoring = true;
    Lb.els.editor.innerHTML = extern(entry.html);
    Lb.els.editor.focus({ preventScroll: true });
    setCaret(entry.caret);
    restoring = false;
    Lb.emit('restored');
    Lb.emit('changed');
  }

  Lb.history = {
    reset() { stack = []; index = -1; blobs.clear(); keys.clear(); push(); },
    /** called on every input event (debounced) */
    typed() { pending(); },
    /** call before a programmatic change so typing is recorded separately */
    checkpoint() { pending.cancel(); push(); },
    /** call after a programmatic change */
    commit() { pending.cancel(); if (push()) Lb.emit('changed'); },
    undo() {
      pending.cancel();
      push();
      if (index <= 0) return;
      index--;
      restore(stack[index]);
    },
    redo() {
      pending.cancel();
      if (index >= stack.length - 1) return;
      index++;
      restore(stack[index]);
    },
    get canUndo() { return index > 0; },
    get canRedo() { return index < stack.length - 1; },
    get restoring() { return restoring; }
  };
})();
