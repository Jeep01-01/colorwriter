/* Écritoire — page layout: zoom, page-break preview, page guides, rulers. */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { clamp, round } = Lb.util;
  const L = {};
  let pageCount = 1;
  let pageHeightPx = 0;
  let notePages = [];   // notePages[k] = footnote markers shown at the bottom of page k
  let noteReserve = []; // noteReserve[k] = px kept free for them at the bottom of page k

  const els = () => Lb.els;
  const z = () => Lb.state.zoom;
  const mg = () => Lb.settings.margins;

  /* ------------------------------------------------------------ */
  /* Clean HTML (layout artefacts removed)                         */
  /* ------------------------------------------------------------ */
  function stripArtefacts(root) {
    for (const el of root.querySelectorAll('[data-lb-push]')) {
      const v = el.getAttribute('data-lb-push');
      el.style.marginTop = v;
      el.removeAttribute('data-lb-push');
      if (!el.getAttribute('style')) el.removeAttribute('style');
    }
    for (const el of root.querySelectorAll('.lb-page-break')) {
      el.removeAttribute('style');
      el.setAttribute('contenteditable', 'false');
    }
    for (const el of root.querySelectorAll('.lb-selected')) el.classList.remove('lb-selected');
    for (const el of root.querySelectorAll('.lb-cell-active')) el.classList.remove('lb-cell-active');
    for (const el of root.querySelectorAll('[class=""]')) el.removeAttribute('class');
  }
  L.cleanEditorHtml = () => {
    const clone = els().editor.cloneNode(true);
    stripArtefacts(clone);
    return clone.innerHTML;
  };

  function clearPushes() {
    const ed = els().editor;
    for (const el of ed.querySelectorAll('[data-lb-push]')) {
      el.style.marginTop = el.getAttribute('data-lb-push');
      el.removeAttribute('data-lb-push');
      if (!el.getAttribute('style')) el.removeAttribute('style');
    }
    for (const el of ed.querySelectorAll('.lb-page-break[style]')) el.removeAttribute('style');
  }

  /* ------------------------------------------------------------ */
  /* Pagination (page-break preview)                               */
  /* ------------------------------------------------------------ */
  function topOf(el, edTop) {
    return (el.getBoundingClientRect().top - edTop) / z();
  }

  /* ---------- footnotes ---------- */
  const NOTE_SEP = 14; // the short rule above the notes, with its spacing
  let measurer = null;
  const noteCache = new Map();
  /** Height a footnote takes at the bottom of the page (same style as the notes area). */
  function noteHeight(fn) {
    const text = fn.dataset.note || '';
    const width = Lb.pageW() - Lb.mm(mg().left) - Lb.mm(mg().right);
    const key = Math.round(width) + '|' + fn.textContent + '|' + text;
    if (noteCache.has(key)) return noteCache.get(key);
    if (!measurer) {
      measurer = document.createElement('div');
      measurer.className = 'lb-content lb-notes';
      measurer.setAttribute('aria-hidden', 'true');
      measurer.style.cssText = 'position:absolute;left:-10000px;top:0;visibility:hidden;';
      els().page.append(measurer);
    }
    measurer.style.width = width + 'px';
    measurer.innerHTML = '';
    const d = document.createElement('div');
    d.className = 'lb-note';
    d.innerHTML = '<sup></sup><span></span>';
    d.firstChild.textContent = fn.textContent;
    d.lastChild.textContent = text;
    measurer.append(d);
    const h = d.getBoundingClientRect().height / z() + 2;
    if (noteCache.size > 400) noteCache.clear();
    noteCache.set(key, h);
    return h;
  }
  /** Number the footnote markers 1, 2, 3… in document order. */
  function numberNotes(ed) {
    let i = 0;
    for (const fn of ed.querySelectorAll('.lb-fn')) {
      const t = String(++i);
      if (fn.textContent !== t) fn.textContent = t;
      if (fn.title !== fn.dataset.note) fn.title = fn.dataset.note || '';
      if (fn.getAttribute('contenteditable') !== 'false') fn.setAttribute('contenteditable', 'false');
    }
    return i;
  }
  const notesIn = (el) => (el.nodeType !== 1 ? [] : el.classList.contains('lb-fn') ? [el] : [...el.querySelectorAll('.lb-fn')]);

  /** A paragraph's height including pictures or shapes floated in it (square, tight) that hang below it. */
  const FLOATS = 'img[data-wrap="square"], img[data-wrap="tight"]';
  function heightWithFloats(el) {
    let h = el.offsetHeight;
    if (el.nodeType !== 1 || !el.querySelector(FLOATS)) return h;
    const top = el.getBoundingClientRect().top;
    for (const f of el.querySelectorAll(FLOATS)) h = Math.max(h, (f.getBoundingClientRect().bottom - top) / z() + (parseFloat(getComputedStyle(f).marginBottom) || 0));
    return h;
  }

  function paginate() {
    const { editor: ed } = els();
    clearPushes();
    const ph = Lb.pageH();
    const mt = Lb.mm(mg().top), mb = Lb.mm(mg().bottom);
    const ch = ph - mt - mb;
    ed.style.minHeight = Math.max(40, ch) + 'px';
    const noteCount = numberNotes(ed);
    notePages = [];
    noteReserve = [];
    const notesHeight = (notes) => notes.reduce((a, f) => a + noteHeight(f), 0);
    const needFor = (p, notes) => (notes.length ? notesHeight(notes) + (noteReserve[p] ? 0 : NOTE_SEP) : 0);
    const keepNotes = (p, notes) => {
      if (!notes.length) return;
      noteReserve[p] = (noteReserve[p] || NOTE_SEP) + notesHeight(notes);
      (notePages[p] = notePages[p] || []).push(...notes);
    };

    if (Lb.state.preview) {
      const list = [];
      for (const c of ed.children) {
        if ((c.tagName === 'UL' || c.tagName === 'OL') && c.offsetHeight > ch) list.push(...c.children);
        else list.push(c);
      }
      let edTop = ed.getBoundingClientRect().top;
      for (let li = 0; li < list.length; li++) {
        const el = list[li];
        if (el.classList && el.classList.contains('lb-page-break')) {
          const top = mt + topOf(el, edTop);
          const p = Math.floor((top + 0.5) / ph);
          const target = (p + 1) * ph + mt;
          el.style.marginTop = '0px';
          el.style.marginBottom = '0px';
          el.style.height = Math.max(0, target - top) + 'px';
          // the browser may scroll to keep the caret in view (scroll anchoring): measure from where the editor is now
          edTop = ed.getBoundingClientRect().top;
          continue;
        }
        const h = heightWithFloats(el);
        const notes = noteCount ? notesIn(el) : [];
        if (!h || h > ch) {
          if (notes.length) keepNotes(Math.max(0, Math.floor((mt + topOf(el, edTop)) / ph)), notes);
          continue;
        }
        const top = mt + topOf(el, edTop);
        const p = Math.floor(top / ph);
        const contentTop = p * ph + mt;
        // footnotes on this page take space from the bottom of the text area
        const contentBottom = p * ph + ph - mb - (noteReserve[p] || 0) - needFor(p, notes);
        let target = null;
        if (top < contentTop - 0.5) target = contentTop;
        else if (top + h > contentBottom + 0.5) target = (p + 1) * ph + mt;
        else if (top > contentTop + 0.5) {
          // keep a heading (or a short caption above a table) with the start of what follows
          const next = list[li + 1];
          const keep = next && next.offsetHeight && !next.classList.contains('lb-page-break') &&
            (/^H[1-6]$/.test(el.tagName) || (next.tagName === 'TABLE' && el.tagName === 'P' && h < 30));
          if (keep) {
            // the next block moves as a whole when it doesn't fit, so measure all of it
            const need = (next.getBoundingClientRect().bottom - el.getBoundingClientRect().bottom) / z();
            if (top + h + need > contentBottom + 0.5 && h + need <= ch) target = (p + 1) * ph + mt;
          }
        }
        keepNotes(target == null ? p : Math.floor(target / ph), notes);
        if (target == null) continue;
        if (!el.hasAttribute('data-lb-push')) el.setAttribute('data-lb-push', el.style.marginTop || '');
        const cur = parseFloat(getComputedStyle(el).marginTop) || 0;
        el.style.marginTop = (cur + (target - top)) + 'px';
        // margins may collapse with the previous sibling: correct until it lands
        for (let i = 0; i < 3; i++) {
          const now = mt + topOf(el, edTop);
          const diff = target - now;
          if (Math.abs(diff) < 0.5) break;
          el.style.marginTop = (parseFloat(el.style.marginTop) + diff) + 'px';
        }
        edTop = ed.getBoundingClientRect().top;
      }
    }
    const natural = mt + ed.offsetHeight + mb;
    if (Lb.state.preview) {
      pageCount = Math.max(1, Math.ceil(natural / ph - 0.002));
      pageHeightPx = pageCount * ph;
    } else {
      pageCount = Math.max(1, Math.ceil(natural / ph - 0.002));
      pageHeightPx = Math.max(ph, natural);
    }
  }

  function drawGuides() {
    const g = els().guides;
    if (!Lb.state.preview) { g.innerHTML = ''; return; }
    const ph = Lb.pageH();
    const m = mg();
    const t = Lb.mm(m.top), b = Lb.mm(m.bottom), l = Lb.mm(m.left), r = Lb.mm(m.right);
    const W = Lb.pageW();
    let html = '';
    for (let k = 0; k < pageCount; k++) {
      const y0 = k * ph;
      if (k > 0) html += `<div class="pg-gap" style="top:${y0 - 9}px"><span>PAGE ${k + 1}</span></div>`;
      html += `<div class="pg-corner tl" style="left:${l - 14}px;top:${y0 + t - 14}px"></div>` +
        `<div class="pg-corner tr" style="left:${W - r}px;top:${y0 + t - 14}px"></div>` +
        `<div class="pg-corner bl" style="left:${l - 14}px;top:${y0 + ph - b}px"></div>` +
        `<div class="pg-corner br" style="left:${W - r}px;top:${y0 + ph - b}px"></div>` +
        (Lb.docparts && Lb.docparts.hasFooter(k) ? '' : `<div class="pg-num" style="top:${y0 + ph - b / 2 - 6}px">${k + 1} / ${pageCount}</div>`);
    }
    g.innerHTML = html;
  }

  function sizeWrap() {
    const { page, pageWrap } = els();
    page.style.height = pageHeightPx + 'px';
    page.style.transform = `scale(${z()})`;
    pageWrap.style.width = Lb.pageW() * z() + 'px';
    pageWrap.style.height = pageHeightPx * z() + 'px';
  }

  L.applyMargins = () => {
    const m = mg();
    const page = els().page;
    page.style.padding = `${m.top}mm ${m.right}mm ${m.bottom}mm ${m.left}mm`;
    // paper size and orientation
    page.style.width = Lb.PAGE_W_MM + 'mm';
    page.style.minHeight = Lb.PAGE_H_MM + 'mm';
    let st = document.getElementById('lbPageStyle');
    if (!st) { st = document.createElement('style'); st.id = 'lbPageStyle'; document.head.append(st); }
    st.textContent = `@media print { @page { size: ${Lb.PAGE_W_MM}mm ${Lb.PAGE_H_MM}mm; margin: 0; } }`;
    const label = document.getElementById('pageSizeLabel');
    if (label) label.textContent = 'Page Setup · ' + Lb.paperLabel();
  };

  /* ------------------------------------------------------------ */
  /* Refresh scheduling                                            */
  /* ------------------------------------------------------------ */
  let raf = 0;
  // functions run after pagination that may change the document (the table of
  // contents fills in page numbers); they return true when they changed it
  L.after = [];
  L.refresh = () => {
    cancelAnimationFrame(raf); raf = 0;
    // measure at the current zoom: the sheet must already have its new scale
    els().page.style.transform = `scale(${z()})`;
    paginate();
    for (let pass = 0; pass < 3; pass++) {
      let changed = false;
      for (const fn of L.after) { try { if (fn()) changed = true; } catch (e) { console.error(e); } }
      if (!changed) break;
      paginate();
    }
    drawGuides();
    sizeWrap();
    L.drawRulers();
    Lb.emit('layout');
  };
  const debounced = Lb.util.debounce(() => { raf = requestAnimationFrame(L.refresh); }, 110);
  L.schedule = () => debounced();

  L.withoutPushes = async (fn) => {
    clearPushes();
    try { return await fn(); } finally { L.refresh(); }
  };

  L.pageCount = () => pageCount;
  L.notePages = () => notePages;
  L.noteReserve = () => noteReserve;
  L.currentPage = () => {
    const { scroller, pageWrap } = els();
    const ph = Lb.pageH() * z();
    const y = scroller.scrollTop + scroller.clientHeight / 3 - pageWrap.offsetTop;
    return clamp(Math.floor(y / ph) + 1, 1, pageCount);
  };
  L.caretPage = () => {
    const r = Lb.sel.range();
    if (!r || !Lb.sel.inEditor(r)) return null;
    const rects = r.getClientRects();
    const rect = rects.length ? rects[0] : (Lb.closestBlock(r.startContainer) || els().editor).getBoundingClientRect();
    const pr = els().page.getBoundingClientRect();
    return clamp(Math.floor((rect.top - pr.top) / (Lb.pageH() * z())) + 1, 1, pageCount);
  };

  /* ------------------------------------------------------------ */
  /* Zoom                                                          */
  /* ------------------------------------------------------------ */
  L.setZoom = (value) => {
    const { scroller } = els();
    const nz = round(clamp(value, 0.25, 4), 2);
    const ratio = (scroller.scrollTop + scroller.clientHeight / 2) / Math.max(1, scroller.scrollHeight);
    Lb.state.zoom = nz;
    L.refresh();
    scroller.scrollTop = ratio * scroller.scrollHeight - scroller.clientHeight / 2;
    Lb.emit('zoom', nz);
  };
  const STEPS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4];
  L.zoomIn = () => L.setZoom(STEPS.find((s) => s > z() + 0.001) || 4);
  L.zoomOut = () => L.setZoom([...STEPS].reverse().find((s) => s < z() - 0.001) || 0.25);
  L.fitWidth = () => L.setZoom((els().scroller.clientWidth - 56) / Lb.pageW());
  L.fitPage = () => {
    const s = els().scroller;
    L.setZoom(Math.min((s.clientWidth - 56) / Lb.pageW(), (s.clientHeight - 60) / Lb.pageH()));
  };

  L.setPreview = (on) => {
    Lb.state.preview = !!on;
    document.body.classList.toggle('preview-on', Lb.state.preview);
    L.refresh();
    Lb.emit('state');
  };
  L.setRuler = (on) => {
    Lb.state.ruler = !!on;
    els().workspace.classList.toggle('no-ruler', !Lb.state.ruler);
    L.refresh();
    Lb.emit('state');
  };

  /* ------------------------------------------------------------ */
  /* Rulers                                                        */
  /* ------------------------------------------------------------ */
  const C = {
    bg: '#1b1b1e', margin: '#2c2c31', content: '#ebe9e4', tickIn: '#55555c', tickOut: '#8c8c95',
    textIn: '#3f3f45', textOut: '#9d9da6', amber: '#f59e0b', amberDark: '#b45309', line: '#2b2b30'
  };
  let hMarks = [];
  let vMarks = [];
  let rulerRaf = 0;

  function prep(canvas) {
    const dpr = window.devicePixelRatio || 1;
    const W = canvas.clientWidth, H = canvas.clientHeight;
    if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) {
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H);
    return { ctx, W, H };
  }

  function tickStep(s) { return s * 2.5 >= 7 ? 2.5 : s * 5 >= 7 ? 5 : 10; }

  function currentIndents() {
    const blk = Lb.selectedBlocks()[0];
    if (!blk) return null;
    const pr = els().page.getBoundingClientRect();
    const zz = z();
    const contentL = pr.left + Lb.mm(mg().left) * zz;
    const contentR = pr.left + (Lb.pageW() - Lb.mm(mg().right)) * zz;
    const br = blk.getBoundingClientRect();
    const cs = getComputedStyle(blk);
    // the block box of table-cell content: measure inside the cell
    const cell = blk.closest('td,th');
    let left = (br.left - contentL) / zz;
    let right = (contentR - br.right) / zz;
    if (cell) {
      const cr = cell.getBoundingClientRect();
      left = (br.left - cr.left) / zz + (cr.left - contentL) / zz;
      right = (contentR - br.right) / zz;
    }
    return { left, right, first: parseFloat(cs.textIndent) || 0, block: blk };
  }

  function drawH() {
    const canvas = els().rulerH;
    if (!canvas || !Lb.state.ruler) return;
    const { ctx, W, H } = prep(canvas);
    const pr = els().page.getBoundingClientRect();
    const cr = canvas.getBoundingClientRect();
    const s = Lb.MM * z();
    const x0 = pr.left - cr.left;
    const m = mg();
    const pw = Lb.PAGE_W_MM * s;
    const cl = x0 + m.left * s, crr = x0 + pw - m.right * s;
    ctx.fillStyle = C.margin; ctx.fillRect(x0, 3, pw, H - 6);
    ctx.fillStyle = C.content; ctx.fillRect(cl, 3, crr - cl, H - 6);
    const step = tickStep(s);
    ctx.font = '9px Inter, Segoe UI, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const startMm = -Math.floor(m.left / step + 1e-9) * step;
    for (let mmv = startMm; mmv <= Lb.PAGE_W_MM - m.left + 0.001; mmv += step) {
      const x = cl + mmv * s;
      if (x < -20 || x > W + 20) continue;
      const inside = x >= cl - 0.5 && x <= crr + 0.5;
      const isCm = Math.abs(mmv % 10) < 0.001;
      const isHalf = Math.abs(mmv % 5) < 0.001;
      ctx.fillStyle = inside ? C.tickIn : C.tickOut;
      if (isCm && mmv !== 0) {
        if (s * 10 >= 14 || Math.abs(mmv % 20) < 0.001) {
          ctx.fillStyle = inside ? C.textIn : C.textOut;
          ctx.fillText(String(Math.abs(mmv / 10)), x, H / 2 + 0.5);
        } else ctx.fillRect(Math.round(x), H / 2 - 3, 1, 6);
      } else if (isHalf) ctx.fillRect(Math.round(x), H / 2 - 3, 1, 6);
      else ctx.fillRect(Math.round(x), H / 2 - 1, 1, 2);
    }
    hMarks = [
      { type: 'marginL', x: cl },
      { type: 'marginR', x: crr }
    ];
    // indent markers for the current paragraph
    const ind = currentIndents();
    if (ind) {
      const zz = z();
      const leftX = cl + ind.left * zz;
      const firstX = leftX + ind.first * zz;
      const rightX = crr - ind.right * zz;
      ctx.fillStyle = C.amber; ctx.strokeStyle = '#111'; ctx.lineWidth = 1;
      // first line: down triangle at top
      tri(ctx, firstX, 2, 5, 6, true);
      // left indent: up triangle + base
      tri(ctx, leftX, H - 8, 5, 6, false);
      ctx.fillRect(leftX - 5, H - 3, 10, 3);
      // right indent
      tri(ctx, rightX, H - 8, 5, 6, false);
      hMarks.push({ type: 'indFirst', x: firstX, y: 0, y2: H / 2 }, { type: 'indLeft', x: leftX, y: H / 2, y2: H },
        { type: 'indRight', x: rightX, y: H / 2, y2: H });
      hMarks.ind = ind;
    }
  }

  function tri(ctx, x, y, hw, h, down) {
    ctx.beginPath();
    if (down) { ctx.moveTo(x - hw, y); ctx.lineTo(x + hw, y); ctx.lineTo(x, y + h); }
    else { ctx.moveTo(x - hw, y + h); ctx.lineTo(x + hw, y + h); ctx.lineTo(x, y); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
  }

  function drawV() {
    const canvas = els().rulerV;
    if (!canvas || !Lb.state.ruler) return;
    const { ctx, W, H } = prep(canvas);
    const pr = els().page.getBoundingClientRect();
    const cr = canvas.getBoundingClientRect();
    const s = Lb.MM * z();
    const m = mg();
    const ph = Lb.PAGE_H_MM * s;
    const step = tickStep(s);
    ctx.font = '9px Inter, Segoe UI, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    vMarks = [];
    const pages = Lb.state.preview ? pageCount : 1;
    for (let k = 0; k < pages; k++) {
      const y0 = pr.top - cr.top + k * ph;
      if (y0 > H || y0 + ph < 0) continue;
      const ct = y0 + m.top * s, cb = y0 + ph - m.bottom * s;
      ctx.fillStyle = C.margin; ctx.fillRect(3, y0, W - 6, ph);
      ctx.fillStyle = C.content; ctx.fillRect(3, ct, W - 6, cb - ct);
      if (k > 0) { ctx.fillStyle = C.bg; ctx.fillRect(0, y0 - 1, W, 2); }
      const startMm = -Math.floor(m.top / step + 1e-9) * step;
      for (let mmv = startMm; mmv <= Lb.PAGE_H_MM - m.top + 0.001; mmv += step) {
        const y = ct + mmv * s;
        if (y < -10 || y > H + 10) continue;
        const inside = y >= ct - 0.5 && y <= cb + 0.5;
        const isCm = Math.abs(mmv % 10) < 0.001;
        const isHalf = Math.abs(mmv % 5) < 0.001;
        ctx.fillStyle = inside ? C.tickIn : C.tickOut;
        if (isCm && mmv !== 0) {
          if (s * 10 >= 14 || Math.abs(mmv % 20) < 0.001) {
            ctx.fillStyle = inside ? C.textIn : C.textOut;
            ctx.fillText(String(Math.abs(mmv / 10)), W / 2, y + 0.5);
          } else ctx.fillRect(W / 2 - 3, Math.round(y), 6, 1);
        } else if (isHalf) ctx.fillRect(W / 2 - 3, Math.round(y), 6, 1);
        else ctx.fillRect(W / 2 - 1, Math.round(y), 2, 1);
      }
      vMarks.push({ type: 'marginT', y: ct, page: k }, { type: 'marginB', y: cb, page: k });
    }
    if (!Lb.state.preview && pageHeightPx > Lb.pageH()) {
      // continuous view: shade the remaining sheet
      const y0 = pr.top - cr.top + ph;
      ctx.fillStyle = C.content; ctx.fillRect(3, y0, W - 6, pageHeightPx * z() - ph);
    }
  }

  L.drawRulers = () => {
    if (rulerRaf) return;
    rulerRaf = requestAnimationFrame(() => { rulerRaf = 0; drawH(); drawV(); });
  };

  /* ---------- ruler dragging ---------- */
  function hitH(x, y) {
    for (const mk of hMarks) {
      if (mk.type.startsWith('ind') && Math.abs(x - mk.x) <= 6 && y >= mk.y && y <= mk.y2) return mk;
    }
    for (const mk of hMarks) if (mk.type.startsWith('margin') && Math.abs(x - mk.x) <= 4) return mk;
    return null;
  }
  function hitV(y) {
    for (const mk of vMarks) if (Math.abs(y - mk.y) <= 4) return mk;
    return null;
  }

  function setupRulerDrag() {
    const { rulerH, rulerV } = els();
    const tip = document.createElement('div');
    tip.className = 'size-badge';
    tip.style.cssText = 'position:fixed;z-index:40;pointer-events:none;transform:none;display:none';
    document.body.append(tip);
    const showTip = (text, x, y) => { tip.textContent = text; tip.style.left = x + 12 + 'px'; tip.style.top = y + 14 + 'px'; tip.style.display = 'block'; };

    rulerH.addEventListener('pointermove', (e) => {
      if (rulerH.dataset.dragging) return;
      const r = rulerH.getBoundingClientRect();
      const mk = hitH(e.clientX - r.left, e.clientY - r.top);
      rulerH.style.cursor = mk ? (mk.type.startsWith('margin') ? 'col-resize' : 'ew-resize') : 'default';
      rulerH.title = mk ? ({ marginL: 'Left margin', marginR: 'Right margin', indFirst: 'First line indent', indLeft: 'Left indent', indRight: 'Right indent' })[mk.type] : '';
    });
    rulerH.addEventListener('pointerdown', (e) => {
      const r = rulerH.getBoundingClientRect();
      const mk = hitH(e.clientX - r.left, e.clientY - r.top);
      if (!mk) return;
      e.preventDefault();
      rulerH.dataset.dragging = '1';
      Lb.sel.save();
      const s = Lb.MM * z();
      const pr = els().page.getBoundingClientRect();
      const x0 = pr.left - r.left;
      const ind = hMarks.ind;
      const blocks = mk.type.startsWith('ind') ? Lb.selectedBlocks() : [];
      const startX = e.clientX;
      const base = blocks.map((b) => {
        const cs = getComputedStyle(b);
        return { b, ml: parseFloat(cs.marginLeft) || 0, mr: parseFloat(cs.marginRight) || 0, ti: parseFloat(cs.textIndent) || 0 };
      });
      if (blocks.length) Lb.history.checkpoint();
      const move = (ev) => {
        const x = ev.clientX - r.left;
        const m = mg();
        if (mk.type === 'marginL') {
          m.left = round(clamp((x - x0) / s, 0, Lb.PAGE_W_MM - m.right - 30), 1);
          showTip(`Left margin ${(m.left / 10).toFixed(2)} cm`, ev.clientX, ev.clientY);
        } else if (mk.type === 'marginR') {
          m.right = round(clamp(Lb.PAGE_W_MM - (x - x0) / s, 0, Lb.PAGE_W_MM - m.left - 30), 1);
          showTip(`Right margin ${(m.right / 10).toFixed(2)} cm`, ev.clientX, ev.clientY);
        } else {
          const d = (ev.clientX - startX) / z();
          for (const it of base) {
            if (mk.type === 'indFirst') it.b.style.textIndent = Lb.util.pxToPt(it.ti + d) + 'pt';
            else if (mk.type === 'indLeft') {
              it.b.style.marginLeft = Lb.util.pxToPt(Math.max(-Lb.mm(m.left), it.ml + d)) + 'pt';
            } else if (mk.type === 'indRight') it.b.style.marginRight = Lb.util.pxToPt(it.mr - d) + 'pt';
          }
          const val = mk.type === 'indFirst' ? (ind.first + d) : mk.type === 'indLeft' ? ind.left + d : ind.right - d;
          showTip(`${({ indFirst: 'First line', indLeft: 'Left indent', indRight: 'Right indent' })[mk.type]} ${Lb.util.pxToCm(val).toFixed(2)} cm`, ev.clientX, ev.clientY);
        }
        if (mk.type.startsWith('margin')) L.applyMargins();
        L.refresh();
      };
      const up = () => {
        delete rulerH.dataset.dragging;
        tip.style.display = 'none';
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', up);
        if (blocks.length) Lb.history.commit();
        else { Lb.emit('settings'); }
        Lb.sel.restore();
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
      window.addEventListener('pointercancel', up);
    });

    rulerV.addEventListener('pointermove', (e) => {
      if (rulerV.dataset.dragging) return;
      const r = rulerV.getBoundingClientRect();
      const mk = hitV(e.clientY - r.top);
      rulerV.style.cursor = mk ? 'row-resize' : 'default';
      rulerV.title = mk ? (mk.type === 'marginT' ? 'Top margin' : 'Bottom margin') : '';
    });
    rulerV.addEventListener('pointerdown', (e) => {
      const r = rulerV.getBoundingClientRect();
      const mk = hitV(e.clientY - r.top);
      if (!mk) return;
      e.preventDefault();
      rulerV.dataset.dragging = '1';
      const s = Lb.MM * z();
      const move = (ev) => {
        const pr = els().page.getBoundingClientRect();
        const y0 = pr.top + mk.page * Lb.PAGE_H_MM * s;
        const m = mg();
        const mmv = (ev.clientY - y0) / s;
        if (mk.type === 'marginT') {
          m.top = round(clamp(mmv, 0, Lb.PAGE_H_MM - m.bottom - 40), 1);
          showTip(`Top margin ${(m.top / 10).toFixed(2)} cm`, ev.clientX, ev.clientY);
        } else {
          m.bottom = round(clamp(Lb.PAGE_H_MM - mmv, 0, Lb.PAGE_H_MM - m.top - 40), 1);
          showTip(`Bottom margin ${(m.bottom / 10).toFixed(2)} cm`, ev.clientX, ev.clientY);
        }
        L.applyMargins();
        L.refresh();
      };
      const up = () => {
        delete rulerV.dataset.dragging;
        tip.style.display = 'none';
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', up);
        Lb.emit('settings');
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
      window.addEventListener('pointercancel', up);
    });
  }

  L.init = () => {
    const { scroller } = els();
    scroller.addEventListener('scroll', () => { L.drawRulers(); Lb.emit('scroll'); }, { passive: true });
    new ResizeObserver(() => L.drawRulers()).observe(scroller);
    window.addEventListener('resize', () => L.drawRulers());
    // Ctrl + wheel zoom
    scroller.addEventListener('wheel', (e) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      L.setZoom(z() * (e.deltaY < 0 ? 1.1 : 1 / 1.1));
    }, { passive: false });
    // two-finger pinch to zoom (phones and tablets)
    let pinch = null; let pinchRaf = 0; let pinchTo = 0;
    const gap = (e) => Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY) || 1;
    scroller.addEventListener('touchstart', (e) => { if (e.touches.length === 2) pinch = { d: gap(e), z: z() }; }, { passive: true });
    scroller.addEventListener('touchmove', (e) => {
      if (!pinch || e.touches.length !== 2) return;
      e.preventDefault();
      pinchTo = pinch.z * gap(e) / pinch.d;
      if (!pinchRaf) pinchRaf = requestAnimationFrame(() => { pinchRaf = 0; L.setZoom(pinchTo); });
    }, { passive: false });
    const endPinch = (e) => { if (e.touches.length < 2) pinch = null; };
    scroller.addEventListener('touchend', endPinch, { passive: true });
    scroller.addEventListener('touchcancel', endPinch, { passive: true });
    setupRulerDrag();
    document.body.classList.toggle('preview-on', Lb.state.preview);
    L.applyMargins();
    L.refresh();
  };

  Lb.layout = L;
})();
