/* Écritoire — text & paragraph formatting, lists, styles and their dialogs. */
(function () {
  'use strict';
  const Lb = window.Lb;
  const ui = () => Lb.ui;
  const { pxToPt, firstFamily, round, esc, rgbToHex } = Lb.util;
  const F = {};
  const PT_PER_CM = 28.3465;

  F.SIZES = [8, 9, 10, 10.5, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72];
  const ALL_FONTS = [
    'Calibri', 'Calibri Light', 'Cambria', 'Candara', 'Consolas', 'Constantia', 'Corbel',
    'Arial', 'Arial Black', 'Arial Narrow', 'Book Antiqua', 'Bookman Old Style', 'Century Gothic',
    'Comic Sans MS', 'Courier New', 'Franklin Gothic Medium', 'Garamond', 'Georgia', 'Gill Sans MT',
    'Helvetica', 'Impact', 'Lucida Console', 'Lucida Sans Unicode', 'Palatino Linotype', 'Segoe UI',
    'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana',
    'Carlito', 'Caladea', 'Liberation Sans', 'Liberation Serif', 'Liberation Mono', 'DejaVu Sans', 'DejaVu Serif',
    'Noto Sans', 'Noto Serif', 'Roboto', 'Open Sans', 'Ubuntu', 'Cantarell', 'San Francisco', 'Menlo', 'Monaco', 'Avenir', 'Baskerville', 'Futura', 'Optima'
  ];

  /* ---------- installed font detection ---------- */
  let fontCache = null;
  F.availableFonts = () => {
    if (fontCache) return fontCache;
    const c = document.createElement('canvas').getContext('2d');
    const text = 'mmmmmmmmmlliWWQ@#0123456789';
    const base = {};
    for (const g of ['monospace', 'serif', 'sans-serif']) { c.font = `72px ${g}`; base[g] = c.measureText(text).width; }
    const has = (f) => ['monospace', 'serif', 'sans-serif'].some((g) => { c.font = `72px "${f}", ${g}`; return c.measureText(text).width !== base[g]; });
    fontCache = ALL_FONTS.filter((f) => has(f) || ['Calibri', 'Arial', 'Times New Roman', 'Cambria', 'Courier New', 'Georgia', 'Verdana'].includes(f));
    return fontCache;
  };

  /* ---------- format state at the caret ---------- */
  F.state = () => {
    const el = Lb.sel.focusElement();
    const ed = Lb.els.editor;
    if (!el || !ed.contains(el)) return null;
    const cs = getComputedStyle(el);
    const st = {
      family: firstFamily(cs.fontFamily),
      size: pxToPt(parseFloat(cs.fontSize)),
      bold: (parseInt(cs.fontWeight, 10) || 400) >= 600,
      italic: cs.fontStyle !== 'normal',
      underline: false, strike: false, sup: false, sub: false,
      color: rgbToHex(cs.color)
    };
    for (let n = el; n && n !== ed; n = n.parentElement) {
      const c = n === el ? cs : getComputedStyle(n);
      const deco = c.textDecorationLine || '';
      if (deco.includes('underline')) st.underline = true;
      if (deco.includes('line-through')) st.strike = true;
      if (c.verticalAlign === 'super' || n.tagName === 'SUP') { if (!st.sup && !st.sub) st.supEl = n; st.sup = true; }
      if (c.verticalAlign === 'sub' || n.tagName === 'SUB') { if (!st.sup && !st.sub) st.supEl = n; st.sub = true; }
      if (Lb.isBlock(n)) break;
    }
    if (st.supEl && st.supEl.parentElement) st.size = pxToPt(parseFloat(getComputedStyle(st.supEl.parentElement).fontSize));
    const block = Lb.closestBlock(el);
    if (block) {
      const bcs = getComputedStyle(block);
      st.align = ({ start: 'left', left: 'left', center: 'center', right: 'right', end: 'right', justify: 'justify' })[bcs.textAlign] || 'left';
      st.block = block.tagName.toLowerCase();
      st.blockEl = block;
      st.marginLeft = parseFloat(bcs.marginLeft) || 0;
      st.marginRight = parseFloat(bcs.marginRight) || 0;
      st.marginTop = parseFloat(bcs.marginTop) || 0;
      st.marginBottom = parseFloat(bcs.marginBottom) || 0;
      st.textIndent = parseFloat(bcs.textIndent) || 0;
      const lh = bcs.lineHeight;
      st.lineHeight = lh === 'normal' ? 1.15 : lh.endsWith('px') ? round(parseFloat(lh) / parseFloat(bcs.fontSize), 2) : parseFloat(lh);
      if (block.style.lineHeight && block.style.lineHeight.endsWith('pt')) st.lineExact = parseFloat(block.style.lineHeight);
    } else st.align = 'left';
    const list = el.closest('ul,ol');
    if (list && ed.contains(list)) { st.list = list; st.listTag = list.tagName.toLowerCase(); st.listFmt = list.dataset.list || getComputedStyle(list).listStyleType; }
    return st;
  };

  /* ---------- inline styles over the selection ---------- */
  const TAGS_FOR = {
    'font-weight': ['B', 'STRONG'],
    'font-style': ['I', 'EM'],
    'text-decoration': ['U', 'S', 'STRIKE', 'DEL', 'INS'],
    'vertical-align': ['SUP', 'SUB'],
    'font-family': ['FONT'], 'font-size': ['FONT'], color: ['FONT']
  };

  /**
   * Apply CSS properties (kebab-case keys) to the selected text.
   * With a collapsed selection the style applies to what is typed next.
   */
  F.applyInline = (styles) => {
    Lb.sel.restore();
    const sel = window.getSelection();
    const range = Lb.sel.range();
    if (!range || !Lb.sel.inEditor(range)) return;
    Lb.history.checkpoint();
    if (range.collapsed) {
      const span = document.createElement('span');
      for (const [k, v] of Object.entries(styles)) span.style.setProperty(k, v);
      span.textContent = '​';
      range.insertNode(span);
      const r = document.createRange();
      r.setStart(span.firstChild, 1); r.collapse(true);
      sel.removeAllRanges(); sel.addRange(r);
      Lb.sel.save();
      Lb.history.commit();
      return;
    }
    document.execCommand('styleWithCSS', false, false);
    document.execCommand('fontName', false, 'lb-marker');
    document.execCommand('styleWithCSS', false, true);
    const ed = Lb.els.editor;
    const markers = [...ed.querySelectorAll('font[face="lb-marker"]'), ...[...ed.querySelectorAll('span[style*="lb-marker"]')]];
    const props = Object.keys(styles);
    const created = [];
    for (const m of markers) {
      const span = document.createElement('span');
      if (m.tagName === 'FONT') {
        if (m.getAttribute('color')) span.style.color = m.getAttribute('color');
      } else {
        span.setAttribute('style', m.getAttribute('style'));
        span.style.removeProperty('font-family');
      }
      for (const [k, v] of Object.entries(styles)) span.style.setProperty(k, v);
      while (m.firstChild) span.appendChild(m.firstChild);
      m.replaceWith(span);
      // strip the same properties from descendants so the new value wins
      for (const d of [...span.querySelectorAll('*')]) {
        if (d.style) for (const p of props) d.style.removeProperty(p);
        const kill = props.some((p) => (TAGS_FOR[p] || []).includes(d.tagName));
        if (kill || ((d.tagName === 'SPAN' || d.tagName === 'FONT') && !d.attributes.length) || (d.tagName === 'SPAN' && d.getAttribute('style') === '' && d.attributes.length === 1)) {
          d.replaceWith(...d.childNodes);
        }
      }
      created.push(span);
    }
    if (created.length) {
      const r = document.createRange();
      r.setStartBefore(created[0]); r.setEndAfter(created[created.length - 1]);
      sel.removeAllRanges(); sel.addRange(r);
      Lb.sel.save();
    }
    Lb.history.commit();
    Lb.emit('selection');
  };

  F.exec = (cmd, val) => {
    Lb.sel.restore();
    Lb.history.checkpoint();
    document.execCommand(cmd, false, val);
    Lb.history.commit();
    Lb.sel.save();
    Lb.emit('selection');
  };

  /* ---------- paragraph helpers ---------- */
  F.forBlocks = (fn) => {
    Lb.sel.restore();
    Lb.history.checkpoint();
    Lb.ensureBlocks();
    const blocks = Lb.selectedBlocks();
    blocks.forEach(fn);
    Lb.history.commit();
    Lb.layout.schedule();
    Lb.emit('selection');
    return blocks;
  };

  F.setFontFamily = (name) => { if (name) F.applyInline({ 'font-family': `'${name.replace(/'/g, '')}'` }); };
  F.setFontSize = (pt) => {
    const v = parseFloat(pt);
    if (!(v > 0)) return;
    F.applyInline({ 'font-size': Lb.util.clamp(v, 1, 1638) + 'pt' });
  };
  F.grow = (dir) => {
    const st = F.state();
    const cur = st ? st.size : 11;
    let next;
    if (dir > 0) next = F.SIZES.find((s) => s > cur + 0.01) || cur + 10;
    else next = [...F.SIZES].reverse().find((s) => s < cur - 0.01) || Math.max(1, cur - 1);
    F.setFontSize(next);
  };

  F.clearFormatting = () => {
    Lb.sel.restore();
    Lb.history.checkpoint();
    document.execCommand('removeFormat');
    // remove leftover styled spans inside the selection
    const r = Lb.sel.range();
    if (r && !r.collapsed) {
      for (const sp of [...Lb.els.editor.querySelectorAll('span[style],font')]) {
        if (r.intersectsNode(sp) && !sp.classList.contains('lb-tab')) sp.replaceWith(...sp.childNodes);
      }
    }
    for (const b of Lb.selectedBlocks()) {
      b.removeAttribute('style');
      if (/^H\d$|^BLOCKQUOTE$/.test(b.tagName)) {
        const p = document.createElement('p');
        while (b.firstChild) p.appendChild(b.firstChild);
        b.replaceWith(p);
      }
    }
    Lb.history.commit();
    Lb.layout.schedule();
    Lb.emit('selection');
  };

  F.align = (a) => {
    F.forBlocks((b) => { b.style.textAlign = a === 'left' ? '' : a; if (!b.getAttribute('style')) b.removeAttribute('style'); });
  };

  F.indent = (dir) => {
    Lb.sel.restore();
    const blocks = Lb.selectedBlocks();
    if (blocks.some((b) => b.tagName === 'LI')) { F.exec(dir > 0 ? 'indent' : 'outdent'); fixNestedLists(); Lb.fixStructure(); return; }
    F.forBlocks((b) => {
      const cur = parseFloat(getComputedStyle(b).marginLeft) || 0;
      const step = Lb.util.cmToPx(1.27);
      const next = Math.max(0, cur + dir * step);
      b.style.marginLeft = next ? pxToPt(next) + 'pt' : '';
      if (!b.getAttribute('style')) b.removeAttribute('style');
    });
  };

  // nested lists created by the browser inherit their own default style: pick
  // a sensible style per level (like most editors do)
  function fixNestedLists() {
    const cycleUl = ['disc', 'circle', 'square'];
    const cycleOl = ['decimal', 'lower-alpha', 'lower-roman'];
    for (const l of Lb.els.editor.querySelectorAll('ul ul, ul ol, ol ol, ol ul')) {
      if (l.dataset.list) continue;
      let depth = 0;
      for (let p = l.parentElement; p && p !== Lb.els.editor; p = p.parentElement) if (/^(UL|OL)$/.test(p.tagName)) depth++;
      const fmt = l.tagName === 'UL' ? cycleUl[depth % 3] : cycleOl[depth % 3];
      l.dataset.list = fmt;
      l.style.listStyleType = fmt;
    }
    // indent inside lists can leave the browser's blockquote wrappers behind
    for (const bq of Lb.els.editor.querySelectorAll('blockquote[style*="margin: 0 0 0 40px"]')) {
      bq.replaceWith(...bq.childNodes);
    }
  }

  /* ---------- lists ---------- */
  F.lastBullet = 'disc';
  F.lastNumber = 'decimal';
  F.list = (tag, fmt) => {
    Lb.sel.restore();
    Lb.history.checkpoint();
    const st = F.state() || {};
    const cmd = tag === 'ul' ? 'insertUnorderedList' : 'insertOrderedList';
    if (fmt === 'none' || (fmt == null && st.listTag === tag)) {
      if (st.listTag) document.execCommand(st.listTag === 'ul' ? 'insertUnorderedList' : 'insertOrderedList');
      Lb.fixStructure();
      Lb.history.commit(); Lb.layout.schedule(); Lb.emit('selection');
      return;
    }
    const style = fmt || (tag === 'ul' ? F.lastBullet : F.lastNumber);
    if (tag === 'ul') F.lastBullet = style; else F.lastNumber = style;
    if (st.listTag !== tag) document.execCommand(cmd);
    Lb.fixStructure();
    const lists = new Set();
    const fe = Lb.sel.focusElement();
    if (fe && fe.closest('ul,ol')) lists.add(fe.closest('ul,ol'));
    for (const b of Lb.selectedBlocks()) { const l = b.closest('ul,ol'); if (l) lists.add(l); }
    for (const l of lists) {
      if (!Lb.els.editor.contains(l) || l.tagName.toLowerCase() !== tag) continue;
      l.dataset.list = style;
      l.style.listStyleType = window.LbDocxReader.cssListType(style);
    }
    Lb.history.commit();
    Lb.layout.schedule();
    Lb.emit('selection');
  };

  /* ---------- block styles ---------- */
  F.setBlock = (tag) => {
    Lb.sel.restore();
    Lb.history.checkpoint();
    Lb.ensureBlocks();
    document.execCommand('formatBlock', false, tag);
    Lb.history.commit();
    Lb.layout.schedule();
    Lb.emit('selection');
  };

  F.lineSpacing = (v) => F.forBlocks((b) => { b.style.lineHeight = String(v); });
  F.toggleSpace = (which) => F.forBlocks((b) => {
    const prop = which === 'before' ? 'marginTop' : 'marginBottom';
    const cur = parseFloat(getComputedStyle(b)[prop]) || 0;
    b.style[prop] = cur > 0.5 ? '0pt' : '12pt';
  });

  /* ---------- page break ---------- */
  F.pageBreak = () => {
    const range = Lb.sel.restore();
    if (!range) return;
    Lb.history.checkpoint();
    const ed = Lb.els.editor;
    let top = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
    if (top === ed) top = ed.childNodes[range.startOffset] || ed.lastElementChild;
    while (top && top.parentElement !== ed) top = top.parentElement;
    const brk = document.createElement('div');
    brk.className = 'lb-page-break';
    brk.setAttribute('contenteditable', 'false');
    let next;
    if (top && /^(P|H[1-6]|BLOCKQUOTE|PRE|DIV)$/.test(top.tagName) && !top.classList.contains('lb-page-break') && Lb.closestBlock(range.startContainer) === top) {
      const tail = document.createRange();
      tail.setStart(range.startContainer, range.startOffset);
      tail.setEnd(top, top.childNodes.length);
      const frag = tail.extractContents();
      next = top.cloneNode(false);
      next.appendChild(frag);
      if (!next.textContent.replace(/​/g, '') && !next.querySelector('img')) next.innerHTML = '<br>';
      if (!top.textContent.replace(/​/g, '') && !top.querySelector('img')) top.innerHTML = '<br>';
      top.after(brk, next);
    } else {
      next = document.createElement('p');
      next.innerHTML = '<br>';
      if (top) top.after(brk, next); else ed.append(brk, next);
    }
    const r = document.createRange();
    r.setStart(next, 0); r.collapse(true);
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    Lb.history.commit();
    Lb.layout.refresh();
    next.scrollIntoView({ block: 'nearest' });
  };

  /* ---------- toolbar reflection ---------- */
  F.reflect = () => {
    const st = F.state();
    if (!st) return;
    const famInput = document.getElementById('fontFamily');
    const sizeInput = document.getElementById('fontSize');
    if (document.activeElement !== famInput) famInput.value = st.family;
    if (document.activeElement !== sizeInput) sizeInput.value = st.size;
    famInput.style.fontFamily = `'${st.family}', var(--ui-font)`;
    const flags = {
      bold: st.bold, italic: st.italic, underline: st.underline, strike: st.strike, sup: st.sup, sub: st.sub,
      left: st.align === 'left', center: st.align === 'center', right: st.align === 'right', justify: st.align === 'justify',
      ul: st.listTag === 'ul', ol: st.listTag === 'ol'
    };
    for (const b of document.querySelectorAll('.ribbon [data-state]')) {
      const k = b.dataset.state;
      if (k in flags) b.classList.toggle('on', !!flags[k]);
    }
    const blk = st.list ? 'p' : st.block;
    for (const c of document.querySelectorAll('.style-chip')) c.classList.toggle('on', c.dataset.style === blk);
    // layout tab fields
    const set = (id, v) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = v; };
    set('lyIndLeft', round(Lb.util.pxToCm(st.marginLeft || 0), 2));
    set('lyIndRight', round(Lb.util.pxToCm(st.marginRight || 0), 2));
    set('lySpBefore', round((st.marginTop || 0) * 0.75, 1));
    set('lySpAfter', round((st.marginBottom || 0) * 0.75, 1));
  };

  /* ---------- menus ---------- */
  const h = (...a) => Lb.ui.h(...a);
  Lb.menus.fontMenu = () => {
    const st = F.state();
    const wrap = h('div', { class: 'font-list', style: { width: '250px' } });
    wrap.append(Lb.ui.menuTitle('Fonts'));
    for (const f of F.availableFonts()) {
      wrap.append(Lb.ui.menuItem(f, () => F.setFontFamily(f), { labelStyle: { fontFamily: `'${f}'` }, checkable: true, checked: st && st.family === f }));
    }
    return wrap;
  };
  Lb.menus.sizeMenu = () => {
    const st = F.state();
    const wrap = h('div', { style: { width: '90px' } });
    for (const s of F.SIZES) wrap.append(Lb.ui.menuItem(String(s), () => F.setFontSize(s), { checkable: true, checked: st && st.size === s }));
    return wrap;
  };
  F.foreColor = '#c2410c';
  F.hiliteColor = '#fde047';
  Lb.menus.foreMenu = () => Lb.ui.palette((c) => {
    if (c) { F.foreColor = c; document.getElementById('foreSwatch').style.background = c; }
    F.applyInline({ color: c || '#000000' });
  }, { autoLabel: 'Automatic', current: F.foreColor });
  Lb.menus.hiliteMenu = () => Lb.ui.palette((c) => {
    if (c) { F.hiliteColor = c; document.getElementById('hiliteSwatch').style.background = c; }
    F.applyInline({ 'background-color': c || 'transparent' });
  }, { autoLabel: 'No Color', autoIcon: 'close', current: F.hiliteColor });

  function listGallery(items, tag, current) {
    const g = h('div', { class: 'list-gallery' });
    for (const [fmt, sample] of items) {
      const b = h('button', { class: fmt === current ? 'on' : '', title: fmt });
      if (fmt === 'none') { b.classList.add('none'); b.textContent = 'None'; } else b.innerHTML = sample;
      b.addEventListener('click', () => { Lb.ui.closePopover(); F.list(tag, fmt); });
      g.append(b);
    }
    return g;
  }
  const lines = (marks) => marks.map((m) => `<div style="display:flex;gap:6px;align-items:center;margin:2px 0"><span style="width:16px;text-align:right">${m}</span><i style="flex:1;height:2px;background:#bbb;display:block"></i></div>`).join('');
  Lb.menus.bulletMenu = () => {
    const st = F.state() || {};
    const wrap = h('div');
    wrap.append(Lb.ui.menuTitle('Bullet Library'));
    wrap.append(listGallery([
      ['none'], ['disc', lines(['●', '●', '●'])], ['circle', lines(['○', '○', '○'])],
      ['square', lines(['■', '■', '■'])], ['dash', lines(['–', '–', '–'])], ['check', lines(['✓', '✓', '✓'])],
      ['arrow', lines(['➢', '➢', '➢'])]
    ], 'ul', st.listTag === 'ul' ? st.listFmt : null));
    return wrap;
  };
  Lb.menus.numberMenu = () => {
    const st = F.state() || {};
    const wrap = h('div');
    wrap.append(Lb.ui.menuTitle('Numbering Library'));
    wrap.append(listGallery([
      ['none'], ['decimal', lines(['1.', '2.', '3.'])], ['lower-alpha', lines(['a.', 'b.', 'c.'])],
      ['upper-alpha', lines(['A.', 'B.', 'C.'])], ['lower-roman', lines(['i.', 'ii.', 'iii.'])], ['upper-roman', lines(['I.', 'II.', 'III.'])]
    ], 'ol', st.listTag === 'ol' ? st.listFmt : null));
    return wrap;
  };
  Lb.menus.spacingMenu = () => {
    const st = F.state() || {};
    const wrap = h('div', { style: { width: '250px' } });
    for (const v of [1, 1.15, 1.5, 2, 2.5, 3]) {
      wrap.append(Lb.ui.menuItem(v.toFixed(v % 1 ? 2 : 1).replace(/0$/, '').replace(/\.$/, '.0'), () => F.lineSpacing(v), { checkable: true, checked: Math.abs((st.lineHeight || 0) - v) < 0.02 }));
    }
    wrap.append(Lb.ui.menuSep());
    wrap.append(Lb.ui.menuItem((st.marginTop > 0.5 ? 'Remove' : 'Add') + ' Space Before Paragraph', () => F.toggleSpace('before')));
    wrap.append(Lb.ui.menuItem((st.marginBottom > 0.5 ? 'Remove' : 'Add') + ' Space After Paragraph', () => F.toggleSpace('after')));
    wrap.append(Lb.ui.menuSep());
    wrap.append(Lb.ui.menuItem('Line Spacing Options…', () => F.paragraphDialog(), { icon: 'paragraph' }));
    return wrap;
  };
  const MARGIN_PRESETS = [
    ['Normal', { top: 25.4, bottom: 25.4, left: 25.4, right: 25.4 }],
    ['Narrow', { top: 12.7, bottom: 12.7, left: 12.7, right: 12.7 }],
    ['Moderate', { top: 25.4, bottom: 25.4, left: 19.1, right: 19.1 }],
    ['Wide', { top: 25.4, bottom: 25.4, left: 50.8, right: 50.8 }],
    ['Classic', { top: 25.4, bottom: 25.4, left: 31.8, right: 31.8 }],
    ['Indonesia (4-3-3-3)', { top: 30, bottom: 30, left: 40, right: 30 }]
  ];
  Lb.menus.marginMenu = () => {
    const m = Lb.settings.margins;
    const wrap = h('div', { style: { width: '380px' } });
    for (const [name, p] of MARGIN_PRESETS) {
      const same = ['top', 'bottom', 'left', 'right'].every((k) => Math.abs(m[k] - p[k]) < 0.2);
      wrap.append(Lb.ui.menuItem(name, () => F.setMargins(p), {
        checkable: true, checked: same,
        sub: `T ${(p.top / 10).toFixed(2)} · B ${(p.bottom / 10).toFixed(2)} · L ${(p.left / 10).toFixed(2)} · R ${(p.right / 10).toFixed(2)} cm`
      }));
    }
    wrap.append(Lb.ui.menuSep());
    wrap.append(Lb.ui.menuItem('Custom Margins…', () => F.pageSetupDialog(), { icon: 'pageSetup' }));
    return wrap;
  };

  /* ---------- paper size and orientation ---------- */
  Lb.menus.orientationMenu = () => {
    const wrap = h('div', { style: { width: '220px' } });
    for (const [v, label] of [['portrait', 'Portrait'], ['landscape', 'Landscape']]) {
      wrap.append(Lb.ui.menuItem(label, () => F.setPage({ orientation: v }), {
        icon: v, checkable: true, checked: Lb.settings.orientation === v
      }));
    }
    return wrap;
  };
  Lb.menus.paperMenu = () => {
    const wrap = h('div', { style: { width: '260px' } });
    for (const [k, p] of Object.entries(Lb.PAPERS)) {
      wrap.append(Lb.ui.menuItem(p.label, () => F.setPage({ paper: k }), {
        checkable: true, checked: Lb.settings.paper === k, sub: p.sub
      }));
    }
    wrap.append(Lb.ui.menuSep());
    wrap.append(Lb.ui.menuItem('Page Setup…', () => F.pageSetupDialog(), { icon: 'pageSetup' }));
    return wrap;
  };

  /** Change paper size and/or orientation; margins are shrunk if they no longer fit. */
  F.setPage = (p) => {
    if (p.paper && Lb.PAPERS[p.paper]) Lb.settings.paper = p.paper;
    if (p.orientation === 'portrait' || p.orientation === 'landscape') Lb.settings.orientation = p.orientation;
    const m = Lb.settings.margins;
    const fit = (a, b, total, keep) => {
      if (a + b <= total - keep) return [a, b];
      const f = (total - keep) / (a + b);
      return [round(a * f, 1), round(b * f, 1)];
    };
    [m.left, m.right] = fit(m.left, m.right, Lb.PAGE_W_MM, 30);
    [m.top, m.bottom] = fit(m.top, m.bottom, Lb.PAGE_H_MM, 40);
    Lb.layout.applyMargins();
    Lb.layout.refresh();
    // keep the whole page width visible on small screens
    if (Lb.els.scroller.clientWidth < Lb.pageW() * Lb.state.zoom + 40) Lb.layout.fitWidth();
    Lb.emit('settings');
  };

  F.setMargins = (m) => {
    Object.assign(Lb.settings.margins, m);
    Lb.layout.applyMargins();
    Lb.layout.refresh();
    Lb.emit('settings');
  };

  /* ---------- dialogs ---------- */
  const opt = (v, label, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(label)}</option>`;

  F.fontDialog = async () => {
    Lb.sel.save();
    const st = F.state() || { family: 'Calibri', size: 11 };
    const fonts = F.availableFonts();
    const styleVal = st.bold && st.italic ? 'bi' : st.bold ? 'b' : st.italic ? 'i' : 'r';
    const body = `
      <div class="grid2">
        <div><div class="mrow"><label>Font</label><input type="text" id="fdFamily" list="fdFonts" value="${esc(st.family)}" style="flex:1"></div>
          <datalist id="fdFonts">${fonts.map((f) => `<option value="${esc(f)}">`).join('')}</datalist></div>
        <div><div class="mrow"><label>Size</label><input type="number" id="fdSize" min="1" max="400" step="0.5" value="${st.size}"><span class="unit">pt</span></div></div>
        <div><div class="mrow"><label>Font style</label><select id="fdStyle">${opt('r', 'Regular', styleVal === 'r')}${opt('i', 'Italic', styleVal === 'i')}${opt('b', 'Bold', styleVal === 'b')}${opt('bi', 'Bold Italic', styleVal === 'bi')}</select></div></div>
        <div><div class="mrow"><label>Font color</label><input type="color" id="fdColor" value="${st.color || '#000000'}"></div></div>
        <div><div class="mrow"><label>Spacing</label><input type="number" id="fdSpacing" step="0.1" value="0"><span class="unit">pt</span></div></div>
        <div><div class="mrow"><label>Highlight</label><input type="checkbox" id="fdHlOn"><input type="color" id="fdHl" value="#fde047"></div></div>
      </div>
      <fieldset style="margin-top:10px"><legend>Effects</legend>
        <div class="grid2">
          <label class="check"><input type="checkbox" id="fdU" ${st.underline ? 'checked' : ''}> Underline</label>
          <label class="check"><input type="checkbox" id="fdS" ${st.strike ? 'checked' : ''}> Strikethrough</label>
          <label class="check"><input type="checkbox" id="fdSup" ${st.sup ? 'checked' : ''}> Superscript</label>
          <label class="check"><input type="checkbox" id="fdSub" ${st.sub ? 'checked' : ''}> Subscript</label>
          <label class="check"><input type="checkbox" id="fdCaps"> All caps</label>
          <label class="check"><input type="checkbox" id="fdSmall"> Small caps</label>
        </div>
      </fieldset>
      <div class="preview-box" id="fdPreview">The quick brown fox — Écritoire</div>`;
    const res = await Lb.ui.modal({
      title: 'Font', width: 560, body,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Apply', value: 'ok', primary: true }],
      init: (root) => {
        const q = (id) => root.querySelector('#' + id);
        const upd = () => {
          const p = q('fdPreview').style;
          p.fontFamily = `'${q('fdFamily').value}'`;
          p.fontSize = Math.min(48, +q('fdSize').value || 11) + 'pt';
          const s = q('fdStyle').value;
          p.fontWeight = s.includes('b') ? 'bold' : 'normal';
          p.fontStyle = s.includes('i') ? 'italic' : 'normal';
          p.color = q('fdColor').value;
          p.textDecoration = [q('fdU').checked ? 'underline' : '', q('fdS').checked ? 'line-through' : ''].join(' ').trim() || 'none';
          p.letterSpacing = (+q('fdSpacing').value || 0) + 'pt';
          p.textTransform = q('fdCaps').checked ? 'uppercase' : 'none';
          p.fontVariant = q('fdSmall').checked ? 'small-caps' : 'normal';
          p.backgroundColor = q('fdHlOn').checked ? q('fdHl').value : '#fff';
        };
        root.addEventListener('input', upd);
        root.addEventListener('change', upd);
        q('fdSup').addEventListener('change', () => { if (q('fdSup').checked) q('fdSub').checked = false; });
        q('fdSub').addEventListener('change', () => { if (q('fdSub').checked) q('fdSup').checked = false; });
        upd();
      }
    });
    if (res.value !== 'ok') { Lb.sel.restore(); return; }
    const q = (id) => res.root.querySelector('#' + id);
    const s = q('fdStyle').value;
    const styles = {
      'font-family': `'${q('fdFamily').value.replace(/'/g, '')}'`,
      'font-size': (+q('fdSize').value || st.size) + 'pt',
      'font-weight': s.includes('b') ? 'bold' : 'normal',
      'font-style': s.includes('i') ? 'italic' : 'normal',
      color: q('fdColor').value,
      'text-decoration': [q('fdU').checked ? 'underline' : '', q('fdS').checked ? 'line-through' : ''].join(' ').trim() || 'none',
      'vertical-align': q('fdSup').checked ? 'super' : q('fdSub').checked ? 'sub' : 'baseline',
      'text-transform': q('fdCaps').checked ? 'uppercase' : 'none',
      'font-variant': q('fdSmall').checked ? 'small-caps' : 'normal'
    };
    const sp = +q('fdSpacing').value || 0;
    if (sp) styles['letter-spacing'] = sp + 'pt';
    if (q('fdHlOn').checked) styles['background-color'] = q('fdHl').value;
    if (styles['vertical-align'] !== 'baseline') styles['font-size'] = round((+q('fdSize').value || st.size) * 0.66, 1) + 'pt';
    F.applyInline(styles);
  };

  F.paragraphDialog = async () => {
    Lb.sel.save();
    const st = F.state() || {};
    const cm = (px) => round(Lb.util.pxToCm(px || 0), 2);
    const pt = (px) => round((px || 0) * 0.75, 1);
    const special = st.textIndent > 0.5 ? 'first' : st.textIndent < -0.5 ? 'hanging' : 'none';
    let lineMode = 'multiple'; let lineVal = st.lineHeight || 1.15;
    if (st.lineExact) { lineMode = 'exact'; lineVal = st.lineExact; }
    else if (Math.abs(lineVal - 1) < 0.01) lineMode = 'single';
    else if (Math.abs(lineVal - 1.5) < 0.01) lineMode = '1.5';
    else if (Math.abs(lineVal - 2) < 0.01) lineMode = 'double';
    const body = `
      <fieldset><legend>General</legend>
        <div class="mrow"><label>Alignment</label><select id="pdAlign">${opt('left', 'Left', st.align === 'left')}${opt('center', 'Centered', st.align === 'center')}${opt('right', 'Right', st.align === 'right')}${opt('justify', 'Justified', st.align === 'justify')}</select></div>
      </fieldset>
      <fieldset><legend>Indentation</legend>
        <div class="grid2">
          <div class="mrow"><label>Left</label><input type="number" id="pdLeft" step="0.1" value="${cm(st.marginLeft)}"><span class="unit">cm</span></div>
          <div class="mrow"><label>Special</label><select id="pdSpecial">${opt('none', '(none)', special === 'none')}${opt('first', 'First line', special === 'first')}${opt('hanging', 'Hanging', special === 'hanging')}</select></div>
          <div class="mrow"><label>Right</label><input type="number" id="pdRight" step="0.1" value="${cm(st.marginRight)}"><span class="unit">cm</span></div>
          <div class="mrow"><label>By</label><input type="number" id="pdBy" step="0.1" min="0" value="${cm(Math.abs(st.textIndent || 0)) || 1.27}"><span class="unit">cm</span></div>
        </div>
      </fieldset>
      <fieldset><legend>Spacing</legend>
        <div class="grid2">
          <div class="mrow"><label>Before</label><input type="number" id="pdBefore" step="1" min="0" value="${pt(st.marginTop)}"><span class="unit">pt</span></div>
          <div class="mrow"><label>Line spacing</label><select id="pdLineMode">${opt('single', 'Single', lineMode === 'single')}${opt('1.5', '1.5 lines', lineMode === '1.5')}${opt('double', 'Double', lineMode === 'double')}${opt('multiple', 'Multiple', lineMode === 'multiple')}${opt('exact', 'Exactly', lineMode === 'exact')}</select></div>
          <div class="mrow"><label>After</label><input type="number" id="pdAfter" step="1" min="0" value="${pt(st.marginBottom)}"><span class="unit">pt</span></div>
          <div class="mrow"><label>At</label><input type="number" id="pdLineVal" step="0.05" min="0.5" value="${lineVal}"><span class="unit" id="pdLineUnit">${lineMode === 'exact' ? 'pt' : '×'}</span></div>
        </div>
      </fieldset>
      <p class="hint">Applies to all selected paragraphs. 1 cm = 28.35 pt.</p>`;
    const res = await Lb.ui.modal({
      title: 'Paragraph', width: 560, body,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Apply', value: 'ok', primary: true }],
      init: (root) => {
        const mode = root.querySelector('#pdLineMode'); const val = root.querySelector('#pdLineVal'); const unit = root.querySelector('#pdLineUnit');
        mode.addEventListener('change', () => {
          const m = mode.value;
          unit.textContent = m === 'exact' ? 'pt' : '×';
          if (m === 'single') val.value = 1; else if (m === '1.5') val.value = 1.5; else if (m === 'double') val.value = 2;
          else if (m === 'exact') val.value = 14; else if (m === 'multiple' && (+val.value > 5)) val.value = 1.15;
        });
      }
    });
    if (res.value !== 'ok') { Lb.sel.restore(); return; }
    const q = (id) => res.root.querySelector('#' + id);
    const left = +q('pdLeft').value || 0, right = +q('pdRight').value || 0, by = +q('pdBy').value || 0;
    const special2 = q('pdSpecial').value;
    const mode = q('pdLineMode').value; const lv = +q('pdLineVal').value || 1;
    F.forBlocks((b) => {
      const a = q('pdAlign').value;
      b.style.textAlign = a === 'left' ? '' : a;
      if (b.tagName !== 'LI') {
        b.style.marginLeft = left ? round(left * PT_PER_CM, 2) + 'pt' : '';
        b.style.marginRight = right ? round(right * PT_PER_CM, 2) + 'pt' : '';
      }
      b.style.textIndent = special2 === 'none' ? '' : (special2 === 'first' ? '' : '-') + round(by * PT_PER_CM, 2) + 'pt';
      b.style.marginTop = (+q('pdBefore').value || 0) + 'pt';
      b.style.marginBottom = (+q('pdAfter').value || 0) + 'pt';
      b.style.lineHeight = mode === 'exact' ? lv + 'pt' : String(mode === 'single' ? 1 : mode === '1.5' ? 1.5 : mode === 'double' ? 2 : lv);
      if (!b.getAttribute('style')) b.removeAttribute('style');
    });
  };

  F.pageSetupDialog = async () => {
    const m = Lb.settings.margins;
    const c = (v) => round(v / 10, 2);
    const body = `
      <fieldset><legend>Margins</legend>
        <div class="grid2">
          <div class="mrow"><label>Top</label><input type="number" id="psTop" step="0.1" min="0" value="${c(m.top)}"><span class="unit">cm</span></div>
          <div class="mrow"><label>Bottom</label><input type="number" id="psBottom" step="0.1" min="0" value="${c(m.bottom)}"><span class="unit">cm</span></div>
          <div class="mrow"><label>Left</label><input type="number" id="psLeft" step="0.1" min="0" value="${c(m.left)}"><span class="unit">cm</span></div>
          <div class="mrow"><label>Right</label><input type="number" id="psRight" step="0.1" min="0" value="${c(m.right)}"><span class="unit">cm</span></div>
        </div>
      </fieldset>
      <fieldset><legend>Paper</legend>
        <div class="mrow"><label>Size</label><select id="psPaper">${Object.entries(Lb.PAPERS).map(([k, p]) =>
          `<option value="${k}"${Lb.settings.paper === k ? ' selected' : ''}>${p.label} — ${p.sub}</option>`).join('')}</select></div>
        <div class="mrow"><label>Orientation</label><select id="psOrient">
          <option value="portrait"${Lb.settings.orientation !== 'landscape' ? ' selected' : ''}>Portrait</option>
          <option value="landscape"${Lb.settings.orientation === 'landscape' ? ' selected' : ''}>Landscape</option>
        </select></div>
      </fieldset>`;
    const dims = (root) => {
      const p = Lb.PAPERS[root.querySelector('#psPaper').value] || Lb.PAPERS.A4;
      return root.querySelector('#psOrient').value === 'landscape' ? [p.h, p.w] : [p.w, p.h];
    };
    const res = await Lb.ui.modal({
      title: 'Page Setup', width: 500, body,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'OK', value: 'ok', primary: true }],
      validate: (v, root) => {
        if (v !== 'ok') return true;
        const g = (id) => (+root.querySelector('#' + id).value || 0) * 10;
        const [w, hh] = dims(root);
        if (g('psLeft') + g('psRight') > w - 30 || g('psTop') + g('psBottom') > hh - 40) { Lb.ui.toast('The margins are too large for this paper size.', 'error'); return false; }
        return true;
      }
    });
    if (res.value !== 'ok') return;
    const g = (id) => round((+res.root.querySelector('#' + id).value || 0) * 10, 1);
    Object.assign(Lb.settings.margins, { top: g('psTop'), bottom: g('psBottom'), left: g('psLeft'), right: g('psRight') });
    F.setPage({ paper: res.root.querySelector('#psPaper').value, orientation: res.root.querySelector('#psOrient').value });
  };

  /* ---------- layout tab quick fields ---------- */
  F.bindLayoutFields = () => {
    const bind = (id, fn) => {
      const el = document.getElementById(id);
      el.addEventListener('focus', () => Lb.sel.save());
      el.addEventListener('change', () => { const v = parseFloat(el.value) || 0; F.forBlocks((b) => fn(b, v)); });
    };
    bind('lyIndLeft', (b, v) => { b.style.marginLeft = v ? round(v * PT_PER_CM, 2) + 'pt' : ''; });
    bind('lyIndRight', (b, v) => { b.style.marginRight = v ? round(v * PT_PER_CM, 2) + 'pt' : ''; });
    bind('lySpBefore', (b, v) => { b.style.marginTop = v + 'pt'; });
    bind('lySpAfter', (b, v) => { b.style.marginBottom = v + 'pt'; });
  };

  Lb.format = F;
})();
