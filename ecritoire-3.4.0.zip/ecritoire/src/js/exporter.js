/* Écritoire — exporter.
 * Turns the live editor DOM into:
 *   - a JSON document model consumed by lib/docx-writer.js (.docx output)
 *   - clean HTML for PDF export and printing
 * Formatting is read from computed styles, so anything the editor displays
 * (including pasted content) is exported faithfully.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { rgbToHex, firstFamily } = Lb.util;
  const E = {};

  const LIST_MAP = {
    disc: 'disc', circle: 'circle', square: 'square', decimal: 'decimal', 'decimal-leading-zero': 'decimal',
    'lower-alpha': 'lower-alpha', 'lower-latin': 'lower-alpha', 'upper-alpha': 'upper-alpha', 'upper-latin': 'upper-alpha',
    'lower-roman': 'lower-roman', 'upper-roman': 'upper-roman'
  };
  const pt = (px) => Math.round(px * 0.75 * 100) / 100;

  /* ---------- images ---------- */
  function rasterize(img, maxSide) {
    const w = img.offsetWidth || img.naturalWidth || 100;
    const h = img.offsetHeight || img.naturalHeight || 100;
    const shape = img.classList.contains('lb-shape');
    let scale = shape ? 2 : Math.max(1, Math.min((img.naturalWidth || w) / w, 3));
    const limit = maxSide || 2400;
    if (Math.max(w, h) * scale > limit) scale = limit / Math.max(w, h);
    const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
    const canvas = document.createElement('canvas');
    canvas.width = cw; canvas.height = ch;
    const ctx = canvas.getContext('2d');
    const filter = Lb.objects.filterOf(img);
    if (filter) ctx.filter = filter;
    const src = img; // shapes are re-rendered at their exact size on every resize
    try {
      ctx.drawImage(src, 0, 0, cw, ch);
      const isJpeg = /^data:image\/jpe?g/i.test(img.src) && !/opacity/.test(filter);
      const url = canvas.toDataURL(isJpeg ? 'image/jpeg' : 'image/png', 0.92);
      return { base64: url.split(',')[1], type: isJpeg ? 'jpg' : 'png', width: w, height: h };
    } catch (e) {
      console.warn('rasterize failed', e);
      return null;
    }
  }

  /**
   * How a picture or shape sits in the text (see wrap.js), with its position in
   * CSS pixels: x from the left of the text column (or table cell), y from the
   * top of its paragraph.
   */
  function floatOf(img) {
    const wrap = img.dataset.wrap;
    if (!wrap) return null;
    const z = Lb.state.zoom;
    const r = img.getBoundingClientRect();
    const col = img.closest('td,th') || Lb.els.editor;
    let para = img.parentElement;
    while (para && para !== Lb.els.editor && !Lb.isBlock(para) && !/^(TD|TH)$/.test(para.tagName)) para = para.parentElement;
    const cr = col.getBoundingClientRect(), pr = (para || col).getBoundingClientRect();
    return {
      wrap, side: img.dataset.side || 'left', z: +img.dataset.z || 0,
      x: Math.round((r.left - cr.left) / z), y: Math.round((r.top - pr.top) / z),
      inCell: col !== Lb.els.editor
    };
  }
  /** A shape's own settings, so Écritoire can make it editable again when the .docx is opened. */
  function shapeOf(img) {
    if (!img.classList.contains('lb-shape')) return null;
    const d = img.dataset;
    const o = { shape: d.shape, fill: d.fill, stroke: d.stroke, sw: d.sw };
    for (const k of ['nofill', 'nostroke', 'path', 'closed', 'ab', 'ac', 'as', 'ah', 'at', 'ag', 'ao']) if (d[k] != null) o[k] = d[k];
    // Word files store tight wrapping as square: remember it for Écritoire
    if (d.wrap === 'tight') o.tight = '1';
    return o;
  }

  function imageRun(img) {
    const w = img.offsetWidth, h = img.offsetHeight;
    if (!w || !h) return null;
    const extra = {};
    const fl = floatOf(img); if (fl) extra.float = fl;
    const sh = shapeOf(img); if (sh) extra.shape = sh;
    const m = /^data:image\/(png|jpe?g|gif|bmp);base64,(.*)$/i.exec(img.src);
    const needsRaster = img.classList.contains('lb-shape') || !!Lb.objects.filterOf(img) || !m;
    if (!needsRaster) {
      const type = m[1].toLowerCase().replace('jpeg', 'jpg');
      return Object.assign({ image: { base64: m[2], type, width: w, height: h } }, extra);
    }
    const r = rasterize(img);
    return r ? Object.assign({ image: r }, extra) : null;
  }

  /* ---------- runs ---------- */
  function blockOf(el) {
    return el.closest('p,h1,h2,h3,h4,h5,h6,li,blockquote,pre,td,th,div') || Lb.els.editor;
  }

  function runProps(textParent, block) {
    const cs = getComputedStyle(textParent);
    const p = {};
    const weight = parseInt(cs.fontWeight, 10) || 400;
    if (weight >= 600) p.b = true;
    if (cs.fontStyle !== 'normal') p.i = true;
    let supEl = null;
    let hl = null; let hlStopped = false;
    for (let n = textParent; n && n !== block.parentElement; n = n.parentElement) {
      const c = n === textParent ? cs : getComputedStyle(n);
      const deco = c.textDecorationLine || '';
      if (deco.includes('underline')) p.u = true;
      if (deco.includes('line-through')) p.s = true;
      if (!supEl && (c.verticalAlign === 'super' || c.verticalAlign === 'sub')) { supEl = n; if (c.verticalAlign === 'super') p.sup = true; else p.sub = true; }
      if (!hlStopped && n !== block) {
        if (n.style && n.style.backgroundColor) {
          hlStopped = true;
          const col = rgbToHex(c.backgroundColor);
          if (col) hl = col;
        } else if (!Lb.util.isTransparent(c.backgroundColor)) { hl = rgbToHex(c.backgroundColor); hlStopped = true; }
      }
      if (n === block) break;
    }
    if (hl) p.highlight = hl;
    const sizeEl = supEl && supEl.parentElement ? supEl.parentElement : textParent;
    p.size = Math.round(parseFloat(getComputedStyle(sizeEl).fontSize) * 0.75 * 2) / 2;
    p.font = firstFamily(cs.fontFamily);
    const col = rgbToHex(cs.color);
    if (col && col !== '#000000') p.color = col;
    if (cs.textTransform === 'uppercase') p.caps = true;
    if (cs.letterSpacing && cs.letterSpacing !== 'normal' && parseFloat(cs.letterSpacing)) p.spacing = pt(parseFloat(cs.letterSpacing));
    return p;
  }

  const sameProps = (a, b) => {
    const ka = Object.keys(a).filter((k) => k !== 'text'), kb = Object.keys(b).filter((k) => k !== 'text');
    return ka.length === kb.length && ka.every((k) => a[k] === b[k]);
  };

  function collectRuns(block, runs, opts, nodes) {
    const o = opts || {};
    const walk = (list) => {
      for (const n of list) {
        if (n.nodeType === 3) {
          const parent = n.parentElement;
          const ws = getComputedStyle(parent).whiteSpace;
          let text = n.nodeValue.replace(/​/g, '');
          if (!/^pre/.test(ws)) text = text.replace(/[ \n\r\f]+/g, ' ');
          if (!text) continue;
          const props = runProps(parent, block);
          const parts = text.split(/(\t|\n)/);
          for (const part of parts) {
            if (part === '\t') runs.push({ tab: true });
            else if (part === '\n') runs.push({ br: true });
            else if (part) {
              const last = runs[runs.length - 1];
              if (last && last.text != null && !last.image && sameProps(last, props)) last.text += part;
              else runs.push(Object.assign({ text: part }, props));
            }
          }
        } else if (n.nodeType === 1) {
          const tag = n.tagName;
          if (tag === 'BR') { if (n.nextSibling || n.parentElement !== block) runs.push({ br: true }); continue; }
          if (tag === 'IMG') { const r = imageRun(n); if (r) runs.push(r); continue; }
          if (tag === 'UL' || tag === 'OL' || tag === 'TABLE') continue; // handled by the caller
          if (n.classList.contains('lb-page-break')) continue;
          if (n.classList.contains('lb-fn')) { runs.push({ footnote: n.dataset.note || '' }); continue; }
          if (n.classList.contains('lb-video')) { const v = Lb.media && Lb.media.exportRun(n); if (v) runs.push(v); continue; }
          if (getComputedStyle(n).display === 'none') continue;
          const isInnerBlock = o.flatten && /^(P|H[1-6]|DIV|BLOCKQUOTE|PRE)$/.test(tag);
          if (isInnerBlock && runs.length && !runs[runs.length - 1].br) runs.push({ br: true });
          walk(n.childNodes);
        }
      }
    };
    walk(nodes || block.childNodes);
    // trim a trailing line break
    while (runs.length && runs[runs.length - 1].br) runs.pop();
    // collapse leading space
    if (runs.length && runs[0].text) runs[0].text = runs[0].text.replace(/^ +/, '');
    return runs;
  }

  /* ---------- paragraphs ---------- */
  function paragraph(el, list) {
    const b = paragraphProps(el, list);
    collectRuns(el, b.runs, { flatten: true });
    return b;
  }

  function paragraphProps(el, list) {
    const cs = getComputedStyle(el);
    const tag = el.tagName.toLowerCase();
    const b = { type: 'p', runs: [] };
    if (/^h[1-6]$/.test(tag)) b.style = tag;
    else if (tag === 'blockquote' && !/border:\s*none/.test(el.getAttribute('style') || '')) b.style = 'quote';
    const ta = cs.textAlign;
    b.align = ({ start: 'left', left: 'left', center: 'center', right: 'right', end: 'right', justify: 'justify', '-webkit-center': 'center' })[ta] || 'left';
    b.spacingBefore = pt(parseFloat(cs.marginTop) || 0);
    b.spacingAfter = pt(parseFloat(cs.marginBottom) || 0);
    const fs = parseFloat(cs.fontSize) || 14.667;
    if (cs.lineHeight !== 'normal') {
      const lh = cs.lineHeight.endsWith('px') ? parseFloat(cs.lineHeight) / fs : parseFloat(cs.lineHeight);
      if (lh > 0) b.lineHeight = Math.round(lh * 100) / 100;
    } else b.lineHeight = 1.15;
    if (list) b.list = list;
    else {
      let left = parseFloat(cs.marginLeft) || 0;
      if (b.style === 'quote') left += parseFloat(cs.paddingLeft) || 0;
      if (left) b.indentLeft = pt(left);
      const right = parseFloat(cs.marginRight) || 0;
      if (right) b.indentRight = pt(right);
    }
    const ti = parseFloat(cs.textIndent) || 0;
    if (ti) b.firstLine = pt(ti);
    return b;
  }

  /* ---------- containers ---------- */
  let listInstance = 0;

  function listFormat(listEl) {
    if (listEl.dataset.list && listEl.dataset.list !== 'none') return listEl.dataset.list;
    const t = getComputedStyle(listEl).listStyleType || '';
    if (LIST_MAP[t]) return LIST_MAP[t];
    if (t.includes('–')) return 'dash';
    if (t.includes('✓')) return 'check';
    if (t.includes('➢')) return 'arrow';
    return listEl.tagName === 'OL' ? 'decimal' : 'disc';
  }

  function list(listEl, level, out) {
    const fmt = listFormat(listEl);
    const instance = ++listInstance;
    for (const li of listEl.children) {
      if (li.tagName !== 'LI') { container(li, out); continue; }
      out.push(paragraph(li, { fmt, level, instance }));
      for (const child of li.children) {
        if (child.tagName === 'UL' || child.tagName === 'OL') list(child, level + 1, out);
        else if (child.tagName === 'TABLE') out.push(table(child));
      }
    }
  }

  function table(tbl) {
    const t = { type: 'table', rows: [] };
    const firstCell = tbl.querySelector('td,th');
    if (firstCell) t.borderColor = rgbToHex(getComputedStyle(firstCell).borderTopColor) || '#000000';
    for (const tr of tbl.rows) {
      const row = { cells: [] };
      for (const cell of tr.cells) {
        const c = { blocks: [], colspan: cell.colSpan || 1, rowspan: cell.rowSpan || 1, width: cell.offsetWidth };
        const bg = getComputedStyle(cell).backgroundColor;
        if (!Lb.util.isTransparent(bg)) c.fill = rgbToHex(bg);
        container(cell, c.blocks);
        row.cells.push(c);
      }
      t.rows.push(row);
    }
    // column widths from the first row without merged cells
    const plain = [...tbl.rows].find((r) => [...r.cells].every((c) => (c.colSpan || 1) === 1));
    if (plain) t.colWidths = [...plain.cells].map((c) => c.offsetWidth);
    return t;
  }

  function toc(el) {
    const title = el.querySelector('.lb-toc-title');
    return {
      type: 'toc',
      title: el.dataset.title || (title ? title.textContent : 'Contents'),
      color: title ? rgbToHex(getComputedStyle(title).color) : null,
      entries: [...el.querySelectorAll('.lb-toc-e')].map((e) => ({
        text: (e.querySelector('.lb-toc-t') || e).textContent,
        level: +((/\bl(\d)\b/.exec(e.className) || [0, 1])[1]),
        page: (e.querySelector('.lb-toc-n') || {}).textContent || ''
      }))
    };
  }

  function container(root, out) {
    let loose = null; // inline content directly inside the container
    const flushLoose = () => {
      if (!loose) return;
      const nodes = loose;
      loose = null;
      const b = paragraphProps(root, null);
      if (/^(TD|TH)$/.test(root.tagName)) { b.spacingBefore = 0; b.spacingAfter = 0; delete b.indentLeft; delete b.indentRight; }
      collectRuns(root, b.runs, {}, nodes);
      out.push(b);
    };
    for (const n of root.childNodes) {
      if (n.nodeType === 1) {
        const tag = n.tagName;
        if (n.classList.contains('lb-page-break')) { flushLoose(); out.push({ type: 'pagebreak' }); continue; }
        if (n.classList.contains('lb-toc')) { flushLoose(); out.push(toc(n)); continue; }
        if (tag === 'UL' || tag === 'OL') { flushLoose(); list(n, 0, out); continue; }
        if (tag === 'TABLE') { flushLoose(); out.push(table(n)); continue; }
        if (/^(P|H[1-6]|BLOCKQUOTE|PRE|LI|DIV|SECTION|ARTICLE)$/.test(tag)) {
          flushLoose();
          if ([...n.children].some((c) => /^(P|H[1-6]|DIV|UL|OL|TABLE|BLOCKQUOTE|PRE)$/.test(c.tagName))) container(n, out);
          else out.push(paragraph(n, null));
          continue;
        }
        if (tag === 'HR') { flushLoose(); continue; }
      } else if (n.nodeType === 3 && !n.nodeValue.replace(/[\s​]+/g, '') && !loose) continue;
      if (!loose) loose = [];
      loose.push(n);
    }
    flushLoose();
  }

  /** Build the .docx document model from the editor. */
  E.buildModel = () => Lb.layout.withoutPushes(async () => {
    Lb.fixStructure();
    listInstance = 0;
    // videos: their files go into the .docx next to a still picture
    const media = Lb.media ? await Lb.media.prepare(Lb.els.editor) : [];
    const blocks = [];
    container(Lb.els.editor, blocks);
    return {
      media,
      settings: {
        pageWidthMm: Lb.PAGE_W_MM, pageHeightMm: Lb.PAGE_H_MM,
        paper: Lb.settings.paper, orientation: Lb.settings.orientation,
        margins: Object.assign({}, Lb.settings.margins),
        defaultFont: 'Calibri', defaultSize: 11,
        title: Lb.state.title,
        hf: Lb.settings.hf || null
      },
      blocks
    };
  });

  /** Clean HTML for PDF / printing (layout artefacts removed, shapes kept as SVG). */
  E.cleanHtml = () => {
    const clone = Lb.els.editor.cloneNode(true);
    for (const el of clone.querySelectorAll('[data-lb-push]')) {
      el.style.marginTop = el.getAttribute('data-lb-push');
      el.removeAttribute('data-lb-push');
    }
    for (const el of clone.querySelectorAll('.lb-page-break')) { el.removeAttribute('style'); el.removeAttribute('contenteditable'); }
    for (const el of clone.querySelectorAll('.lb-selected,.lb-cell-active')) el.classList.remove('lb-selected', 'lb-cell-active');
    // make shape SVGs exact for their final size
    const live = Lb.els.editor.querySelectorAll('img.lb-shape');
    const copies = clone.querySelectorAll('img.lb-shape');
    copies.forEach((img, i) => {
      const src = live[i];
      if (src) img.src = window.LbShapes.dataUrl(src.dataset.shape, Lb.objects.shapeProps(src));
    });
    const walker = document.createTreeWalker(clone, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) if (n.nodeValue.includes('​')) n.nodeValue = n.nodeValue.replace(/​/g, '');
    return clone.innerHTML;
  };

  /** Remove editing artefacts from a cloned element tree. */
  function tidy(root, liveRoot) {
    for (const el of root.querySelectorAll('[contenteditable]')) el.removeAttribute('contenteditable');
    for (const el of root.querySelectorAll('.lb-selected,.lb-cell-active')) el.classList.remove('lb-selected', 'lb-cell-active');
    for (const el of root.querySelectorAll('.lb-toc-empty')) el.remove();
    for (const el of root.querySelectorAll('[data-lb-push]')) el.removeAttribute('data-lb-push');
    const live = liveRoot.querySelectorAll('img.lb-shape');
    root.querySelectorAll('img.lb-shape').forEach((img, i) => {
      if (live[i]) img.src = window.LbShapes.dataUrl(live[i].dataset.shape, Lb.objects.shapeProps(live[i]));
    });
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) if (n.nodeValue.includes('\u200B')) n.nodeValue = n.nodeValue.replace(/\u200B/g, '');
  }

  /**
   * Page-by-page HTML for printing and PDF on the desktop: every page is a fixed
   * box showing exactly what the page-break preview shows, plus its header,
   * footer and footnotes. Uses the same styles as the editor, so the lines break
   * the same way.
   *
   * Each page gets the run of paragraphs that appear on it, laid out together
   * (not one by one), so text keeps flowing around pictures and shapes that
   * float in an earlier paragraph, and free objects (behind or in front of the
   * text) stay where they were placed.
   */
  E.pagedHtml = () => E.pagedPages().join('');

  /** The same, one HTML string per page (for Print Preview and printing chosen pages). */
  E.pagedPages = () => {
    const wasPreview = Lb.state.preview;
    Lb.objects.deselect();
    if (!wasPreview) Lb.layout.setPreview(true); else Lb.layout.refresh();
    try {
      const ed = Lb.els.editor;
      const pr = Lb.els.page.getBoundingClientRect();
      const z = Lb.state.zoom;
      const ph = Lb.pageH();
      const n = Lb.layout.pageCount();
      const er = ed.getBoundingClientRect();
      const left = (er.left - pr.left) / z, width = er.width / z;
      const py = (v) => (v - pr.top) / z;
      const blocks = [];
      for (const el of ed.children) {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        // where it reaches, including pictures and shapes that float or are placed outside it
        let top = py(r.top), bottom = py(r.bottom);
        for (const o of el.querySelectorAll('img[data-wrap]')) {
          const orr = o.getBoundingClientRect();
          top = Math.min(top, py(orr.top)); bottom = Math.max(bottom, py(orr.bottom));
        }
        blocks.push({ el, boxTop: py(r.top), top, bottom, mt: parseFloat(cs.marginTop) || 0, pb: el.classList.contains('lb-page-break') });
      }
      const cloneOf = (b) => {
        if (b.pb) {
          // a page break only keeps its space here; the page boxes do the breaking
          const sp = document.createElement('div');
          sp.setAttribute('style', b.el.getAttribute('style') || '');
          sp.style.visibility = 'hidden';
          return sp.outerHTML;
        }
        const c = b.el.cloneNode(true);
        tidy(c, b.el);
        c.removeAttribute('data-lb-cover');
        return c.outerHTML;
      };
      const out = [];
      for (let k = 0; k < n; k++) {
        const y0 = k * ph, y1 = y0 + ph;
        let i0 = -1, i1 = -1;
        blocks.forEach((b, i) => {
          if (b.pb || b.bottom <= y0 + 0.5 || b.top >= y1 - 0.5) return;
          if (i0 < 0) i0 = i;
          i1 = i;
        });
        let body = '';
        if (i0 >= 0) {
          // earlier paragraphs whose floating pictures reach into this run shape its lines: include them
          for (let changed = true; changed;) {
            changed = false;
            for (let j = 0; j < i0; j++) {
              if (!blocks[j].pb && blocks[j].bottom > blocks[i0].boxTop + 0.5 && blocks[j].el.querySelector('img[data-wrap="square"],img[data-wrap="tight"]')) { i0 = j; changed = true; break; }
            }
          }
          for (let i = i0; i <= i1; i++) body += cloneOf(blocks[i]);
          const top = blocks[i0].boxTop - blocks[i0].mt - y0;
          body = `<div class="lb-content lb-run" style="position:absolute;left:${left}px;top:${top}px;width:${width}px;display:flow-root;padding:0;margin:0">${body}</div>`;
        }
        out.push(`<div class="lb-pp">${body}${Lb.docparts.pageDecor(k, n)}</div>`);
      }
      return out;
    } finally {
      if (!wasPreview) Lb.layout.setPreview(false);
    }
  };

  Lb.exporter = E;
})();
