/* Écritoire — PDF export without a print engine (used on phones and tablets).
 * Each page of the page-break preview is rendered to an image with
 * html-to-image and placed on a page of the same paper size with pdf-lib, so the PDF looks
 * exactly like the screen.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const PT_PER_MM = 72 / 25.4;

  const frame = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

  function bytesToBase64(bytes) {
    let bin = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    return btoa(bin);
  }

  /**
   * Render the current document to PDF.
   * @param {{onProgress?: (done:number,total:number)=>void, pixelRatio?: number, pages?: number[]}} opts
   *   pages: 1-based page numbers to include (all when left out)
   * @returns {Promise<string>} base64 PDF
   */
  async function fromEditor(opts) {
    const o = opts || {};
    if (!window.htmlToImage || !window.PDFLib) throw new Error('PDF libraries are not loaded.');
    const ed = Lb.els.editor;
    const prev = { zoom: Lb.state.zoom, preview: Lb.state.preview, scroll: Lb.els.scroller.scrollTop, spell: ed.spellcheck };
    Lb.objects.deselect();
    const sel = window.getSelection();
    if (sel) sel.removeAllRanges();
    ed.spellcheck = false;
    document.body.classList.add('lb-exporting');
    if (!Lb.state.preview) Lb.layout.setPreview(true);
    if (Lb.state.zoom !== 1) Lb.layout.setZoom(1);
    Lb.layout.refresh();
    await frame();

    const undoStills = Lb.media ? await Lb.media.beforeCapture() : () => {};
    try {
      const page = Lb.els.page;
      const pw = Lb.pageW();
      const ph = Lb.pageH();
      const pages = Lb.layout.pageCount();
      const pagePt = [Lb.PAGE_W_MM * PT_PER_MM, Lb.PAGE_H_MM * PT_PER_MM];
      // big paper (A3) gets a slightly lower ratio to keep memory use down on phones
      const ratio = o.pixelRatio || (pw * ph > 1.5e6 ? 1.5 : 2);
      const pdf = await window.PDFLib.PDFDocument.create();
      pdf.setTitle(Lb.state.title || 'Document');
      pdf.setCreator('Écritoire');
      pdf.setProducer('Écritoire');
      // Safari (iPhone / iPad) sometimes draws pictures blank the first time:
      // a throw-away first render loads them
      if (/iP(hone|ad|od)|Macintosh/.test(navigator.userAgent) && 'ontouchend' in document) {
        try { await window.htmlToImage.toPng(page, { width: pw, height: Math.min(ph, 400), pixelRatio: 0.25, skipFonts: true, cacheBust: false }); } catch (_) { /* ignore */ }
      }
      const list = (o.pages && o.pages.length ? o.pages.map((p) => p - 1) : [...Array(pages).keys()]).filter((k) => k >= 0 && k < pages);
      let done = 0;
      for (const k of list) {
        // shift the cloned sheet up so page k fills the capture window
        const png = await window.htmlToImage.toPng(page, {
          width: pw,
          height: ph,
          pixelRatio: ratio,
          backgroundColor: '#ffffff',
          cacheBust: false,
          skipFonts: true,
          style: { transform: `translateY(${-k * ph}px)`, transformOrigin: '0 0', boxShadow: 'none', margin: '0', left: '0', top: '0' }
        });
        const img = await pdf.embedPng(png);
        const p = pdf.addPage(pagePt);
        p.drawImage(img, { x: 0, y: 0, width: pagePt[0], height: pagePt[1] });
        if (o.onProgress) o.onProgress(++done, list.length);
      }
      const bytes = await pdf.save();
      return bytesToBase64(bytes);
    } finally {
      undoStills();
      document.body.classList.remove('lb-exporting');
      ed.spellcheck = prev.spell;
      if (!prev.preview) Lb.layout.setPreview(false);
      if (prev.zoom !== 1) Lb.layout.setZoom(prev.zoom);
      Lb.els.scroller.scrollTop = prev.scroll;
    }
  }

  window.LbPdf = { fromEditor, bytesToBase64 };
})();
