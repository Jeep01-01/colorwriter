/* Écritoire — Print Preview, like Word's Print screen: the pages exactly as they
 * will print (headers, footers, page numbers, pictures), and a choice of pages:
 * All, Current page, or Custom ("1, 2, 6", "3-5", "8-"). Pages can also be
 * picked by clicking them. Print and Save as PDF use the same choice.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const R = window.LbPageRange;
  const P = {};
  let ov = null;          // the open preview, or null
  let st = null;          // { count, current, mode, custom, pages, scale }
  let keep = null;        // where the cursor was in the document
  const SCALE_KEY = 'ecritoire.previewScale';

  const isPhone = () => window.matchMedia('(max-width: 720px), (max-height: 520px)').matches;

  /** The page the caret is on (1-based), measured before the preview changes the layout. */
  function currentPage() {
    const ph = Lb.pageH() * Lb.state.zoom;
    const pr = Lb.els.page.getBoundingClientRect();
    let y = null;
    if (keep) {
      const r = keep.getBoundingClientRect();
      const n = keep.startContainer;
      if (r && (r.top || r.bottom)) y = r.top;
      else if (n.nodeType === 1) y = n.getBoundingClientRect().top;
      else if (n.parentElement) y = n.parentElement.getBoundingClientRect().top;
    }
    if (y == null) { const sr = Lb.els.scroller.getBoundingClientRect(); y = sr.top + sr.height / 3; }
    return Math.max(1, Math.floor((y - pr.top) / ph) + 1);
  }

  function chosen() {
    if (st.mode === 'all') return { pages: [...Array(st.count).keys()].map((k) => k + 1), error: null };
    if (st.mode === 'current') return { pages: [Math.min(st.current, st.count)], error: null };
    return R.parse(st.custom, st.count);
  }

  function refresh() {
    const { pages, error } = chosen();
    st.pages = pages;
    const on = new Set(pages);
    for (const el of ov.querySelectorAll('.pp-page')) el.classList.toggle('off', !on.has(+el.dataset.n));
    const sum = ov.querySelector('.pp-summary');
    sum.textContent = !pages.length ? 'No pages chosen'
      : pages.length === st.count ? (st.count === 1 ? 'Printing the page' : `Printing all ${st.count} pages`)
      : `Printing ${pages.length} of ${st.count} pages: ${R.format(pages)}`;
    const err = ov.querySelector('.pp-error');
    err.textContent = error || '';
    err.hidden = !error;
    for (const b of ov.querySelectorAll('.pp-go')) b.disabled = !pages.length;
    for (const r of ov.querySelectorAll('input[name="pp-mode"]')) r.checked = r.value === st.mode;
    const custom = ov.querySelector('.pp-custom');
    if (document.activeElement !== custom) custom.value = st.custom;
    custom.classList.toggle('bad', st.mode === 'custom' && !!error && !pages.length);
  }

  function setScale(s) {
    st.scale = Math.max(0.15, Math.min(1.5, Math.round(s * 100) / 100));
    try { localStorage.setItem(SCALE_KEY, String(st.scale)); } catch (_) { /* private mode */ }
    const pw = Lb.pageW(), ph = Lb.pageH();
    for (const sheet of ov.querySelectorAll('.pp-sheet')) {
      sheet.style.width = Math.round(pw * st.scale) + 'px';
      sheet.style.height = Math.round(ph * st.scale) + 'px';
      const inner = sheet.firstElementChild;
      inner.style.width = pw + 'px';
      inner.style.height = ph + 'px';
      inner.style.transform = `scale(${st.scale})`;
    }
    ov.querySelector('.pp-zoom-val').textContent = Math.round(st.scale * 100) + '%';
  }
  function fitScale() {
    const area = ov.querySelector('.pp-pages');
    const w = area.clientWidth - (isPhone() ? 24 : 64) - 20; // padding, and room for a scroll bar
    const pw = Lb.pageW();
    // phones: one page across; larger screens: two pages side by side when they fit at a readable size
    const two = Math.floor(((w - 28) / 2 / pw) * 100) / 100;
    return isPhone() ? w / pw : (two >= 0.42 ? Math.min(two, 0.75) : Math.min(1, w / pw));
  }

  /** Clicking a page adds it to the chosen pages or takes it out. */
  function togglePage(n) {
    const cur = new Set(st.pages);
    if (st.mode !== 'custom') st.mode = 'custom';
    if (cur.has(n)) cur.delete(n); else cur.add(n);
    st.custom = R.format([...cur]);
    ov.querySelector('.pp-custom').value = st.custom;
    refresh();
  }

  async function doPrint() {
    const { pages } = chosen();
    if (!pages.length) return;
    const all = pages.length === st.count;
    close();
    await Lb.printing.printPages(all ? null : pages);
  }
  async function doPdf() {
    const { pages } = chosen();
    if (!pages.length) return;
    const all = pages.length === st.count;
    close();
    await Lb.printing.exportPdf(all ? null : { pages });
  }

  function close() {
    if (!ov) return;
    ov.remove();
    ov = null;
    document.removeEventListener('keydown', onKey, true);
    document.removeEventListener('beforeinput', onBeforeInput, true);
    document.body.classList.remove('pp-open');
    // back to where the cursor was (on phones without bringing up the keyboard)
    if (keep && Lb.els.editor.contains(keep.startContainer)) {
      Lb.savedRange = keep;
      if (!Lb.isMobile) {
        Lb.els.editor.focus({ preventScroll: true });
        const s = window.getSelection(); s.removeAllRanges(); s.addRange(keep);
      }
    }
  }
  function onKey(e) {
    if (!ov) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') { e.preventDefault(); e.stopPropagation(); doPrint(); return; }
    // nothing typed while the preview is open may change the document behind it;
    // inside the preview (the Pages box) keys work as usual
    e.stopPropagation();
    if (!ov.contains(e.target)) e.preventDefault();
  }
  // the browser's own undo/redo would also reach the document: stop it
  function onBeforeInput(e) {
    if (ov && !ov.contains(e.target)) { e.preventDefault(); e.stopPropagation(); }
  }

  P.isOpen = () => !!ov;
  P.close = close;

  P.open = async (opts) => {
    if (ov) return doPrint(); // Print pressed again inside the preview
    const o = opts || {};
    const h = Lb.ui.h;
    const live = Lb.sel.range();
    keep = live && Lb.sel.inEditor(live) ? live.cloneRange() : (Lb.savedRange && Lb.els.editor.contains(Lb.savedRange.startContainer) ? Lb.savedRange.cloneRange() : null);
    // pages are counted as they print: measure in the page-break view
    const wasPreview = Lb.state.preview;
    if (!wasPreview) Lb.layout.setPreview(true);
    const current = currentPage();
    if (!wasPreview) Lb.layout.setPreview(false);
    Lb.objects.deselect();
    let pages;
    try { pages = await Lb.printing.pagedPages(); } catch (err) { Lb.ui.alert('Print Preview', 'The preview could not be made: ' + (err.message || err)); return; }
    let saved = 0;
    try { saved = +localStorage.getItem(SCALE_KEY) || 0; } catch (_) { saved = 0; }
    st = { count: pages.length, current: Math.min(current, pages.length), mode: o.pages ? 'custom' : 'all', custom: o.pages || '', pages: [], scale: 0.5 };

    const radio = (value, label) => {
      const inp = h('input', { type: 'radio', name: 'pp-mode', value });
      inp.addEventListener('change', () => { st.mode = value; refresh(); if (value === 'custom') ov.querySelector('.pp-custom').focus(); });
      return h('label', { class: 'pp-radio' }, inp, h('span', null, label));
    };
    const custom = h('input', { class: 'pp-custom', type: 'text', inputmode: 'text', autocomplete: 'off', spellcheck: 'false', placeholder: 'e.g. 1, 2, 6 or 3-5', 'aria-label': 'Pages to print' });
    custom.addEventListener('input', () => { st.mode = 'custom'; st.custom = custom.value; refresh(); });
    custom.addEventListener('focus', () => { if (st.mode !== 'custom') { st.mode = 'custom'; if (!st.custom) st.custom = String(st.current); refresh(); custom.select(); } });
    custom.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doPrint(); } });

    const btn = (label, icon, fn, cls) => {
      const b = h('button', { class: 'btn ' + (cls || ''), type: 'button' }, Lb.ui.icon(icon), h('span', null, label));
      b.addEventListener('click', fn);
      return b;
    };
    const s = Lb.settings;
    const paper = `${s.paper || 'A4'} · ${s.orientation === 'landscape' ? 'Landscape' : 'Portrait'}`;
    const zoomOut = h('button', { class: 'icon-btn', type: 'button', title: 'Smaller pages' }, Lb.ui.icon('zoomOut'));
    const zoomIn = h('button', { class: 'icon-btn', type: 'button', title: 'Bigger pages' }, Lb.ui.icon('zoomIn'));
    const fit = h('button', { class: 'btn sm', type: 'button', title: 'Fit the pages to the window' }, 'Fit');
    zoomOut.addEventListener('click', () => setScale(st.scale - 0.1));
    zoomIn.addEventListener('click', () => setScale(st.scale + 0.1));
    fit.addEventListener('click', () => setScale(fitScale()));

    const side = h('div', { class: 'pp-side' },
      h('div', { class: 'pp-actions' },
        btn('Print', 'print', doPrint, 'primary pp-go'),
        btn('Save as PDF', 'pdf', doPdf, 'pp-go')),
      h('div', { class: 'pp-sec' }, h('div', { class: 'pp-label' }, 'Pages'),
        radio('all', `All pages (${st.count})`),
        radio('current', `Current page (${st.current})`),
        (() => { const r = radio('custom', 'Pages:'); r.classList.add('pp-radio-custom'); r.append(custom); return r; })(),
        h('p', { class: 'pp-hint' }, 'Type page numbers and ranges: 1, 2, 6 or 3-5. Or click pages to pick them.'),
        h('p', { class: 'pp-error', hidden: true })),
      h('div', { class: 'pp-sec' }, h('div', { class: 'pp-label' }, 'Paper'),
        h('div', { class: 'pp-paper' }, h('span', null, paper),
          btn('Page Setup…', 'pageSetup', () => { close(); Lb.run('pageSetup'); }, 'sm'))),
      h('p', { class: 'pp-summary' }),
      h('p', { class: 'pp-note' }, Lb.isMobile
        ? 'Print makes a PDF of these pages and opens it, so you can print from your phone’s PDF viewer.'
        : 'Print opens the Windows print dialog for these pages, where you choose the printer and the number of copies.'));

    const pagesArea = h('div', { class: 'pp-pages', role: 'list' });
    pages.forEach((html, k) => {
      const n = k + 1;
      const inner = h('div', { class: 'pp-scale' });
      inner.innerHTML = html;
      const sheet = h('div', { class: 'pp-sheet' }, inner);
      const tick = h('span', { class: 'pp-tick' }, Lb.ui.icon('tick'));
      const page = h('div', { class: 'pp-page', role: 'listitem', 'data-n': String(n), title: `Page ${n}: click to include or leave out` },
        sheet, h('div', { class: 'pp-num' }, tick, h('span', null, `Page ${n}`)));
      page.addEventListener('click', () => togglePage(n));
      pagesArea.append(page);
    });

    ov = h('div', { class: 'pp-overlay', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Print Preview' },
      h('div', { class: 'pp-bar' },
        h('button', { class: 'icon-btn pp-close', type: 'button', title: 'Close Print Preview (Esc)', onclick: close }, Lb.ui.icon('close')),
        h('div', { class: 'pp-title' }, 'Print Preview'),
        h('div', { class: 'pp-zoom' }, zoomOut, h('span', { class: 'pp-zoom-val' }, ''), zoomIn, fit)),
      h('div', { class: 'pp-body' }, side, pagesArea));
    document.body.append(ov);
    document.body.classList.add('pp-open');
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('beforeinput', onBeforeInput, true);
    setScale(saved || fitScale());
    refresh();
    // keyboard focus moves into the preview, away from the document
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    if (o.pages) custom.focus(); else ov.querySelector('.pp-go').focus();
    // larger screens: show the current page first (the choices stay beside it)
    const cur = pagesArea.querySelector(`.pp-page[data-n="${st.current}"]`);
    if (cur && st.current > 1 && !isPhone()) cur.scrollIntoView({ block: 'start' }); // phones: keep the Print button in view
  };

  Lb.printPreview = P;
})();
