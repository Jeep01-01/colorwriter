/* Écritoire — shape library (50 shapes).
 * Every shape is drawn in a 100×100 box and stretched to its frame.
 * Strokes use vector-effect:non-scaling-stroke so their width stays
 * constant whatever the shape's size or aspect ratio.
 */
(function (root) {
  'use strict';

  const r1 = (n) => Math.round(n * 100) / 100;
  const pts = (arr) => arr.map((p) => p.map(r1).join(',')).join(' ');
  const poly = (arr, extra) => `<polygon points="${pts(arr)}"${extra || ''}/>`;
  const path = (d, extra) => `<path d="${d}"${extra || ''}/>`;
  const flat = (s) => s.split(/\s+/).filter(Boolean).map((p) => p.split(',').map(Number));

  function regular(n, rot) {
    const out = [];
    const a0 = (rot == null ? -90 : rot) * Math.PI / 180;
    for (let i = 0; i < n; i++) {
      const a = a0 + i * 2 * Math.PI / n;
      out.push([50 + 50 * Math.cos(a), 50 + 50 * Math.sin(a)]);
    }
    return out;
  }
  function star(n, inner, radii) {
    const out = [];
    for (let i = 0; i < n * 2; i++) {
      const a = -Math.PI / 2 + i * Math.PI / n;
      let r = i % 2 === 0 ? 50 : 50 * inner;
      if (radii) r *= radii[i % radii.length];
      out.push([50 + r * Math.cos(a), 50 + r * Math.sin(a)]);
    }
    return out;
  }

  // Each draw(c) receives colors: c.fill, c.stroke, c.ink (for details like eyes)
  const SHAPES = [
    // ---------------- Basic ----------------
    { id: 'rectangle', name: 'Rectangle', cat: 'Basic', draw: () => '<rect x="0" y="0" width="100" height="100"/>' },
    { id: 'round-rect', name: 'Rounded Rectangle', cat: 'Basic', draw: () => '<rect x="0" y="0" width="100" height="100" rx="14" ry="14"/>' },
    { id: 'snip-rect', name: 'Snipped Rectangle', cat: 'Basic', draw: () => poly(flat('0,0 78,0 100,22 100,100 0,100')) },
    { id: 'ellipse', name: 'Oval', cat: 'Basic', draw: () => '<ellipse cx="50" cy="50" rx="50" ry="50"/>' },
    { id: 'triangle', name: 'Triangle', cat: 'Basic', draw: () => poly(flat('50,0 100,100 0,100')) },
    { id: 'right-triangle', name: 'Right Triangle', cat: 'Basic', draw: () => poly(flat('0,0 100,100 0,100')) },
    { id: 'parallelogram', name: 'Parallelogram', cat: 'Basic', draw: () => poly(flat('25,0 100,0 75,100 0,100')) },
    { id: 'trapezoid', name: 'Trapezoid', cat: 'Basic', draw: () => poly(flat('20,0 80,0 100,100 0,100')) },
    { id: 'diamond', name: 'Diamond', cat: 'Basic', draw: () => poly(flat('50,0 100,50 50,100 0,50')) },
    { id: 'pentagon', name: 'Pentagon', cat: 'Basic', draw: () => poly(regular(5)) },
    { id: 'hexagon', name: 'Hexagon', cat: 'Basic', draw: () => poly(flat('25,0 75,0 100,50 75,100 25,100 0,50')) },
    { id: 'octagon', name: 'Octagon', cat: 'Basic', draw: () => poly(flat('30,0 70,0 100,30 100,70 70,100 30,100 0,70 0,30')) },
    { id: 'decagon', name: 'Decagon', cat: 'Basic', draw: () => poly(regular(10)) },
    { id: 'plus', name: 'Plus', cat: 'Basic', draw: () => poly(flat('35,0 65,0 65,35 100,35 100,65 65,65 65,100 35,100 35,65 0,65 0,35 35,35')) },
    { id: 'frame', name: 'Frame', cat: 'Basic', draw: () => path('M0 0H100V100H0Z M14 14V86H86V14Z', ' fill-rule="evenodd"') },
    { id: 'donut', name: 'Donut', cat: 'Basic', draw: () => path('M0 50A50 50 0 1 0 100 50A50 50 0 1 0 0 50Z M26 50A24 24 0 1 1 74 50A24 24 0 1 1 26 50Z', ' fill-rule="evenodd"') },
    { id: 'folded-corner', name: 'Folded Corner', cat: 'Basic', draw: () => path('M0 0H100V78L78 100H0Z') + path('M78 100V78H100Z', ' fill="rgba(0,0,0,.18)"') },
    { id: 'cylinder', name: 'Cylinder', cat: 'Basic', draw: () => path('M0 12A50 12 0 0 1 100 12V88A50 12 0 0 1 0 88Z') + '<ellipse cx="50" cy="12" rx="50" ry="12" fill="rgba(255,255,255,.28)"/>' },
    { id: 'cube', name: 'Cube', cat: 'Basic', draw: () => poly(flat('0,25 75,25 75,100 0,100')) + poly(flat('0,25 25,0 100,0 75,25'), ' fill="rgba(255,255,255,.3)"') + poly(flat('75,25 100,0 100,75 75,100'), ' fill="rgba(0,0,0,.22)"') },

    // ---------------- Symbols ----------------
    { id: 'no-symbol', name: '"No" Symbol', cat: 'Symbols', draw: () => path('M0 50A50 50 0 1 0 100 50A50 50 0 1 0 0 50Z M17 50A33 33 0 1 1 83 50A33 33 0 1 1 17 50Z', ' fill-rule="evenodd"') + poly(flat('21,29 29,21 79,71 71,79')) },
    { id: 'teardrop', name: 'Teardrop', cat: 'Symbols', draw: () => path('M100 0V50A50 50 0 1 1 50 0Z') },
    { id: 'heart', name: 'Heart', cat: 'Symbols', draw: () => path('M50 96C12 68 0 47 0 29C0 12 12 0 27 0C38 0 46 7 50 16C54 7 62 0 73 0C88 0 100 12 100 29C100 47 88 68 50 96Z') },
    { id: 'lightning', name: 'Lightning Bolt', cat: 'Symbols', draw: () => poly(flat('40,0 76,0 56,36 82,36 24,100 40,54 16,54')) },
    { id: 'moon', name: 'Moon', cat: 'Symbols', draw: () => path('M70 0A50 50 0 1 0 70 100A28 50 0 1 1 70 0Z') },
    { id: 'cloud', name: 'Cloud', cat: 'Symbols', draw: () => path('M24 92A18 18 0 0 1 14 58A22 22 0 0 1 42 30A25 25 0 0 1 82 36A18 18 0 0 1 86 70A12 12 0 0 1 76 92Z') },
    { id: 'smiley', name: 'Smiley Face', cat: 'Symbols', draw: (c) => '<ellipse cx="50" cy="50" rx="50" ry="50"/>' +
        `<ellipse cx="34" cy="37" rx="6" ry="8" fill="${c.ink}" stroke="none"/><ellipse cx="66" cy="37" rx="6" ry="8" fill="${c.ink}" stroke="none"/>` +
        `<path d="M27 62Q50 84 73 62" fill="none" stroke="${c.ink}" stroke-width="3"/>` },
    { id: 'sun', name: 'Sun', cat: 'Symbols', draw: () => {
        let rays = '';
        for (let i = 0; i < 8; i++) {
          const a = i * Math.PI / 4;
          const tip = [50 + 50 * Math.cos(a), 50 + 50 * Math.sin(a)];
          const l = [50 + 32 * Math.cos(a - 0.22), 50 + 32 * Math.sin(a - 0.22)];
          const r = [50 + 32 * Math.cos(a + 0.22), 50 + 32 * Math.sin(a + 0.22)];
          rays += poly([l, tip, r]);
        }
        return rays + '<ellipse cx="50" cy="50" rx="25" ry="25"/>';
      } },

    // ---------------- Arrows ----------------
    { id: 'arrow-right', name: 'Right Arrow', cat: 'Arrows', draw: () => poly(flat('0,30 60,30 60,4 100,50 60,96 60,70 0,70')) },
    { id: 'arrow-left', name: 'Left Arrow', cat: 'Arrows', draw: () => poly(flat('100,30 40,30 40,4 0,50 40,96 40,70 100,70')) },
    { id: 'arrow-up', name: 'Up Arrow', cat: 'Arrows', draw: () => poly(flat('30,100 30,40 4,40 50,0 96,40 70,40 70,100')) },
    { id: 'arrow-down', name: 'Down Arrow', cat: 'Arrows', draw: () => poly(flat('30,0 70,0 70,60 96,60 50,100 4,60 30,60')) },
    { id: 'arrow-left-right', name: 'Left-Right Arrow', cat: 'Arrows', draw: () => poly(flat('0,50 25,8 25,30 75,30 75,8 100,50 75,92 75,70 25,70 25,92')) },
    { id: 'arrow-up-down', name: 'Up-Down Arrow', cat: 'Arrows', draw: () => poly(flat('50,0 92,25 70,25 70,75 92,75 50,100 8,75 30,75 30,25 8,25')) },
    { id: 'arrow-quad', name: 'Quad Arrow', cat: 'Arrows', draw: () => poly(flat('50,0 66,16 57,16 57,43 84,43 84,34 100,50 84,66 84,57 57,57 57,84 66,84 50,100 34,84 43,84 43,57 16,57 16,66 0,50 16,34 16,43 43,43 43,16 34,16')) },
    { id: 'chevron', name: 'Chevron', cat: 'Arrows', draw: () => poly(flat('0,0 72,0 100,50 72,100 0,100 28,50')) },
    { id: 'home-plate', name: 'Pentagon Arrow', cat: 'Arrows', draw: () => poly(flat('0,0 72,0 100,50 72,100 0,100')) },
    { id: 'arrow-notched', name: 'Notched Right Arrow', cat: 'Arrows', draw: () => poly(flat('0,25 60,25 60,0 100,50 60,100 60,75 0,75 16,50')) },

    // ---------------- Stars ----------------
    { id: 'star-4', name: '4-Point Star', cat: 'Stars & Banners', draw: () => poly(star(4, 0.38)) },
    { id: 'star-5', name: '5-Point Star', cat: 'Stars & Banners', draw: () => poly(star(5, 0.4)) },
    { id: 'star-6', name: '6-Point Star', cat: 'Stars & Banners', draw: () => poly(star(6, 0.55)) },
    { id: 'star-8', name: '8-Point Star', cat: 'Stars & Banners', draw: () => poly(star(8, 0.6)) },
    { id: 'explosion', name: 'Explosion', cat: 'Stars & Banners', draw: () => poly(star(12, 0.6, [1, 1, 0.82, 0.9, 0.95, 1.05, 0.78, 1, 1, 0.92, 0.85, 1.08])) },

    // ---------------- Callouts ----------------
    { id: 'callout-rect', name: 'Rectangular Callout', cat: 'Callouts', draw: () => path('M0 0H100V70H46L24 100L30 70H0Z') },
    { id: 'callout-oval', name: 'Oval Callout', cat: 'Callouts', draw: () => path('M38 78.8L16 100L55 79.8A50 40 0 1 0 38 78.8Z') },

    // ---------------- Flowchart ----------------
    { id: 'flow-terminator', name: 'Terminator', cat: 'Flowchart', draw: () => path('M22 0H78A22 50 0 0 1 78 100H22A22 50 0 0 1 22 0Z') },
    { id: 'flow-document', name: 'Document', cat: 'Flowchart', draw: () => path('M0 0H100V82C80 70 65 72 50 85C35 98 18 100 0 90Z') },
    { id: 'flow-predefined', name: 'Predefined Process', cat: 'Flowchart', draw: () => '<rect x="0" y="0" width="100" height="100"/><path d="M12 0V100M88 0V100" fill="none"/>' },
    { id: 'flow-manual-input', name: 'Manual Input', cat: 'Flowchart', draw: () => poly(flat('0,26 100,0 100,100 0,100')) },

    // ---------------- Lines ----------------
    { id: 'line', name: 'Line', cat: 'Lines', line: true, draw: () => '<path d="M0 50H100" fill="none"/>' },
    { id: 'arrow-line', name: 'Arrow Line', cat: 'Lines', line: true, draw: (c) => `<path d="M0 50H88" fill="none"/><polygon points="84,22 100,50 84,78" fill="${c.stroke}" stroke="none"/>` },

    // ---------------- Freeform (drawn by the user; points in o.path) ----------------
    { id: 'freeform', name: 'Freeform', cat: 'Freeform', hidden: true, draw: (c, o) => freeformPath(o.path, o.closed) }
  ];

  /** "x,y;x,y;…" (0–100 in both directions) → a smooth SVG path. */
  function parsePoints(str) {
    return String(str || '').split(';').map((p) => p.split(',').map(Number)).filter((p) => p.length === 2 && isFinite(p[0]) && isFinite(p[1]));
  }
  function freeformPath(str, closed) {
    const P = parsePoints(str);
    if (P.length < 2) return '';
    const f = (p) => `${r1(p[0])} ${r1(p[1])}`;
    let d = `M${f(P[0])}`;
    if (P.length === 2) d += `L${f(P[1])}`;
    else {
      // quadratic curves through the midpoints: smooth, and still passes near every point
      for (let i = 1; i < P.length - 1; i++) {
        const m = [(P[i][0] + P[i + 1][0]) / 2, (P[i][1] + P[i + 1][1]) / 2];
        d += `Q${f(P[i])} ${f(m)}`;
      }
      d += `L${f(P[P.length - 1])}`;
    }
    return closed ? `<path d="${d}Z"/>` : `<path d="${d}" fill="none"/>`;
  }

  const byId = Object.create(null);
  SHAPES.forEach((s) => { byId[s.id] = s; });

  const esc = (v) => String(v).replace(/"/g, '&quot;');

  /**
   * @param {string} id
   * @param {{w:number,h:number,fill:string,stroke:string,strokeWidth:number,noFill:boolean,noStroke:boolean}} o
   */
  function svg(id, o) {
    const s = byId[id] || byId.rectangle;
    const opt = Object.assign({ w: 120, h: 120, fill: '#f59e0b', stroke: '#1f1f1f', strokeWidth: 2, noFill: false, noStroke: false }, o || {});
    const w = Math.max(1, opt.w), h = Math.max(1, opt.h);
    const sw = opt.noStroke ? 0 : Math.max(0, +opt.strokeWidth || 0);
    const fill = s.line || opt.noFill ? 'none' : opt.fill;
    const stroke = sw ? opt.stroke : 'none';
    // pad the viewBox so thick strokes are not clipped at the frame edge
    const px = (sw / 2 + 0.5) * 100 / w;
    const py = (sw / 2 + 0.5) * 100 / h;
    const ink = stroke !== 'none' ? stroke : '#1f1f1f';
    const lineColor = s.line ? (opt.stroke || '#1f1f1f') : stroke;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${r1(w)}" height="${r1(h)}" viewBox="${r1(-px)} ${r1(-py)} ${r1(100 + 2 * px)} ${r1(100 + 2 * py)}" preserveAspectRatio="none">` +
      '<style>*{vector-effect:non-scaling-stroke;stroke-linejoin:round}</style>' +
      `<g fill="${esc(fill)}" stroke="${esc(s.line ? lineColor : stroke)}" stroke-width="${s.line ? Math.max(1, sw || 2) : sw}">` +
      s.draw({ fill, stroke: s.line ? lineColor : stroke, ink }, opt) + '</g></svg>';
  }

  function dataUrl(id, o) {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg(id, o));
  }

  function defaultSize(id) {
    const s = byId[id];
    if (!s) return { w: 140, h: 140 };
    if (s.line) return { w: 220, h: 24 };
    if (/arrow-(right|left|left-right)|home-plate|chevron|arrow-notched|flow-terminator/.test(id)) return { w: 180, h: 100 };
    if (/arrow-(up|down|up-down)/.test(id)) return { w: 100, h: 180 };
    if (/callout|flow-|round-rect|rectangle|snip-rect|parallelogram|trapezoid|cylinder/.test(id)) return { w: 180, h: 120 };
    return { w: 140, h: 140 };
  }

  const shown = SHAPES.filter((s) => !s.hidden);
  const api = {
    list: shown.map(({ id, name, cat, line }) => ({ id, name, cat, line: !!line })),
    categories: [...new Set(shown.map((s) => s.cat))],
    parsePoints,
    get: (id) => byId[id],
    svg, dataUrl, defaultSize
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.LbShapes = api;
})(typeof window !== 'undefined' ? window : globalThis);
