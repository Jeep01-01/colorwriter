/* Écritoire — freeform shapes: draw with a finger, pen or mouse.
 *
 * The drawing becomes an ordinary shape (img.lb-shape, data-shape="freeform")
 * whose points are stored, scaled to 0–100, in data-path. It can then be
 * resized, filled, outlined and colour-adjusted like every other shape, and
 * is saved as a picture in .docx and PDF.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const F = {};

  /** Ramer–Douglas–Peucker: keep the points that matter for the outline. */
  function simplify(points, eps) {
    if (points.length < 3) return points.slice();
    const sqSeg = (p, a, b) => {
      let x = a[0], y = a[1], dx = b[0] - x, dy = b[1] - y;
      if (dx || dy) {
        const t = Math.max(0, Math.min(1, ((p[0] - x) * dx + (p[1] - y) * dy) / (dx * dx + dy * dy)));
        x += dx * t; y += dy * t;
      }
      dx = p[0] - x; dy = p[1] - y;
      return dx * dx + dy * dy;
    };
    const keep = new Uint8Array(points.length);
    keep[0] = keep[points.length - 1] = 1;
    const stack = [[0, points.length - 1]];
    const e2 = eps * eps;
    while (stack.length) {
      const [a, b] = stack.pop();
      let max = 0, idx = -1;
      for (let i = a + 1; i < b; i++) {
        const d = sqSeg(points[i], points[a], points[b]);
        if (d > max) { max = d; idx = i; }
      }
      if (max > e2 && idx > 0) { keep[idx] = 1; stack.push([a, idx], [idx, b]); }
    }
    return points.filter((_, i) => keep[i]);
  }
  F.simplify = simplify;

  /**
   * Points in screen pixels → { path: "x,y;…" in 0–100, w, h } (w/h in px).
   * A straight line still gets a little height so it can be selected.
   */
  F.normalize = (points) => {
    const pts = simplify(points, 1.6);
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const [x, y] of pts) { minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); }
    const w = Math.max(maxX - minX, 1), h = Math.max(maxY - minY, 1);
    const sx = (x) => (maxX - minX < 4 ? 50 : ((x - minX) / w) * 100);
    const sy = (y) => (maxY - minY < 4 ? 50 : ((y - minY) / h) * 100);
    const path = pts.map(([x, y]) => `${Math.round(sx(x) * 10) / 10},${Math.round(sy(y) * 10) / 10}`).join(';');
    return { path, w: Math.max(w, 12), h: Math.max(h, 12), count: pts.length };
  };

  async function drawDialog() {
    const h = Lb.ui.h;
    const body = h('div', { class: 'ff-dlg' });
    const canvas = h('canvas', { class: 'ff-canvas' });
    const closedBox = h('input', { type: 'checkbox', checked: true });
    const undoBtn = h('button', { type: 'button', class: 'btn small' }, 'Undo stroke');
    const clearBtn = h('button', { type: 'button', class: 'btn small' }, 'Clear');
    body.append(
      h('p', { class: 'hint', style: { marginTop: '0' } }, 'Draw your shape in the box with a finger, pen or mouse. You can lift and draw again to add to it.'),
      canvas,
      h('div', { class: 'ff-tools' }, h('label', { class: 'check' }, closedBox, 'Closed shape (filled)'), undoBtn, clearBtn)
    );
    const strokes = []; // each stroke: [[x,y]…] in canvas px
    let cur = null;
    let ctx = null;
    const paint = () => {
      const g = ctx;
      g.clearRect(0, 0, canvas.width, canvas.height);
      const all = strokes.concat(cur ? [cur] : []);
      const pts = all.flat();
      if (!pts.length) {
        g.fillStyle = '#9a9aa2'; g.font = '14px sans-serif'; g.textAlign = 'center';
        g.fillText('Draw here', canvas.width / 2 / devicePixelRatio, canvas.height / 2 / devicePixelRatio);
        return;
      }
      g.lineJoin = 'round'; g.lineCap = 'round';
      g.beginPath();
      pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])));
      if (closedBox.checked && pts.length > 2) { g.closePath(); g.fillStyle = 'rgba(245,158,11,.35)'; g.fill(); }
      g.strokeStyle = '#b45309'; g.lineWidth = 2.5; g.stroke();
    };
    const res = await Lb.ui.modal({
      title: 'Freeform Shape', width: 560, body,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Insert', value: 'ok', primary: true }],
      validate: (v) => {
        if (v === 'ok' && strokes.flat().length < 3) { Lb.ui.toast('Draw a shape first.'); return false; }
        return true;
      },
      init: () => {
        const dpr = window.devicePixelRatio || 1;
        const W = canvas.clientWidth || 480, H = canvas.clientHeight || 300;
        canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
        ctx = canvas.getContext('2d');
        ctx.scale(dpr, dpr);
        paint();
        const at = (e) => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
        canvas.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          canvas.setPointerCapture(e.pointerId);
          cur = [at(e)];
          paint();
        });
        canvas.addEventListener('pointermove', (e) => {
          if (!cur) return;
          const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
          for (const ev of evs) {
            const p = at(ev);
            const last = cur[cur.length - 1];
            if (Math.hypot(p[0] - last[0], p[1] - last[1]) >= 1.5) cur.push(p);
          }
          paint();
        });
        const end = () => { if (cur && cur.length) strokes.push(cur); cur = null; paint(); };
        canvas.addEventListener('pointerup', end);
        canvas.addEventListener('pointercancel', end);
        undoBtn.addEventListener('click', () => { strokes.pop(); paint(); });
        clearBtn.addEventListener('click', () => { strokes.length = 0; paint(); });
        closedBox.addEventListener('change', paint);
      }
    });
    if (res.value !== 'ok') return null;
    return { points: strokes.flat(), closed: closedBox.checked };
  }

  F.insert = async () => {
    Lb.sel.save();
    const saved = Lb.savedRange ? Lb.savedRange.cloneRange() : null;
    const v = await drawDialog();
    if (!v) return;
    const n = F.normalize(v.points);
    // fit the text width of the page
    const m = Lb.settings.margins;
    const maxW = Lb.pageW() - Lb.mm(m.left + m.right);
    const k = Math.min(1, maxW / n.w, 500 / n.h);
    const w = Math.round(n.w * k), hh = Math.round(n.h * k);
    const img = document.createElement('img');
    img.className = 'lb-shape';
    img.alt = 'Freeform';
    img.dataset.shape = 'freeform';
    img.dataset.path = n.path;
    img.dataset.closed = v.closed ? '1' : '0';
    img.dataset.fill = '#f59e0b';
    img.dataset.stroke = '#1f1f1f';
    img.dataset.sw = v.closed ? '2' : '3';
    img.style.width = w + 'px';
    img.style.height = hh + 'px';
    Lb.objects.renderShape(img, w, hh);
    if (saved) Lb.savedRange = saved;
    Lb.objects.insertNode(img);
  };

  Lb.register('freeform', () => F.insert());
  Lb.freeform = F;
})();
