/* Écritoire — .docx → HTML reader.
 * Parses WordprocessingML with JSZip + DOMParser and produces HTML that the
 * editor understands, keeping direct and style-based formatting:
 * fonts, sizes, colours, highlight, bold/italic/underline/strike, super/sub,
 * alignment, spacing, line height, indents, headings, numbered and bulleted
 * lists (with nesting), tables (merged cells, shading), images and page breaks.
 */
(function (root) {
  'use strict';

  const HIGHLIGHT = {
    yellow: '#ffff00', green: '#00ff00', cyan: '#00ffff', magenta: '#ff00ff', blue: '#0000ff',
    red: '#ff0000', darkBlue: '#000080', darkCyan: '#008080', darkGreen: '#008000',
    darkMagenta: '#800080', darkRed: '#800000', darkYellow: '#808000', darkGray: '#808080',
    lightGray: '#c0c0c0', black: '#000000', white: '#ffffff'
  };
  const NUMFMT = {
    decimal: 'decimal', decimalZero: 'decimal', lowerLetter: 'lower-alpha', upperLetter: 'upper-alpha',
    lowerRoman: 'lower-roman', upperRoman: 'upper-roman', ordinal: 'decimal', cardinalText: 'decimal'
  };
  const IMG_MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml', webp: 'image/webp', tif: 'image/tiff', tiff: 'image/tiff' };

  const twipToPt = (v) => Math.round((v / 20) * 100) / 100;
  const twipToMm = (v) => Math.round((v / 56.6929) * 10) / 10;
  // paper sizes Écritoire supports (portrait, mm)
  const PAPERS = { A4: [210, 297], A5: [148, 210], A3: [297, 420], Letter: [215.9, 279.4] };
  const paperFor = (w, h) => {
    const a = Math.min(w, h), b = Math.max(w, h);
    for (const [k, [pw, ph]] of Object.entries(PAPERS)) if (Math.abs(pw - a) < 3 && Math.abs(ph - b) < 3) return k;
    return null;
  };
  const emuToPx = (v) => Math.round(v / 9525);

  // ---------- tiny XML helpers (namespace-prefix agnostic) ----------
  const kids = (el, name) => {
    const out = [];
    if (!el) return out;
    for (let c = el.firstElementChild; c; c = c.nextElementSibling) if (!name || c.localName === name) out.push(c);
    return out;
  };
  const kid = (el, name) => {
    if (!el) return null;
    for (let c = el.firstElementChild; c; c = c.nextElementSibling) if (c.localName === name) return c;
    return null;
  };
  const desc = (el, name) => {
    if (!el) return null;
    const list = el.getElementsByTagName('*');
    for (let i = 0; i < list.length; i++) if (list[i].localName === name) return list[i];
    return null;
  };
  const attr = (el, name) => {
    if (!el) return null;
    for (const a of el.attributes) if (a.localName === name) return a.value;
    return null;
  };
  const val = (el) => attr(el, 'val');

  /**
   * A floating picture (wp:anchor): how text wraps around it and where it is.
   * The position is kept as Word states it (data-ah, data-av: "relativeFrom:offset-px"
   * or "relativeFrom:align:value"); the editor turns it into a place on the page
   * once the document is laid out (wrap.js).
   */
  function anchorAttrs(an) {
    const behind = /^(1|true|on)$/i.test(attr(an, 'behindDoc') || '');
    let wrap = null;
    for (const k of kids(an)) {
      if (k.localName === 'wrapSquare') wrap = 'square';
      else if (k.localName === 'wrapTight' || k.localName === 'wrapThrough') wrap = 'tight';
      else if (k.localName === 'wrapTopAndBottom') wrap = 'topbottom';
      else if (k.localName === 'wrapNone') wrap = behind ? 'behind' : 'front';
    }
    if (!wrap) wrap = behind ? 'behind' : 'front';
    const pos = (p, def) => {
      if (!p) return def + ':0';
      const rel = attr(p, 'relativeFrom') || def;
      const off = kid(p, 'posOffset'), al = kid(p, 'align');
      if (al) return rel + ':align:' + al.textContent.trim();
      return rel + ':' + (off ? emuToPx(+off.textContent || 0) : 0);
    };
    let out = ` data-wrap="${wrap}" data-ah="${esc(pos(kid(an, 'positionH'), 'column'))}" data-av="${esc(pos(kid(an, 'positionV'), 'paragraph'))}"`;
    const rh = +attr(an, 'relativeHeight');
    if (rh) out += ` data-z="${rh}"`;
    return out;
  }
  const onOff = (el) => {
    if (!el) return undefined;
    const v = val(el);
    return !(v === '0' || v === 'false' || v === 'off' || v === 'none');
  };
  const parseXml = (s) => new DOMParser().parseFromString(s, 'application/xml');
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ---------- property parsing ----------
  function parseRPr(rPr, theme) {
    const p = {};
    if (!rPr) return p;
    const b = kid(rPr, 'b'); if (b) p.b = onOff(b);
    const i = kid(rPr, 'i'); if (i) p.i = onOff(i);
    const u = kid(rPr, 'u'); if (u) p.u = onOff(u);
    const st = kid(rPr, 'strike') || kid(rPr, 'dstrike'); if (st) p.s = onOff(st);
    const caps = kid(rPr, 'caps'); if (caps) p.caps = onOff(caps);
    const sc = kid(rPr, 'smallCaps'); if (sc) p.smallCaps = onOff(sc);
    const vanish = kid(rPr, 'vanish'); if (vanish) p.hidden = onOff(vanish);
    const color = kid(rPr, 'color');
    if (color) { const v = val(color); if (v && v !== 'auto') p.color = '#' + v.toLowerCase(); else if (v === 'auto') p.color = null; }
    const sz = kid(rPr, 'sz'); if (sz && val(sz)) p.size = +val(sz) / 2;
    const fonts = kid(rPr, 'rFonts');
    if (fonts) {
      const f = attr(fonts, 'ascii') || attr(fonts, 'hAnsi') || attr(fonts, 'cs') || attr(fonts, 'eastAsia');
      const th = attr(fonts, 'asciiTheme') || attr(fonts, 'hAnsiTheme');
      if (f) p.font = f;
      else if (th && theme) p.font = /major/i.test(th) ? theme.major : theme.minor;
    }
    const hl = kid(rPr, 'highlight'); if (hl && HIGHLIGHT[val(hl)]) p.highlight = HIGHLIGHT[val(hl)];
    const shd = kid(rPr, 'shd');
    if (shd && !p.highlight) { const f = attr(shd, 'fill'); if (f && f !== 'auto' && !/^0{0}ffffff$/i.test(f)) p.highlight = '#' + f.toLowerCase(); }
    const va = kid(rPr, 'vertAlign'); if (va) { const v = val(va); if (v === 'superscript') p.sup = true; else if (v === 'subscript') p.sub = true; }
    const sp = kid(rPr, 'spacing'); if (sp && val(sp)) p.spacing = twipToPt(+val(sp));
    return p;
  }

  function parsePPr(pPr) {
    const p = {};
    if (!pPr) return p;
    const ps = kid(pPr, 'pStyle'); if (ps) p.styleId = val(ps);
    const jc = kid(pPr, 'jc');
    if (jc) {
      const v = val(jc);
      p.align = { left: 'left', start: 'left', center: 'center', right: 'right', end: 'right', both: 'justify', distribute: 'justify' }[v] || undefined;
    }
    const sp = kid(pPr, 'spacing');
    if (sp) {
      if (attr(sp, 'before') != null) p.before = twipToPt(+attr(sp, 'before'));
      if (attr(sp, 'after') != null) p.after = twipToPt(+attr(sp, 'after'));
      if (attr(sp, 'line') != null) {
        const rule = attr(sp, 'lineRule') || 'auto';
        const line = +attr(sp, 'line');
        if (rule === 'auto') p.line = { mult: Math.round((line / 240) * 100) / 100 };
        else p.line = { pt: twipToPt(line) };
      }
    }
    const ind = kid(pPr, 'ind');
    if (ind) {
      const l = attr(ind, 'left') ?? attr(ind, 'start');
      const r = attr(ind, 'right') ?? attr(ind, 'end');
      if (l != null) p.indLeft = twipToPt(+l);
      if (r != null) p.indRight = twipToPt(+r);
      if (attr(ind, 'firstLine') != null) p.firstLine = twipToPt(+attr(ind, 'firstLine'));
      if (attr(ind, 'hanging') != null) p.firstLine = -twipToPt(+attr(ind, 'hanging'));
    }
    const pb = kid(pPr, 'pageBreakBefore'); if (pb) p.pageBreakBefore = onOff(pb);
    const numPr = kid(pPr, 'numPr');
    if (numPr) {
      const n = kid(numPr, 'numId'); const l = kid(numPr, 'ilvl');
      p.num = { numId: n ? val(n) : null, ilvl: l ? +val(l) : 0 };
    }
    const shd = kid(pPr, 'shd');
    if (shd) { const f = attr(shd, 'fill'); if (f && f !== 'auto') p.shade = '#' + f.toLowerCase(); }
    return p;
  }

  const merge = (...objs) => {
    const out = {};
    for (const o of objs) if (o) for (const k of Object.keys(o)) if (o[k] !== undefined) out[k] = o[k];
    return out;
  };

  // ---------- main reader ----------
  async function read(input) {
    if (!root.JSZip) throw new Error('JSZip is not loaded');
    const zip = await root.JSZip.loadAsync(input);
    const warnings = new Set();
    const file = (p) => zip.file(p);
    const text = async (p) => (file(p) ? file(p).async('string') : null);

    const docXmlStr = await text('word/document.xml');
    if (!docXmlStr) throw new Error('This file is not a valid .docx document (word/document.xml missing).');
    const doc = parseXml(docXmlStr);

    // theme fonts
    const theme = { major: 'Calibri Light', minor: 'Calibri' };
    const themeStr = await text('word/theme/theme1.xml');
    if (themeStr) {
      const t = parseXml(themeStr);
      const maj = desc(t, 'majorFont'); const min = desc(t, 'minorFont');
      const ml = maj && kid(maj, 'latin'); const nl = min && kid(min, 'latin');
      if (ml && attr(ml, 'typeface')) theme.major = attr(ml, 'typeface');
      if (nl && attr(nl, 'typeface')) theme.minor = attr(nl, 'typeface');
    }

    // styles
    const styles = {};
    let defaults = { r: { font: theme.minor, size: 11 }, p: {} };
    let defaultParaStyle = null;
    const stylesStr = await text('word/styles.xml');
    if (stylesStr) {
      const s = parseXml(stylesStr);
      const dd = desc(s, 'docDefaults');
      if (dd) {
        const rpd = desc(dd, 'rPrDefault'); const ppd = desc(dd, 'pPrDefault');
        defaults = { r: merge(defaults.r, parseRPr(rpd && kid(rpd, 'rPr'), theme)), p: parsePPr(ppd && kid(ppd, 'pPr')) };
      }
      for (const st of desc(s, 'styles') ? kids(desc(s, 'styles'), 'style') : kids(s.documentElement, 'style')) {
        const id = attr(st, 'styleId');
        const nameEl = kid(st, 'name');
        const based = kid(st, 'basedOn');
        styles[id] = {
          id, type: attr(st, 'type'),
          name: nameEl ? (val(nameEl) || '').toLowerCase() : '',
          basedOn: based ? val(based) : null,
          r: parseRPr(kid(st, 'rPr'), theme),
          p: parsePPr(kid(st, 'pPr'))
        };
        if (attr(st, 'type') === 'paragraph' && (attr(st, 'default') === '1' || attr(st, 'default') === 'true')) defaultParaStyle = id;
      }
    }
    const resolved = {};
    function resolveStyle(id, depth) {
      if (!id || !styles[id]) return { r: {}, p: {}, name: '' };
      if (resolved[id]) return resolved[id];
      const st = styles[id];
      const base = depth > 20 ? { r: {}, p: {} } : resolveStyle(st.basedOn, (depth || 0) + 1);
      const p = merge(base.p, st.p); delete p.styleId;
      const out = { r: merge(base.r, st.r), p, name: st.name };
      resolved[id] = out;
      return out;
    }

    // numbering
    const abstract = {}; const nums = {};
    const numStr = await text('word/numbering.xml');
    if (numStr) {
      const n = parseXml(numStr);
      const all = n.getElementsByTagName('*');
      for (let i = 0; i < all.length; i++) {
        const el = all[i];
        if (el.localName === 'abstractNum') {
          const levels = {};
          for (const lvl of kids(el, 'lvl')) {
            const fmt = val(kid(lvl, 'numFmt')) || 'decimal';
            const txt = val(kid(lvl, 'lvlText')) || '';
            const start = kid(lvl, 'start') ? +val(kid(lvl, 'start')) : 1;
            const lp = parsePPr(kid(lvl, 'pPr'));
            levels[+attr(lvl, 'ilvl')] = { fmt, txt, start, indLeft: lp.indLeft };
          }
          abstract[attr(el, 'abstractNumId')] = levels;
        } else if (el.localName === 'num') {
          const a = kid(el, 'abstractNumId');
          nums[attr(el, 'numId')] = a ? val(a) : null;
        }
      }
    }
    function listInfo(numId, ilvl) {
      const levels = abstract[nums[numId]] || {};
      const l = levels[ilvl] || levels[0] || { fmt: 'bullet', txt: '•', start: 1 };
      if (l.fmt === 'bullet') {
        const c = l.txt || '';
        let style = 'disc';
        if (/^[o◦○]$/.test(c)) style = 'circle';
        else if (/^[▪■◾◼§]$/.test(c)) style = 'square';
        else if (/^[–—\-]$/.test(c)) style = 'dash';
        else if (/^[✓✔]$/.test(c)) style = 'check';
        else if (/^[➢➤►]$/.test(c)) style = 'arrow';
        return { tag: 'ul', fmt: style, start: 1, indLeft: l.indLeft };
      }
      if (l.fmt === 'none') return { tag: 'ul', fmt: 'none', start: 1, indLeft: l.indLeft };
      return { tag: 'ol', fmt: NUMFMT[l.fmt] || 'decimal', start: l.start || 1, indLeft: l.indLeft };
    }

    // relationships (images, hyperlinks)
    const rels = {};
    const relStr = await text('word/_rels/document.xml.rels');
    if (relStr) {
      for (const r of kids(parseXml(relStr).documentElement, 'Relationship')) {
        rels[r.getAttribute('Id')] = { target: r.getAttribute('Target'), external: r.getAttribute('TargetMode') === 'External', type: r.getAttribute('Type') || '' };
      }
    }
    const imageCache = {};
    async function imageSrc(rid) {
      const rel = rels[rid];
      if (!rel || rel.external) return null;
      let target = rel.target.replace(/^\//, '');
      if (!target.startsWith('word/')) target = 'word/' + target;
      target = target.replace(/\/[^/]+\/\.\.\//g, '/');
      if (imageCache[target] !== undefined) return imageCache[target];
      const f = file(target);
      if (!f) { imageCache[target] = null; return null; }
      const ext = (target.split('.').pop() || '').toLowerCase();
      const mime = IMG_MIME[ext];
      if (!mime) { warnings.add('Some images use a format (' + ext.toUpperCase() + ') that cannot be displayed and were skipped.'); imageCache[target] = null; return null; }
      const b64 = await f.async('base64');
      imageCache[target] = `data:${mime};base64,${b64}`;
      return imageCache[target];
    }

    // footnotes and endnotes (both become Écritoire footnotes)
    const notes = { footnote: {}, endnote: {} };
    for (const kind of ['footnote', 'endnote']) {
      const str = await text(`word/${kind}s.xml`);
      if (!str) continue;
      for (const n of parseXml(str).getElementsByTagName('*')) {
        if (n.localName !== kind) continue;
        const type = attr(n, 'type');
        if (type && type !== 'normal') continue; // separators
        notes[kind][attr(n, 'id')] = kids(n, 'p').map((p) => noteText(p).trim()).filter(Boolean).join('\n');
      }
    }

    const media = {}; // video files stored by Écritoire: name -> bytes

    // ---------- conversion ----------
    const baseline = { font: 'Calibri', size: 11 };
    const listStack = [];          // {tag, fmt, numId, level, el}
    const counters = {};           // numId -> [count per level]
    let out = [];                  // array of HTML strings (top level)

    function runStyle(r, isHeading) {
      const css = [];
      if (r.font && (isHeading || r.font !== baseline.font)) css.push(`font-family:'${r.font.replace(/'/g, '')}'`);
      if (r.size && (isHeading || r.size !== baseline.size)) css.push(`font-size:${r.size}pt`);
      if (r.b) css.push('font-weight:bold'); else if (isHeading) css.push('font-weight:normal');
      if (r.i) css.push('font-style:italic');
      const deco = [r.u ? 'underline' : '', r.s ? 'line-through' : ''].filter(Boolean).join(' ');
      if (deco) css.push('text-decoration:' + deco);
      if (r.color) css.push('color:' + r.color);
      if (r.highlight) css.push('background-color:' + r.highlight);
      if (r.sup) css.push('vertical-align:super;font-size:smaller');
      if (r.sub) css.push('vertical-align:sub;font-size:smaller');
      if (r.caps) css.push('text-transform:uppercase');
      if (r.smallCaps) css.push('font-variant:small-caps');
      if (r.spacing) css.push(`letter-spacing:${r.spacing}pt`);
      return css.join(';');
    }

    function paraStyle(p, isList) {
      const css = [];
      if (p.align) css.push('text-align:' + p.align);
      if (p.before != null) css.push(`margin-top:${p.before}pt`);
      if (p.after != null) css.push(`margin-bottom:${p.after}pt`);
      if (p.line) css.push(p.line.mult ? `line-height:${p.line.mult}` : `line-height:${p.line.pt}pt`);
      if (!isList) {
        if (p.indLeft) css.push(`margin-left:${p.indLeft}pt`);
        if (p.indRight) css.push(`margin-right:${p.indRight}pt`);
        if (p.firstLine) css.push(`text-indent:${p.firstLine}pt`);
      }
      if (p.shade) css.push('background-color:' + p.shade);
      return css.join(';');
    }

    // Converts the inline content of a paragraph into a list of "segments":
    // strings of HTML, or {pageBreak:true}
    async function inlineContent(container, pStyle, isHeading, segs) {
      for (const el of kids(container)) {
        const ln = el.localName;
        if (ln === 'r') await runContent(el, pStyle, isHeading, segs);
        else if (ln === 'hyperlink') {
          const rid = attr(el, 'id');
          const href = rid && rels[rid] && rels[rid].external ? rels[rid].target : null;
          const inner = [];
          await inlineContent(el, pStyle, isHeading, inner);
          const html = inner.filter((x) => typeof x === 'string').join('');
          segs.push(href ? `<a href="${esc(href)}">${html}</a>` : html);
        } else if (['ins', 'smartTag', 'customXml', 'fldSimple', 'sdt', 'sdtContent', 'dir', 'bdo', 'moveTo'].includes(ln)) {
          await inlineContent(ln === 'sdt' ? (kid(el, 'sdtContent') || el) : el, pStyle, isHeading, segs);
        } else if (ln === 'oMath' || ln === 'oMathPara') {
          segs.push(esc(el.textContent));
          warnings.add('Equations were imported as plain text.');
        }
      }
    }

    async function runContent(r, pStyle, isHeading, segs) {
      const rPr = kid(r, 'rPr');
      const direct = parseRPr(rPr, theme);
      const rs = kid(rPr, 'rStyle');
      const charStyle = rs ? resolveStyle(val(rs)).r : {};
      const props = merge(defaults.r, pStyle.r, charStyle, direct);
      if (props.hidden) return;
      const css = runStyle(props, isHeading);
      let buf = '';
      const flush = () => {
        if (!buf) return;
        segs.push(css ? `<span style="${css}">${buf}</span>` : buf);
        buf = '';
      };
      for (const c of kids(r)) {
        switch (c.localName) {
          case 't': buf += esc(c.textContent); break;
          case 'tab': buf += '<span class="lb-tab">\t</span>'; break;
          case 'noBreakHyphen': buf += '‑'; break;
          case 'softHyphen': break;
          case 'sym': {
            const ch = attr(c, 'char');
            if (ch) { let code = parseInt(ch, 16); if (code >= 0xF000) code -= 0xF000; buf += esc(String.fromCharCode(code)); }
            break;
          }
          case 'cr': buf += '<br>'; break;
          case 'footnoteReference': case 'endnoteReference': {
            const kind = c.localName === 'footnoteReference' ? 'footnote' : 'endnote';
            const note = notes[kind][attr(c, 'id')];
            if (note != null) { flush(); segs.push(`<sup class="lb-fn" contenteditable="false" data-note="${esc(note)}">#</sup>`); }
            break;
          }
          case 'br': {
            const t = attr(c, 'type');
            if (t === 'page') { flush(); segs.push({ pageBreak: true }); }
            else buf += '<br>';
            break;
          }
          case 'drawing': {
            flush();
            // a video saved by Écritoire: its still picture describes the stored file
            const dp = desc(c, 'docPr');
            const vm = /^ecritoire-video:([\w.-]+)$/.exec((dp && attr(dp, 'descr')) || '');
            if (vm && file('word/media/' + vm[1])) {
              const vb = desc(c, 'blip');
              const vext = desc(c, 'extent');
              const vrid = vb && attr(vb, 'embed');
              const poster = vrid ? await imageSrc(vrid) : null;
              media[vm[1]] = await file('word/media/' + vm[1]).async('uint8array');
              const vw = vext ? emuToPx(+attr(vext, 'cx')) : 320; const vh = vext ? emuToPx(+attr(vext, 'cy')) : 180;
              segs.push(`<span class="lb-video" contenteditable="false" data-lock="1" data-file="${esc(vm[1])}" style="width:${vw}px;height:${vh}px"><video${poster ? ` poster="${poster}"` : ''} controls playsinline preload="metadata"></video></span>`);
              break;
            }
            const blip = desc(c, 'blip');
            const ext = desc(c, 'extent');
            const rid = blip && (attr(blip, 'embed') || attr(blip, 'link'));
            if (rid) {
              const src = await imageSrc(rid);
              if (src) {
                const w = ext ? emuToPx(+attr(ext, 'cx')) : 0; const h = ext ? emuToPx(+attr(ext, 'cy')) : 0;
                const size = w && h ? ` style="width:${w}px;height:${h}px"` : '';
                // a shape saved by Écritoire: its settings make it editable again
                let cls = 'lb-picture', data = '';
                const sm = /^ecritoire-shape:([A-Za-z0-9+/=]+)$/.exec((dp && attr(dp, 'descr')) || '');
                if (sm) {
                  try {
                    const o = JSON.parse(decodeURIComponent(escape(atob(sm[1]))));
                    if (o && o.shape) {
                      cls = 'lb-shape';
                      for (const [k, v] of Object.entries(o)) if (/^[a-z]+$/.test(k) && v != null) data += ` data-${k}="${esc(String(v))}"`;
                      data += ' data-restore="1"';
                    }
                  } catch (_) { /* keep it as a picture */ }
                }
                const an = kid(c, 'anchor');
                if (an) data += anchorAttrs(an);
                segs.push(`<img class="${cls}" src="${src}"${size}${data} alt="">`);
              }
            } else {
              const tx = desc(c, 'txbxContent');
              if (tx) segs.push(`<span class="lb-textbox">${esc(tx.textContent)}</span>`);
              warnings.add('Some drawing objects (text boxes, charts or drawing shapes) were simplified.');
            }
            break;
          }
          case 'pict': case 'object': {
            flush();
            const im = desc(c, 'imagedata');
            const rid = im && attr(im, 'id');
            if (rid) {
              const src = await imageSrc(rid);
              if (src) segs.push(`<img class="lb-picture" src="${src}" alt="">`);
            }
            break;
          }
          case 'AlternateContent': {
            flush();
            const fb = kid(c, 'Fallback') || kid(c, 'Choice');
            if (fb) { const fake = { localName: 'r' }; void fake; await runContent(fb, pStyle, isHeading, segs); }
            break;
          }
          default: break;
        }
      }
      flush();
    }

    function closeLists(toLevel) {
      while (listStack.length && listStack[listStack.length - 1].level > toLevel) listStack.pop();
    }

    // returns list of top-level html strings (or appends into list structure)
    async function paragraph(pEl, ctx) {
      const pPr = kid(pEl, 'pPr');
      const direct = parsePPr(pPr);
      const styleId = direct.styleId || defaultParaStyle;
      const st = resolveStyle(styleId);
      const pp = merge(defaults.p, st.p, direct);
      const num = direct.num || st.p.num;
      const name = (st.name || '').toLowerCase();
      let tag = 'p';
      let hm = /^heading (\d)$/.exec(name) || /^Heading(\d)$/.exec(styleId || '');
      if (hm && +hm[1] >= 1 && +hm[1] <= 6) tag = 'h' + hm[1];
      else if (name === 'title') tag = 'h1';
      else if (name === 'subtitle') tag = 'h2';
      else if (name === 'quote' || name === 'intense quote') tag = 'blockquote';
      const isHeading = /^h\d$/.test(tag);
      const pStyle = { r: st.r };

      const segs = [];
      await inlineContent(pEl, pStyle, isHeading, segs);

      // paragraph mark formatting (for empty paragraphs)
      const markProps = merge(defaults.r, st.r, parseRPr(pPr && kid(pPr, 'rPr'), theme));

      let isList = !!(num && num.numId && num.numId !== '0' && nums[num.numId] !== undefined);
      // outline numbering without a visible number (common on headings) is not a list
      if (isList && listInfo(num.numId, num.ilvl).fmt === 'none') isList = false;
      const style = paraStyle(pp, isList);
      const nodes = [];
      let cur = [];
      const emit = () => {
        let inner = cur.join('');
        if (!inner.replace(/<[^>]+>/g, '').trim() && !/<img|<br/.test(inner)) {
          const mcss = runStyle(markProps, isHeading);
          inner = mcss ? `<span style="${mcss}"><br></span>` : '<br>';
        }
        nodes.push({ html: inner });
        cur = [];
      };
      for (const s of segs) {
        if (typeof s === 'string') cur.push(s);
        else if (s.pageBreak) { if (cur.length) emit(); nodes.push({ pageBreak: true }); }
      }
      if (cur.length || !nodes.length || nodes[nodes.length - 1].pageBreak) emit();

      const html = [];
      if (pp.pageBreakBefore && !ctx.inTable) html.push(PAGE_BREAK);

      if (isList && !ctx.inTable) {
        if (pp.pageBreakBefore) { listStack.length = 0; ctx.pushTop(PAGE_BREAK); html.length = 0; }
        const info = listInfo(num.numId, num.ilvl);
        // visual nesting level: list level, or inferred from the indent when a
        // different list definition is used for sub-items (e.g. "List Bullet 2")
        const ind = direct.indLeft != null ? direct.indLeft : (info.indLeft != null ? info.indLeft : st.p.indLeft);
        let level = num.ilvl || 0;
        const prev = listStack[listStack.length - 1];
        if (prev && prev.numId !== num.numId && ind != null && prev.ind != null && ind > prev.ind + 9) level = prev.level + 1;
        // counters for continued numbering
        const cnt = counters[num.numId] = counters[num.numId] || [];
        cnt[level] = (cnt[level] || 0) + 1;
        for (let k = level + 1; k < cnt.length; k++) cnt[k] = 0;
        closeLists(level);
        let top = listStack[listStack.length - 1];
        const sameList = top && top.fmt === info.fmt && (top.numId === num.numId || nums[top.numId] === nums[num.numId] || info.tag === 'ul');
        if (top && top.level === level && !sameList) { listStack.pop(); top = listStack[listStack.length - 1]; }
        if (!top || top.level < level) {
          const startAttr = info.tag === 'ol' && cnt[level] > 1 ? ` start="${cnt[level] + (info.start - 1)}"` : (info.tag === 'ol' && info.start > 1 ? ` start="${info.start}"` : '');
          const list = { tag: info.tag, fmt: info.fmt, numId: num.numId, level, ind, items: [], open: `<${info.tag} data-list="${info.fmt}" style="list-style-type:${cssListType(info.fmt)}"${startAttr}>` };
          if (top && top.items.length) top.items[top.items.length - 1].children.push(list);
          else ctx.pushTop(list);
          listStack.push(list);
          top = list;
        }
        for (const n of nodes) {
          if (n.pageBreak) continue;
          top.items.push({ html: n.html, style, children: [] });
        }
        return html; // list items are attached to list objects
      }
      if (!ctx.inTable) listStack.length = 0;

      for (const n of nodes) {
        if (n.pageBreak) html.push(PAGE_BREAK);
        else html.push(`<${tag}${style ? ` style="${style}"` : ''}>${n.html}</${tag}>`);
      }
      return html;
    }

    async function table(tbl) {
      const grid = kids(kid(tbl, 'tblGrid'), 'gridCol').map((g) => Math.round((+attr(g, 'w') || 0) / 15));
      const rows = kids(tbl, 'tr');
      // matrix of cells with grid positions
      const matrix = rows.map((tr) => {
        let col = 0;
        const cells = [];
        const tcs = [];
        for (const c of kids(tr)) {
          if (c.localName === 'tc') tcs.push(c);
          else if (c.localName === 'sdt' || c.localName === 'customXml') {
            const content = kid(c, 'sdtContent') || c;
            for (const t of kids(content, 'tc')) tcs.push(t);
          }
        }
        for (const tc of tcs) {
          const tcPr = kid(tc, 'tcPr');
          const span = tcPr && kid(tcPr, 'gridSpan') ? +val(kid(tcPr, 'gridSpan')) || 1 : 1;
          const vm = tcPr && kid(tcPr, 'vMerge');
          const vmerge = vm ? (val(vm) === 'restart' ? 'restart' : 'continue') : null;
          const shd = tcPr && kid(tcPr, 'shd');
          const fill = shd && attr(shd, 'fill') && attr(shd, 'fill') !== 'auto' ? '#' + attr(shd, 'fill').toLowerCase() : null;
          const va = tcPr && kid(tcPr, 'vAlign') ? val(kid(tcPr, 'vAlign')) : null;
          cells.push({ tc, col, span, vmerge, fill, valign: va, rowspan: 1 });
          col += span;
        }
        return cells;
      });
      // compute rowspans
      matrix.forEach((cells, r) => {
        for (const cell of cells) {
          if (cell.vmerge !== 'restart') continue;
          let k = r + 1;
          while (k < matrix.length) {
            const below = matrix[k].find((c) => c.col === cell.col);
            if (below && below.vmerge === 'continue') { cell.rowspan++; below.skip = true; k++; } else break;
          }
        }
      });
      let html = '<table class="lb-table"><colgroup>';
      for (const w of grid) html += `<col style="width:${w}px">`;
      html += '</colgroup><tbody>';
      for (const cells of matrix) {
        html += '<tr>';
        for (const cell of cells) {
          if (cell.skip) continue;
          const inner = await body(kids(cell.tc), { inTable: true });
          const css = [];
          if (cell.fill) css.push('background-color:' + cell.fill);
          if (cell.valign) css.push('vertical-align:' + (cell.valign === 'center' ? 'middle' : cell.valign));
          html += `<td${cell.span > 1 ? ` colspan="${cell.span}"` : ''}${cell.rowspan > 1 ? ` rowspan="${cell.rowspan}"` : ''}${css.length ? ` style="${css.join(';')}"` : ''}>${inner || '<p><br></p>'}</td>`;
        }
        html += '</tr>';
      }
      return html + '</tbody></table>';
    }

    function renderList(list) {
      let h = list.open;
      for (const it of list.items) {
        h += `<li${it.style ? ` style="${it.style}"` : ''}>${it.html}${it.children.map(renderList).join('')}</li>`;
      }
      return h + `</${list.tag}>`;
    }

    let pendingTocTitle = null;
    function tocStyle(pEl) {
      const pPr = kid(pEl, 'pPr');
      const ps = pPr && kid(pPr, 'pStyle');
      if (!ps) return null;
      const id = val(ps) || '';
      const name = ((styles[id] && styles[id].name) || id).toLowerCase();
      if (/^toc ?heading$/.test(name.replace(/\s+/g, ' ')) || /^tocheading$/i.test(id)) return { title: true };
      if (/^toc ?\d$/.test(name) || /^TOC\d$/.test(id)) return { level: +(name.match(/\d/) || [1])[0] };
      return null;
    }

    async function body(elements, opt) {
      const parts = [];
      const ctx = {
        inTable: !!(opt && opt.inTable),
        pushTop: (list) => parts.push(list)
      };
      let inToc = false;
      for (const el of elements) {
        const ln = el.localName;
        // table-of-contents lines become one live Écritoire table of contents
        const tocKind = ln === 'p' && !ctx.inTable ? tocStyle(el) : null;
        if (tocKind) {
          if (tocKind.title) { pendingTocTitle = noteText(el) || pendingTocTitle; continue; }
          if (!inToc) { listStack.length = 0; parts.push(`<div class="lb-toc" contenteditable="false" data-title="${esc(pendingTocTitle || 'Contents')}" data-levels="3"></div>`); inToc = true; }
          continue;
        }
        inToc = false;
        if (ln === 'p') {
          for (const h of await paragraph(el, ctx)) parts.push(h);
        } else if (ln === 'tbl') {
          if (!ctx.inTable) listStack.length = 0;
          parts.push(await table(el));
        } else if (ln === 'sdt') {
          const content = kid(el, 'sdtContent');
          if (content) parts.push(await body(kids(content), opt));
        } else if (ln === 'customXml' || ln === 'ins') {
          parts.push(await body(kids(el), opt));
        }
      }
      return parts.map((p) => (typeof p === 'string' ? p : renderList(p))).join('');
    }

    const bodyEl = desc(doc, 'body');
    const html = await body(kids(bodyEl));

    // page setup
    const settings = {};
    const sect = kid(bodyEl, 'sectPr') || desc(bodyEl, 'sectPr');
    if (sect) {
      const mar = kid(sect, 'pgMar');
      if (mar) {
        settings.margins = {
          top: twipToMm(Math.abs(+attr(mar, 'top') || 1440)),
          right: twipToMm(+attr(mar, 'right') || +attr(mar, 'end') || 1440),
          bottom: twipToMm(Math.abs(+attr(mar, 'bottom') || 1440)),
          left: twipToMm(+attr(mar, 'left') || +attr(mar, 'start') || 1440)
        };
      }
      const sz = kid(sect, 'pgSz');
      if (sz) {
        const w = +attr(sz, 'w'); const h = +attr(sz, 'h');
        if (w && h) {
          settings.orientation = (attr(sz, 'orient') === 'landscape' || w > h) ? 'landscape' : 'portrait';
          const wMm = twipToMm(w), hMm = twipToMm(h);
          const paper = paperFor(wMm, hMm);
          if (paper) settings.paper = paper;
          else {
            settings.paper = 'A4';
            warnings.add('The document used a paper size Écritoire doesn\'t have; it is shown on A4 pages.');
          }
        }
      }
    }
    if (sect) {
      const hf = { header: ['', '', ''], footer: ['', '', ''], firstDifferent: !!kid(sect, 'titlePg') };
      let found = false;
      for (const kind of ['header', 'footer']) {
        const refs = kids(sect, kind + 'Reference');
        const ref = refs.find((r) => attr(r, 'type') === 'default') || refs.find((r) => attr(r, 'type') !== 'even' && attr(r, 'type') !== 'first') || null;
        const rel = ref && rels[attr(ref, 'id')];
        if (!rel) continue;
        let target = rel.target.replace(/^\//, '');
        if (!target.startsWith('word/')) target = 'word/' + target;
        const xml = await text(target);
        if (!xml) continue;
        const slots = hfSlots(parseXml(xml));
        if (slots.some(Boolean)) { hf[kind] = slots; found = true; }
      }
      if (found) settings.hf = hf;
    }

    return { html: html || '<p><br></p>', settings, warnings: [...warnings], defaults, media };
  }

  const PAGE_BREAK = '<div class="lb-page-break" contenteditable="false"></div>';

  /** Plain text of a paragraph: text, tabs as \t, PAGE / NUMPAGES fields as {page} / {pages}. */
  function noteText(p, withFields) {
    let out = '';
    let field = null; // { instr, shown }
    const fieldToken = (instr) => {
      const name = String(instr || '').trim().split(/\s+/)[0].toUpperCase();
      return name === 'PAGE' ? '{page}' : name === 'NUMPAGES' || name === 'SECTIONPAGES' ? '{pages}' : null;
    };
    const walk = (el) => {
      for (const c of kids(el)) {
        const ln = c.localName;
        if (ln === 'fldSimple') {
          const tok = withFields && fieldToken(attr(c, 'instr'));
          if (tok) out += tok; else walk(c);
        } else if (ln === 'fldChar') {
          const t = attr(c, 'fldCharType');
          if (t === 'begin') field = { instr: '', token: null, inResult: false };
          else if (t === 'separate' && field) { field.token = withFields ? fieldToken(field.instr) : null; field.inResult = true; if (field.token) out += field.token; }
          else if (t === 'end') { if (field && !field.inResult && withFields) { const tok = fieldToken(field.instr); if (tok) out += tok; } field = null; }
        } else if (ln === 'instrText') {
          if (field) field.instr += c.textContent;
        } else if (ln === 't') {
          if (!(field && field.token)) out += c.textContent;
        } else if (ln === 'tab' && el.localName === 'r') {
          out += '\t';
        } else if (ln === 'footnoteRef' || ln === 'endnoteRef' || ln === 'pPr' || ln === 'rPr') {
          // the note's own number and formatting
        } else if (ln === 'br' || ln === 'cr') {
          out += ' ';
        } else if (ln === 'r' || ln === 'hyperlink' || ln === 'smartTag' || ln === 'ins' || ln === 'sdt' || ln === 'sdtContent' || ln === 'customXml') {
          walk(c);
        }
      }
    };
    walk(p);
    return out.replace(/[ \u00a0]+/g, ' ').replace(/^ +| +$/g, '');
  }

  /** Header or footer XML → [left, centre, right] text. */
  function hfSlots(xml) {
    const root = xml.documentElement;
    const paras = [];
    for (const n of root.getElementsByTagName('*')) if (n.localName === 'p') paras.push(n);
    for (const p of paras) {
      const t = noteText(p, true);
      if (!t.replace(/\t/g, '').trim()) continue;
      const parts = t.split('\t').map((x) => x.trim());
      // parts follow the usual header tab stops: left, centre, right
      if (parts.length >= 2) return [parts[0], parts[1], parts.slice(2).join(' ').trim()];
      const pPr = kid(p, 'pPr');
      const jc = pPr && kid(pPr, 'jc');
      const align = jc ? val(jc) : 'left';
      if (align === 'center') return ['', parts[0], ''];
      if (align === 'right' || align === 'end') return ['', '', parts[0]];
      return [parts[0], '', ''];
    }
    return ['', '', ''];
  }

  function cssListType(fmt) {
    switch (fmt) {
      case 'dash': return "'–  '";
      case 'check': return "'✓  '";
      case 'arrow': return "'➢  '";
      default: return fmt;
    }
  }

  const api = { read, cssListType, PAGE_BREAK };
  root.LbDocxReader = api;
})(typeof window !== 'undefined' ? window : globalThis);
