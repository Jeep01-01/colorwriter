/* Écritoire — the left pane: Item and Layout as an expandable menu.
 *
 * On tablets and larger screens the pane sits beside the page and can be
 * hidden; on phones it slides in over the page and closes after a choice.
 * Which sections are open is remembered on this device.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const KEY = 'ecritoire.leftpane';
  const NARROW = 820;
  const P = {};

  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (_) { return {}; } };
  const store = (st) => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (_) { /* private mode */ } };
  let state = load();
  // first run: Item and its groups open, Layout closed
  const DEFAULT_OPEN = { item: true, 'item-doc': true, 'item-ill': true, 'item-media': true, layout: false, 'layout-page': true, 'layout-para': true };

  const ws = () => document.getElementById('workspace');
  P.narrow = () => window.innerWidth <= NARROW;
  P.isOpen = () => (P.narrow() ? ws().classList.contains('lp-open') : !ws().classList.contains('lp-closed'));

  function paint() {
    const open = P.isOpen();
    const btn = document.getElementById('lpToggle');
    if (btn) { btn.classList.toggle('on', open); btn.setAttribute('aria-expanded', String(open)); }
  }

  P.open = () => {
    if (P.narrow()) ws().classList.add('lp-open');
    else { ws().classList.remove('lp-closed'); state.docked = true; store(state); }
    paint();
    Lb.layout.drawRulers();
  };
  P.close = () => {
    if (P.narrow()) ws().classList.remove('lp-open');
    else { ws().classList.add('lp-closed'); state.docked = false; store(state); }
    paint();
    Lb.layout.drawRulers();
  };
  P.toggle = () => (P.isOpen() ? P.close() : P.open());

  /** Make sure a section (and its group) is open, e.g. before anchoring a menu to it. */
  P.reveal = (el) => {
    for (let s = el && el.closest('.lp-sec, .lp-grp'); s; s = s.parentElement && s.parentElement.closest('.lp-sec, .lp-grp')) setSection(s, true);
    if (!P.isOpen()) P.open();
  };

  function setSection(sec, open) {
    sec.classList.toggle('open', open);
    const head = sec.querySelector(':scope > .lp-sec-head, :scope > .lp-grp-head');
    if (head) head.setAttribute('aria-expanded', String(open));
    (state.sections = state.sections || {})[sec.dataset.sec] = open;
    store(state);
  }

  P.init = () => {
    const pane = document.getElementById('leftPane');
    if (!pane) return;
    const saved = state.sections || {};
    for (const sec of pane.querySelectorAll('.lp-sec, .lp-grp')) {
      const id = sec.dataset.sec;
      const open = id in saved ? saved[id] : !!DEFAULT_OPEN[id];
      sec.classList.toggle('open', open);
      const head = sec.querySelector(':scope > .lp-sec-head, :scope > .lp-grp-head');
      if (head) {
        head.setAttribute('aria-expanded', String(open));
        head.addEventListener('click', () => setSection(sec, !sec.classList.contains('open')));
      }
    }
    // docked beside the page on wide screens unless the user hid it
    if (state.docked === false) ws().classList.add('lp-closed');
    paint();

    // phones: close after a command; menus close it when their choice is made
    pane.addEventListener('click', (e) => {
      const b = e.target.closest('.lp-item[data-cmd]');
      if (b && P.narrow()) setTimeout(() => { ws().classList.remove('lp-open'); paint(); }, 0);
    });
    document.getElementById('popoverRoot').addEventListener('click', (e) => {
      if (!P.narrow() || !ws().classList.contains('lp-open')) return;
      if (!e.target.closest('button, .tg-cell, [data-r]')) return;
      setTimeout(() => { if (!document.querySelector('.popover')) { ws().classList.remove('lp-open'); paint(); } }, 0);
    });
    window.addEventListener('resize', () => { if (!P.narrow()) ws().classList.remove('lp-open'); paint(); });
  };

  Lb.register('toggleLeftPane', () => P.toggle());
  Lb.leftPane = P;
})();
