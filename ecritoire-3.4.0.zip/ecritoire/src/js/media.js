/* Écritoire — videos inside documents.
 *
 * A video sits in the text like a picture:
 *   <span class="lb-video" contenteditable="false" data-vid="v1" style="width;height">
 *     <video src="blob:…" poster="data:image/jpeg…" controls playsinline></video>
 *   </span>
 * The file itself is kept in memory (Lb.media) and referenced by a blob: URL, so
 * undo snapshots stay small. It plays right in the page.
 *
 * Saving:
 *   .docx  the video file is stored inside the .docx (word/media/ecritoire-videoN.ext)
 *          and a still frame with a play badge stands in the text; its description
 *          "ecritoire-video:<file>" lets Écritoire bring the video back when the
 *          file is opened again. Other editors show the still picture.
 *   PDF    the still frame with the play badge.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const M = {};
  const store = new Map(); // vid -> { blob, type, ext, name, url, badge }
  let seq = 0;
  const MAX_BYTES = 100 * 1024 * 1024;
  const EXT = { 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/x-m4v': 'm4v', 'video/3gpp': '3gp' };
  const MIME = { mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', '3gp': 'video/3gpp' };

  const extOf = (name, type) => {
    const m = /\.([a-z0-9]{2,4})$/i.exec(name || '');
    return (m && MIME[m[1].toLowerCase()] ? m[1].toLowerCase() : EXT[type]) || 'mp4';
  };

  function register(blob, name, type) {
    const vid = 'v' + (++seq) + '-' + Date.now().toString(36);
    const ext = extOf(name, type || blob.type);
    const rec = { blob, type: type || blob.type || MIME[ext], ext, name: name || 'video.' + ext, url: URL.createObjectURL(blob), badge: null };
    store.set(vid, rec);
    return { vid, rec };
  }
  M.get = (vid) => store.get(vid);

  /* ---------- still frames ---------- */
  function drawBadge(g, w, h) {
    const r = Math.max(14, Math.min(w, h) * 0.12);
    g.fillStyle = 'rgba(0,0,0,.55)';
    g.beginPath(); g.arc(w / 2, h / 2, r, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = Math.max(2, r * 0.08); g.stroke();
    g.fillStyle = '#ffffff';
    g.beginPath();
    g.moveTo(w / 2 - r * 0.32, h / 2 - r * 0.45); g.lineTo(w / 2 + r * 0.5, h / 2); g.lineTo(w / 2 - r * 0.32, h / 2 + r * 0.45);
    g.closePath(); g.fill();
  }
  function fallbackStill(w, h, label) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const g = c.getContext('2d');
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#26222c'); gr.addColorStop(1, '#0d0c0f');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = 'rgba(245,158,11,.9)'; g.font = `${Math.round(h * 0.06)}px sans-serif`; g.textAlign = 'center';
    if (label) g.fillText(label, w / 2, h * 0.85);
    return c;
  }
  /** A still with a play badge, for .docx and PDF. */
  function badgeFrom(src, w, h) {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => {
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        const g = c.getContext('2d');
        g.drawImage(im, 0, 0, w, h);
        drawBadge(g, w, h);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      im.onerror = () => { const c = fallbackStill(w, h); drawBadge(c.getContext('2d'), w, h); resolve(c.toDataURL('image/jpeg', 0.85)); };
      im.src = src;
    });
  }

  /** Read the size and grab a frame of a video. Resolves even when no frame can be drawn. */
  function probe(url, label) {
    return new Promise((resolve, reject) => {
      const v = document.createElement('video');
      v.muted = true; v.playsInline = true; v.setAttribute('playsinline', ''); v.setAttribute('muted', '');
      v.preload = 'auto';
      let done = false;
      const finish = (still) => {
        if (done) return;
        done = true;
        const w = v.videoWidth || 640, h = v.videoHeight || 360;
        const k = Math.min(1, 960 / w);
        const cw = Math.round(w * k), ch = Math.round(h * k);
        let poster;
        if (still) {
          const c = document.createElement('canvas'); c.width = cw; c.height = ch;
          try { c.getContext('2d').drawImage(v, 0, 0, cw, ch); poster = c.toDataURL('image/jpeg', 0.82); } catch (_) { poster = null; }
        }
        if (!poster) poster = fallbackStill(cw, ch, label).toDataURL('image/jpeg', 0.82);
        v.removeAttribute('src'); v.load();
        resolve({ w, h, duration: v.duration || 0, poster });
      };
      const timer = setTimeout(() => (v.videoWidth ? finish(false) : (done ? null : reject(new Error('timeout')))), 8000);
      v.addEventListener('loadedmetadata', () => {
        const t = isFinite(v.duration) && v.duration > 0 ? Math.min(1, v.duration * 0.25) : 0.1;
        try { v.currentTime = t; } catch (_) { finish(false); }
      });
      v.addEventListener('seeked', () => { clearTimeout(timer); requestAnimationFrame(() => finish(true)); });
      v.addEventListener('error', () => { clearTimeout(timer); if (!done) reject(new Error('unsupported')); });
      v.src = url;
    });
  }

  /* ---------- inserting ---------- */
  function videoEl(rec, poster) {
    const v = document.createElement('video');
    v.src = rec.url;
    if (poster) v.poster = poster;
    v.controls = true;
    v.setAttribute('controls', '');
    v.setAttribute('playsinline', '');
    v.setAttribute('preload', 'metadata');
    return v;
  }

  M.insertFile = async (file) => {
    if (!file) return;
    if (!/^video\//.test(file.type) && !/\.(mp4|m4v|webm|mov|3gp)$/i.test(file.name || '')) { Lb.ui.toast('That file is not a video.', 'error'); return; }
    if (file.size > MAX_BYTES) {
      Lb.ui.alert('Video too large', `This video is ${(file.size / 1048576).toFixed(0)} MB. Écritoire takes videos up to 100 MB so documents stay easy to save and share. Try a shorter or smaller clip.`);
      return;
    }
    Lb.ui.toast('Adding video…', '', 1500);
    const { vid, rec } = register(file, file.name, file.type);
    let info;
    try { info = await probe(rec.url, file.name); } catch (e) {
      store.delete(vid); URL.revokeObjectURL(rec.url);
      Lb.ui.alert('Video not supported', 'This video format can’t be played here. MP4 (H.264) videos work on every phone and tablet.');
      return;
    }
    const m = Lb.settings.margins;
    const maxW = Lb.pageW() - Lb.mm(m.left + m.right);
    const maxH = (Lb.pageH() - Lb.mm(m.top + m.bottom)) * 0.6;
    const k = Math.min(1, maxW / info.w, maxH / info.h);
    const w = Math.round(info.w * k), h = Math.round(info.h * k);
    const span = document.createElement('span');
    span.className = 'lb-video';
    span.setAttribute('contenteditable', 'false');
    span.dataset.vid = vid;
    span.dataset.lock = '1';
    span.title = file.name || 'Video';
    span.style.width = w + 'px';
    span.style.height = h + 'px';
    span.append(videoEl(rec, info.poster));
    Lb.objects.insertNode(span);
    // a little room after the video so typing can continue
    if (!span.nextSibling) span.after(document.createTextNode('​'));
  };

  M.pick = () => {
    Lb.sel.save();
    const input = document.getElementById('videoInput');
    input.value = '';
    input.onchange = () => { if (input.files[0]) M.insertFile(input.files[0]); };
    input.click();
  };

  /* ---------- opening a .docx that contains videos ---------- */
  /** files: { "ecritoire-video1.mp4": Uint8Array } — fills in the videos of the loaded document. */
  M.hydrate = (files) => {
    const ed = Lb.els.editor;
    for (const span of ed.querySelectorAll('.lb-video[data-file]')) {
      const name = span.dataset.file;
      const bytes = files && files[name];
      if (!bytes) continue;
      const ext = extOf(name);
      const { vid, rec } = register(new Blob([bytes], { type: MIME[ext] || 'video/mp4' }), name, MIME[ext]);
      span.dataset.vid = vid;
      span.removeAttribute('data-file');
      span.setAttribute('contenteditable', 'false');
      const old = span.querySelector('video');
      const poster = old && old.getAttribute('poster');
      span.replaceChildren(videoEl(rec, poster));
      // the stored still has a play badge; take a clean frame for the player
      probe(rec.url, name).then((info) => { const v = span.querySelector('video'); if (v) v.poster = info.poster; }).catch(() => {});
    }
  };

  /* ---------- saving ---------- */
  function readBase64(blob) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result).split(',')[1] || '');
      fr.onerror = () => reject(fr.error);
      fr.readAsDataURL(blob);
    });
  }

  /**
   * Before the .docx model is built: name every video in document order and
   * prepare its still. Returns the files to store in the .docx.
   */
  M.prepare = async (root) => {
    const out = [];
    let n = 0;
    for (const span of (root || Lb.els.editor).querySelectorAll('.lb-video')) {
      const rec = store.get(span.dataset.vid);
      if (!rec) continue;
      const name = `ecritoire-video${++n}.${rec.ext}`;
      span.dataset.export = name;
      const v = span.querySelector('video');
      const w = Math.max(16, Math.round(span.offsetWidth || parseFloat(span.style.width) || 320));
      const h = Math.max(16, Math.round(span.offsetHeight || parseFloat(span.style.height) || 180));
      rec.badge = await badgeFrom(v && v.poster ? v.poster : '', Math.min(1280, w * 2), Math.min(1280, Math.round(h * Math.min(1280, w * 2) / w)));
      out.push({ name, base64: await readBase64(rec.blob), mime: rec.type || MIME[rec.ext] || 'video/mp4' });
    }
    return out;
  };

  /** The run for a video in the .docx model (called while walking the document). */
  M.exportRun = (span) => {
    const rec = store.get(span.dataset.vid);
    const w = span.offsetWidth, h = span.offsetHeight;
    if (!rec || !rec.badge || !w || !h) return null;
    return { image: { base64: rec.badge.split(',')[1], type: 'jpg', width: w, height: h }, video: { name: span.dataset.export } };
  };

  /**
   * PDF export draws the page as a picture: show each video's still (with a
   * play badge) instead of the player. Returns a function that undoes it.
   */
  M.beforeCapture = async () => {
    const added = [];
    for (const span of Lb.els.editor.querySelectorAll('.lb-video')) {
      const v = span.querySelector('video');
      const w = Math.max(16, span.offsetWidth), h = Math.max(16, span.offsetHeight);
      const src = await badgeFrom(v && v.poster ? v.poster : '', Math.min(1280, w * 2), Math.min(1280, h * 2));
      const im = document.createElement('img');
      im.className = 'lb-video-still';
      im.src = src;
      try { await im.decode(); } catch (_) { /* drawn anyway */ }
      span.append(im);
      if (v) v.style.visibility = 'hidden';
      added.push([im, v]);
    }
    return () => { for (const [im, v] of added) { im.remove(); if (v) v.style.visibility = ''; } };
  };

  M.init = () => {
    // keep players from being edited as text
    Lb.on('layout', () => {
      for (const s of Lb.els.editor.querySelectorAll('.lb-video:not([contenteditable])')) s.setAttribute('contenteditable', 'false');
    });
  };

  Lb.register('insertVideo', () => M.pick());
  Lb.media = M;
})();
