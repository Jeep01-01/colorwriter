/* Écritoire — UI icon set.
 * Own "duotone" style: a light 2px outline (currentColor) plus a solid amber
 * accent shape (class "t"). 24×24 grid, rounded joins.
 */
(function (root) {
  'use strict';
  const S = (body, extra) => `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${extra || ''}>${body}</svg>`;
  // a sheet with a rounded page-curl (matches the app logo)
  const sheet = 'M7 3h7.5L19 7.5V19a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z';
  const tone = (d) => `<path class="t" d="${d}"/>`;
  const dot = (cx, cy, r) => `<circle class="t" cx="${cx}" cy="${cy}" r="${r}"/>`;

  const I = {
    /* ---- files ---- */
    new: S(`${tone('M14.5 3L19 7.5h-3a1.5 1.5 0 0 1-1.5-1.5z')}<path d="${sheet}"/>${dot(12, 14.5, 4.2)}<path d="M12 12.2v4.6M9.7 14.5h4.6" stroke="var(--icon-ink)" stroke-width="2"/>`),
    open: S(`${tone('M3 10h18l-2.2 9.2A2 2 0 0 1 16.9 21H5a2 2 0 0 1-2-2z')}<path d="M3 19V6a2 2 0 0 1 2-2h4l2 2.5h6a2 2 0 0 1 2 2V10"/>`),
    save: S(`<rect x="3.5" y="3.5" width="17" height="17" rx="4"/>${tone('M7.5 14.5h9v6h-9z')}<path d="M8 3.5V8h6V3.5"/>`),
    saveAs: S(`<path d="M11 20.5H7.5a4 4 0 0 1-4-4v-9a4 4 0 0 1 4-4h9a4 4 0 0 1 4 4V10"/><path d="M8 3.5V8h6V3.5"/>${tone('M14 21v-2.6l5-5 2.6 2.6-5 5z')}`),
    pdf: S(`<path d="${sheet}"/>${tone('M5 12h14v6H5z')}<path d="M8 17v-3.6h1.3a1.1 1.1 0 0 1 0 2.2H8M12.4 17v-3.6h.8a1.8 1.8 0 0 1 0 3.6h-.8M16 17v-3.6h2M16 15.2h1.6" stroke="var(--icon-ink)" stroke-width="1.3"/>`),
    print: S(`${tone('M3 10a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6H3z')}<path d="M7 8V3h10v5M7 14h10v7H7z"/>${'<path d="M17.5 11h.01" stroke="var(--icon-ink)" stroke-width="2.4"/>'}`),
    pageSetup: S(`<path d="${sheet}"/>${tone('M8 10h8v2.5H8z')}<path d="M8 15.5h8M8 18.5h5"/>`),
    pro: S(`${tone('M4 9l3.5 3L12 5l4.5 7L20 9l-1.6 9H5.6z')}<path d="M4 9l3.5 3L12 5l4.5 7L20 9l-1.6 9H5.6zM6 21h12"/>`),
    info: S(`${tone('M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18z')}<path d="M12 11v6M12 7.5h.01" stroke="var(--icon-ink)" stroke-width="2.4"/>`),
    newWindow: S(`<rect x="3" y="7" width="13" height="13" rx="3"/>${tone('M8 3h10a3 3 0 0 1 3 3v10a1 1 0 0 1-1 1h-2V9a3 3 0 0 0-3-3H8z')}`),
    keyboard: S(`<rect x="2.5" y="6" width="19" height="12" rx="3"/>${tone('M7 14h10v1.6H7z')}<path d="M6.5 10h.01M10 10h.01M14 10h.01M17.5 10h.01" stroke-width="2.4"/>`),
    share: S(`${dot(18, 5.5, 2.8)}${dot(6, 12, 2.8)}${dot(18, 18.5, 2.8)}<circle cx="18" cy="5.5" r="2.8"/><circle cx="6" cy="12" r="2.8"/><circle cx="18" cy="18.5" r="2.8"/><path d="M8.5 10.7l7-3.9M8.5 13.3l7 3.9"/>`),
    find: S(`${dot(10.5, 10.5, 4.2)}<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21"/>`),

    /* ---- edit ---- */
    undo: S(`<path d="M9 13L4 8l5-5"/><path d="M4 8h10a6 6 0 0 1 0 12h-3"/>${dot(11, 20, 1.6)}`),
    redo: S(`<path d="M15 13l5-5-5-5"/><path d="M20 8H10a6 6 0 0 0 0 12h3"/>${dot(13, 20, 1.6)}`),
    cut: S(`${dot(6, 18, 3)}${dot(18, 18, 3)}<circle cx="6" cy="18" r="3"/><circle cx="18" cy="18" r="3"/><path d="M8.2 16L18 3M15.8 16L6 3"/>`),
    copy: S(`${tone('M9 9h10a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H11a2 2 0 0 1-2-2z')}<path d="M15 9V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h4"/><rect x="9" y="9" width="12" height="12" rx="2"/>`),
    paste: S(`<rect x="4" y="4.5" width="16" height="17" rx="3"/>${tone('M8.5 2.5h7v4h-7z')}<path d="M8 12h8M8 16h5"/>`),
    clear: S(`<path d="M5 5h12M11 5l-3 15"/>${tone('M14.5 13.5l6 6-1.5 1.5-6-6z')}<path d="M20 14l-5.5 6"/>`),

    /* ---- text ---- */
    textColor: S(`<path d="M6.5 16L12 3.5 17.5 16M8.4 11.6h7.2"/>`),
    highlight: S(`${tone('M4 21h7l-2-2H5z')}<path d="M14.5 3.5l6 6-8.5 8.5H6v-6z"/>`),
    grow: S(`<path d="M3 20L8 6l5 14M4.8 15h6.4"/>${tone('M17 3l4 5h-8z')}`),
    shrink: S(`<path d="M3 20L8 6l5 14M4.8 15h6.4"/>${tone('M17 9l4-5h-8z')}`),
    launcher: S(`${dot(6, 12, 1.8)}${dot(12, 12, 1.8)}${dot(18, 12, 1.8)}`),
    more: S(`${dot(6, 12, 1.8)}${dot(12, 12, 1.8)}${dot(18, 12, 1.8)}`),
    style: S(`<path d="M4 20h16M7 16l5-12 5 12M8.7 12h6.6"/>`),

    /* ---- paragraph ---- */
    bullets: S(`${tone('M3 4.5h3.5V8H3zM3 10.25h3.5v3.5H3zM3 16h3.5v3.5H3z')}<path d="M10 6.25h11M10 12h11M10 17.75h11"/>`),
    numbering: S(`<path d="M11 6h10M11 12.5h10M11 19h10"/><path d="M4 4.2h1.4v4.6M3.3 10.6a1.5 1.5 0 0 1 2.9.5c0 1-2.9 1.6-2.9 3.1h3M3.3 16.6h2.9l-1.6 1.8a1.4 1.4 0 1 1-1.4 2" stroke="var(--amber)" stroke-width="1.6"/>`),
    outdent: S(`<path d="M21 5H10M21 12h-8M21 19H10"/>${tone('M8 8.5L3 12l5 3.5z')}`),
    indent: S(`<path d="M21 5H10M21 12h-6M21 19H10"/>${tone('M3 8.5L8 12l-5 3.5z')}`),
    alignLeft: S(`${tone('M3 3.5h3v17H3z')}<path d="M9.5 6h11.5M9.5 10h7M9.5 14h11.5M9.5 18h7"/>`),
    alignCenter: S(`${tone('M10.5 3h3v18h-3z')}<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>`),
    alignRight: S(`${tone('M18 3.5h3v17h-3z')}<path d="M3 6h11.5M7.5 10h7M3 14h11.5M7.5 18h7"/>`),
    alignJustify: S(`${tone('M3 3h18v1.6H3zM3 19.4h18V21H3z')}<path d="M3 8.5h18M3 12h18M3 15.5h18"/>`),
    lineSpacing: S(`<path d="M11 6h10M11 12h10M11 18h10"/>${tone('M5 2.5l3.5 4h-7zM5 21.5l3.5-4h-7z')}<path d="M5 6v12"/>`),
    paragraph: S(`${tone('M10 4h3v8h-3a4 4 0 0 1 0-8z')}<path d="M13 4v16M17 4v16M19 4H10a4 4 0 0 0 0 8h3"/>`),

    /* ---- insert ---- */
    picture: S(`<rect x="3" y="4" width="18" height="16" rx="3"/>${tone('M3 17l5.5-5.5 4 4 2.5-2.5L21 19v-2 1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z')}${dot(15.5, 8.5, 1.8)}`),
    shapes: S(`${tone('M3 12h8.5v8.5H3z')}<rect x="3" y="12" width="8.5" height="8.5" rx="1.5"/><circle cx="16.5" cy="7.5" r="4.5"/><path d="M13.5 20.5l3.5-6 3.5 6z"/>`),
    table: S(`<rect x="3" y="3.5" width="18" height="17" rx="3"/>${tone('M3 6.5a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3V9H3z')}<path d="M3 9h18M3 14.5h18M9 9v11.5M15 9v11.5"/>`),
    sidePanel: S(`<rect x="3" y="4" width="18" height="16" rx="3"/>${tone('M3 7a3 3 0 0 1 3-3h3v16H6a3 3 0 0 1-3-3z')}<path d="M13 9h5M13 12h5M13 15h3"/>`),
    item: S(`<rect x="3.5" y="3.5" width="7.5" height="7.5" rx="2"/>${tone('M13 3.5h7.5V11H13z')}<rect x="3.5" y="13" width="7.5" height="7.5" rx="2"/><rect x="13" y="13" width="7.5" height="7.5" rx="2"/>`),
    layout: S(`<path d="${sheet}"/>${tone('M8 7.5h7v3H8z')}<path d="M8 14h8M8 17h5"/>`),
    freeform: S(`${tone('M5 17c1-6 4-11 8-11 3 0 4 3 2 5s-6 2-5 6c.7 2.8 5 3 8 1l-1 3H6z')}<path d="M4 18c2-7 5-12 9-12 3 0 4 3 2 5s-6 2-5 6c.6 2.6 4.5 3 8.5 0"/>`),
    video: S(`<rect x="2.5" y="5.5" width="13.5" height="13" rx="3"/>${tone('M7 9.2v5.6l4.6-2.8z')}<path d="M16 10l5.5-3v10L16 14"/>`),
    template: S(`<path d="M8 21h9a3 3 0 0 0 3-3V8"/><rect x="4" y="3" width="12.5" height="15" rx="2.5"/>${tone('M7 6h6.5v4H7z')}<path d="M7 13h6.5M7 15.5h4"/>`),
    cover: S(`<path d="${sheet}"/>${tone('M5 9.5V5a2 2 0 0 1 2-2h7.5l2.5 2.5V9.5z')}<path d="M8 13h8M8 16h5.5"/>`),
    toc: S(`<path d="M4 6h8M4 12h6M7 18h5"/>${tone('M16.5 4h3.5v4h-3.5zM16.5 10h3.5v4h-3.5zM16.5 16h3.5v4h-3.5z')}<path d="M13.6 6h.01M11.6 12h.01M13.6 18h.01" stroke-width="2.4"/>`),
    headerFooter: S(`<rect x="4" y="3" width="16" height="18" rx="2.5"/>${tone('M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5V7.5H4z')}${tone('M4 16.5h16v2a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 18.5z')}<path d="M8 11h8M8 13.5h5"/>`),
    footnote: S(`<path d="M4 7h9M4 11h7"/>${tone('M3.5 16h17v4.5h-17z')}<path d="M16.5 5.2L18.3 4v6" stroke-width="1.7"/><path d="M6 18.3h9" stroke="var(--icon-ink)" stroke-width="1.6"/>`),
    pageBreak: S(`<path d="M6 3v4a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V3M6 21v-4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v4"/>${tone('M2 11h20v2H2z')}`),
    orientation: S(`<rect x="3" y="8" width="13" height="10" rx="2"/>${tone('M14 3h5a2 2 0 0 1 2 2v9h-5V8a3 3 0 0 0-2-2.8z')}<path d="M7 5.5a4 4 0 0 1 4-2.5M11 3l-1.6 1.8M11 3L9.2 1.6" stroke-width="1.6"/>`),
    portrait: S(`<rect x="6" y="3" width="12" height="18" rx="2.5"/>${tone('M9 7h6v2H9z')}`),
    landscape: S(`<rect x="3" y="6" width="18" height="12" rx="2.5"/>${tone('M6.5 9h8v2h-8z')}`),
    paperSize: S(`<rect x="3" y="7" width="10" height="14" rx="2"/>${tone('M9 3h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4V9a4 4 0 0 0-4-4H9z')}`),
    margins: S(`<rect x="4" y="3" width="16" height="18" rx="2.5"/>${tone('M8 7h8v10H8z')}`),

    /* ---- view ---- */
    zoomIn: S(`${dot(10.5, 10.5, 6.5)}<path d="M15.5 15.5L21 21"/><path d="M8 10.5h5M10.5 8v5" stroke="var(--icon-ink)"/>`),
    zoomOut: S(`${dot(10.5, 10.5, 6.5)}<path d="M15.5 15.5L21 21"/><path d="M8 10.5h5" stroke="var(--icon-ink)"/>`),
    zoomReset: S(`${dot(10.5, 10.5, 6.5)}<path d="M15.5 15.5L21 21"/><path d="M9.3 9.3l1.2-.8v4.8" stroke="var(--icon-ink)" stroke-width="1.6"/>`),
    fitWidth: S(`<rect x="7" y="3" width="10" height="18" rx="2"/>${tone('M1.5 12l3-3v6zM22.5 12l-3-3v6z')}`),
    preview: S(`<rect x="3.5" y="2.5" width="11" height="13" rx="2"/>${tone('M9.5 8.5h11v13h-11z')}<rect x="9.5" y="8.5" width="11" height="13" rx="2"/>`),
    ruler: S(`${tone('M3 15L15 3l6 6L9 21z')}<path d="M3 15L15 3l6 6L9 21z"/><path d="M7.5 13.5l2 2M10.5 10.5l2 2M13.5 7.5l2 2" stroke="var(--icon-ink)"/>`),

    /* ---- objects & tables ---- */
    trash: S(`<path d="M4 7h16M9.5 7V4h5v3"/>${tone('M6 7h12l-1 12.5a2 2 0 0 1-2 1.5H9a2 2 0 0 1-2-1.5z')}`),
    lock: S(`${tone('M5 11h14v10H5z')}<path d="M8 11V7a4 4 0 0 1 8 0v4"/>`),
    unlock: S(`${tone('M5 11h14v10H5z')}<path d="M8 11V7a4 4 0 0 1 7.8-1.2"/>`),
    reset: S(`<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/>${tone('M2 3l6.5 1L4 9z')}`),
    chevronDown: S('<path d="M6 9l6 6 6-6"/>', ' width="12" height="12"'),
    close: S('<path d="M18 6L6 18M6 6l12 12"/>'),
    rowAbove: S(`<rect x="3" y="12" width="18" height="9" rx="2"/>${tone('M12 2l4.5 5h-9z')}<path d="M12 7v3"/>`),
    rowBelow: S(`<rect x="3" y="3" width="18" height="9" rx="2"/>${tone('M12 22l4.5-5h-9z')}<path d="M12 14v3"/>`),
    colLeft: S(`<rect x="12" y="3" width="9" height="18" rx="2"/>${tone('M2 12l5-4.5v9z')}<path d="M7 12h3"/>`),
    colRight: S(`<rect x="3" y="3" width="9" height="18" rx="2"/>${tone('M22 12l-5-4.5v9z')}<path d="M14 12h3"/>`),
    delRow: S(`${tone('M3 8h18v8H3z')}<path d="M9.5 10l5 4M14.5 10l-5 4" stroke="var(--icon-ink)"/>`),
    delCol: S(`${tone('M8 3h8v18H8z')}<path d="M10 9.5l4 5M14 9.5l-4 5" stroke="var(--icon-ink)"/>`),
    merge: S(`<rect x="3" y="5" width="18" height="14" rx="2"/>${tone('M12 12l-4-3v6zM12 12l4-3v6z')}`),
    split: S(`<rect x="3" y="5" width="18" height="14" rx="2"/>${tone('M12 5h1.6v14H12z')}`),
    fill: S(`${tone('M5 12l7-7 7 7-7 7z')}<path d="M5 12l7-7 7 7-7 7z"/><path d="M20.5 16s1.5 2 1.5 3a1.5 1.5 0 0 1-3 0c0-1 1.5-3 1.5-3z"/>`),
    outline: S(`<rect x="4" y="4" width="16" height="16" rx="3"/>${tone('M4 4h16v3H4z')}<path d="M8 12h8" stroke-dasharray="2 2.5"/>`),
    palette: S(`<path d="M12 3a9 9 0 1 0 0 18c1.2 0 1.8-.8 1.8-1.7 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-1 .8-1.7 1.8-1.7H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z"/>${dot(7.5, 11, 1.5)}${dot(10, 7, 1.5)}${dot(15, 7.5, 1.5)}`),
    eyedropper: S(`<path d="M14 6l4 4M5 19l-1 1M5.5 18.5L14 10l-1.5-1.5L4 17v2.5h1.5z"/>${tone('M14.5 3.5a2.1 2.1 0 0 1 3 0l3 3a2.1 2.1 0 0 1 0 3L18 12l-6-6z')}`),
    /* ---- text wrapping and arrange ---- */
    wrap: S(`${tone('M8.5 8.5h7v7h-7z')}<path d="M3 5h18M3 19h18M3 9.5h3M3 14.5h3M18 9.5h3M18 14.5h3"/>`),
    wrapInline: S(`<path d="M3 5h18M3 19h18M3 12h3M18 12h3"/>${tone('M8 9h8v6H8z')}`),
    wrapSquare: S(`<path d="M3 5h18M3 19h18M13.5 9.5H21M13.5 14.5H21"/>${tone('M3 8.5h8v7H3z')}`),
    wrapTight: S(`<path d="M3 5h18M3 19h18M14 9.5h7M15 14.5h6"/>${tone('M7.5 8l4.5 4-4.5 4L3 12z')}`),
    wrapTopBottom: S(`<path d="M3 4h18M3 20h18"/>${tone('M7 8h10v8H7z')}`),
    wrapBehind: S(`${tone('M6 6h12v12H6z')}<path d="M3 8h18M3 12h18M3 16h18"/>`),
    wrapFront: S(`<path d="M3 8h18M3 12h18M3 16h18"/>${tone('M6 6h12v12H6z')}<path d="M6 6h12v12H6z" stroke-width="1.6"/>`),
    bringFront: S(`<rect x="3" y="3" width="10" height="10" rx="1.5"/><rect x="11" y="11" width="10" height="10" rx="1.5"/>${tone('M7 7h10v10H7z')}`),
    bringForward: S(`<rect x="3" y="3" width="11" height="11" rx="1.5"/>${tone('M10 10h11v11H10z')}`),
    sendBack: S(`${tone('M7 7h10v10H7z')}<path d="M3 3h10v4M7 13H3V3M21 21H11v-4M17 11h4v10"/>`),
    sendBackward: S(`${tone('M3 3h11v11H3z')}<path d="M10 14v7h11V10h-7"/>`),
    tick: S('<path d="M5 12.5l4.5 4.5L19 7.5" stroke-width="2.2"/>'),
    layoutOptions: S(`${tone('M4 4h9v9H4z')}<path d="M16 6h5M16 10h5M3 17h18M3 21h18"/>`)
  };
  root.LbIcons = I;
})(window);
