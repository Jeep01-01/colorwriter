/* Écritoire — pictures and shapes: insert, select, resize, colour correction. */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { clamp, round, pxToCm, cmToPx } = Lb.util;
  const O = {};
  let selected = null;

  const ADJ = {
    b: { label: 'Brightness', min: 0, max: 200, def: 100, unit: '%' },
    c: { label: 'Contrast', min: 0, max: 200, def: 100, unit: '%' },
    s: { label: 'Saturation', min: 0, max: 300, def: 100, unit: '%' },
    h: { label: 'Hue', min: -180, max: 180, def: 0, unit: '°' },
    t: { label: 'Temperature', min: -100, max: 100, def: 0, unit: '' },
    g: { label: 'Grayscale', min: 0, max: 100, def: 0, unit: '%' },
    o: { label: 'Transparency', min: 0, max: 100, def: 0, unit: '%' }
  };
  const PRESETS = [
    ['Original', {}],
    ['Grayscale', { g: 100 }],
    ['Sepia', { t: 100, s: 70 }],
    ['Warm', { t: 40, s: 115 }],
    ['Cool', { t: -45, s: 105 }],
    ['Vivid', { s: 170, c: 115 }],
    ['Washout', { b: 135, c: 60, s: 55 }],
    ['Contrast', { c: 155, b: 95 }]
  ];

  const isObj = (el) => el && (el.tagName === 'IMG' || el.classList.contains('lb-video')) && Lb.els.editor.contains(el);
  const isShape = (el) => el && el.classList.contains('lb-shape');
  const isVideo = (el) => el && el.classList.contains('lb-video');
  O.isVideo = isVideo;

  /* ---------- colour correction ---------- */
  function adj(img) {
    const a = {};
    for (const k of Object.keys(ADJ)) a[k] = img.dataset['a' + k] != null ? +img.dataset['a' + k] : ADJ[k].def;
    return a;
  }
  O.filterOf = (img) => {
    const a = adj(img);
    const f = [];
    if (a.b !== 100) f.push(`brightness(${a.b / 100})`);
    if (a.c !== 100) f.push(`contrast(${a.c / 100})`);
    // temperature: warm = sepia + slight hue, cool = hue shift towards blue
    if (a.t > 0) f.push(`sepia(${a.t / 100 * 0.6})`);
    if (a.t < 0) f.push(`hue-rotate(${a.t * 0.25}deg)`, `saturate(${1 + (-a.t / 100) * 0.15})`);
    if (a.s !== 100) f.push(`saturate(${a.s / 100})`);
    if (a.h !== 0) f.push(`hue-rotate(${a.h}deg)`);
    if (a.g) f.push(`grayscale(${a.g / 100})`);
    if (a.t < 0) f.push(`brightness(${1 + a.t / 1000})`);
    if (a.o) f.push(`opacity(${1 - a.o / 100})`);
    return f.join(' ');
  };
  O.applyFilter = (img) => {
    const f = O.filterOf(img);
    img.style.filter = f;
    if (!f) img.style.removeProperty('filter');
  };
  O.hasAdjustments = (img) => !!O.filterOf(img);

  /* ---------- shape rendering ---------- */
  O.shapeProps = (img) => ({
    w: img.offsetWidth || parseFloat(img.style.width) || 140,
    h: img.offsetHeight || parseFloat(img.style.height) || 140,
    fill: img.dataset.fill || '#f59e0b',
    stroke: img.dataset.stroke || '#1f1f1f',
    strokeWidth: img.dataset.sw != null ? +img.dataset.sw : 2,
    noFill: img.dataset.nofill === '1',
    noStroke: img.dataset.nostroke === '1',
    path: img.dataset.path || '',
    closed: img.dataset.closed !== '0'
  });
  O.renderShape = (img, w, h) => {
    const p = O.shapeProps(img);
    if (w) p.w = w; if (h) p.h = h;
    img.src = window.LbShapes.dataUrl(img.dataset.shape, p);
    if (Lb.wrap && img.dataset.wrap) Lb.wrap.sync(img);
  };

  /* ---------- insertion ---------- */
  O.insertNode = (node) => insertNode(node);
  function insertNode(node) {
    const range = Lb.sel.restore();
    Lb.history.checkpoint();
    const ed = Lb.els.editor;
    let r = range;
    if (!r || !Lb.sel.inEditor(r)) {
      r = document.createRange();
      r.selectNodeContents(ed.lastElementChild || ed);
      r.collapse(false);
    }
    const prev = O.selected();
    if (prev) {
      // insert next to the selected object rather than replacing it
      r = document.createRange();
      r.setStartAfter(prev); r.collapse(true);
      O.deselect();
    }
    r.deleteContents();
    // never insert directly in the editor root or inside a page break
    let container = r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement;
    if (container === ed || (container.closest && container.closest('.lb-page-break'))) {
      const p = document.createElement('p');
      if (container === ed) ed.insertBefore(p, ed.childNodes[r.startOffset] || null);
      else container.closest('.lb-page-break').after(p);
      p.appendChild(node);
    } else {
      r.insertNode(node);
      // remove a lone <br> placeholder in an otherwise empty block
      const blk = Lb.closestBlock(node);
      if (blk) for (const br of [...blk.querySelectorAll(':scope > br')]) if (blk.childNodes.length === 2 && br.nextSibling === null) br.remove();
    }
    Lb.history.commit();
    Lb.layout.refresh();
    O.select(node);
    node.scrollIntoView({ block: 'nearest' });
  }

  O.insertPictureFromDataUrl = (src) => new Promise((resolve) => {
    const probe = new Image();
    probe.onload = () => {
      const m = Lb.settings.margins;
      const maxW = Lb.pageW() - Lb.mm(m.left + m.right);
      const maxH = (Lb.pageH() - Lb.mm(m.top + m.bottom)) * 0.9;
      let w = probe.naturalWidth || 300, h = probe.naturalHeight || 200;
      const k = Math.min(1, maxW / w, maxH / h);
      w = Math.round(w * k); h = Math.round(h * k);
      const img = document.createElement('img');
      img.className = 'lb-picture';
      img.src = src;
      img.alt = '';
      img.dataset.lock = '1';
      img.style.width = w + 'px';
      img.style.height = h + 'px';
      insertNode(img);
      resolve(img);
    };
    probe.onerror = () => { Lb.ui.toast('That image could not be read.', 'error'); resolve(null); };
    probe.src = src;
  });

  O.insertPictureFile = (file) => new Promise((resolve) => {
    if (!file || !/^image\//.test(file.type)) { resolve(null); return; }
    const fr = new FileReader();
    fr.onload = () => O.insertPictureFromDataUrl(fr.result).then(resolve);
    fr.readAsDataURL(file);
  });

  O.pickPicture = () => {
    Lb.sel.save();
    const input = document.getElementById('pictureInput');
    input.value = '';
    input.onchange = () => { if (input.files[0]) O.insertPictureFile(input.files[0]); };
    input.click();
  };

  O.insertShape = (id) => {
    const size = window.LbShapes.defaultSize(id);
    const img = document.createElement('img');
    img.className = 'lb-shape';
    img.alt = window.LbShapes.get(id).name;
    img.dataset.shape = id;
    img.dataset.fill = '#f59e0b';
    img.dataset.stroke = '#1f1f1f';
    img.dataset.sw = '2';
    img.style.width = size.w + 'px';
    img.style.height = size.h + 'px';
    img.src = window.LbShapes.dataUrl(id, { w: size.w, h: size.h, fill: '#f59e0b', stroke: '#1f1f1f', strokeWidth: 2 });
    insertNode(img);
  };

  /* ---------- selection ---------- */
  O.selected = () => (selected && Lb.els.editor.contains(selected) ? selected : null);

  O.select = (img) => {
    if (selected && selected !== img) selected.classList.remove('lb-selected');
    selected = img;
    img.classList.add('lb-selected');
    // select the node so copy / cut / typing work on it
    const r = document.createRange();
    r.selectNode(img);
    const s = window.getSelection();
    s.removeAllRanges(); s.addRange(r);
    Lb.sel.save();
    O.refresh();
    showFormatTab(true);
    // a video opens its pane only on request, so the player stays in view
    if (!isVideo(img)) O.showPane();
  };

  O.deselect = () => {
    if (!selected) return;
    selected.classList.remove('lb-selected');
    selected = null;
    Lb.els.overlay.hidden = true;
    showFormatTab(false);
    if (Lb.sidebarMode === 'object') Lb.closeSidebar();
  };

  function showFormatTab(on) {
    const tab = document.getElementById('formatTab');
    if (on && selected) {
      Lb.setFormatPanel('object');
      const label = document.getElementById('formatTabLabel');
      tab.hidden = false;
      tab.textContent = isShape(selected) ? 'Shape Format' : isVideo(selected) ? 'Video Format' : 'Picture Format';
      if (label) label.textContent = isShape(selected) ? 'Shape' : isVideo(selected) ? 'Video' : 'Picture';
      if (Lb.wrap) Lb.wrap.syncRibbon();
    } else if (!Lb.tables || !Lb.tables.activeTable()) {
      tab.hidden = true;
      if (tab.classList.contains('active')) Lb.switchTab('home');
    }
  }

  O.refresh = () => {
    const ov = Lb.els.overlay;
    const img = O.selected();
    if (!img) { ov.hidden = true; if (selected) O.deselect(); return; }
    const pr = Lb.els.page.getBoundingClientRect();
    const r = img.getBoundingClientRect();
    const z = Lb.state.zoom;
    ov.hidden = false;
    ov.style.left = (r.left - pr.left) / z + 'px';
    ov.style.top = (r.top - pr.top) / z + 'px';
    ov.style.width = r.width / z + 'px';
    ov.style.height = r.height / z + 'px';
    // keep handles a constant on-screen size
    for (const hd of ov.querySelectorAll('.h')) hd.style.transform = `scale(${1 / z})`;
    ov.classList.toggle('movable', !!(Lb.wrap && Lb.wrap.mode(img) !== 'inline'));
    const lo = document.getElementById('layoutOptionsBtn');
    if (lo) { lo.hidden = !(Lb.wrap && Lb.wrap.canWrap(img)); lo.style.transform = `scale(${1 / z})`; }
    const badge = document.getElementById('sizeBadge');
    badge.style.transform = `translateX(-50%) scale(${1 / z})`;
    badge.textContent = `${pxToCm(img.offsetWidth).toFixed(2)} × ${pxToCm(img.offsetHeight).toFixed(2)} cm`;
  };

  /* ---------- resizing ---------- */
  function setupHandles() {
    Lb.els.overlay.addEventListener('pointerdown', (e) => {
      const hd = e.target.closest('.h');
      const img = O.selected();
      if (!hd || !img) return;
      e.preventDefault(); e.stopPropagation();
      const dir = hd.dataset.h;
      const z = Lb.state.zoom;
      const sw = img.offsetWidth, sh = img.offsetHeight;
      const sx = e.clientX, sy = e.clientY;
      const free = !!(Lb.wrap && Lb.wrap.isFree(img));
      const sl = parseFloat(img.style.left) || 0, st = parseFloat(img.style.top) || 0;
      const lockDefault = img.dataset.lock === '1';
      Lb.history.checkpoint();
      const move = (ev) => {
        let dx = (ev.clientX - sx) / z, dy = (ev.clientY - sy) / z;
        if (dir.includes('w')) dx = -dx;
        if (dir.includes('n')) dy = -dy;
        let w = sw, h = sh;
        if (dir.includes('e') || dir.includes('w')) w = sw + dx;
        if (dir.includes('n') || dir.includes('s')) h = sh + dy;
        const lock = ev.shiftKey ? !lockDefault : lockDefault;
        if (lock) {
          const ratio = sw / sh;
          if (dir.length === 2) { if (Math.abs(dx) * sh > Math.abs(dy) * sw) h = w / ratio; else w = h * ratio; }
          else if (dir === 'e' || dir === 'w') h = w / ratio;
          else w = h * ratio;
        }
        const maxW = Lb.pageW();
        w = clamp(Math.round(w), 6, maxW); h = clamp(Math.round(h), 4, Lb.pageH());
        img.style.width = w + 'px';
        img.style.height = h + 'px';
        if (free) {
          if (dir.includes('w')) img.style.left = Math.round(sl + sw - w) + 'px';
          if (dir.includes('n')) img.style.top = Math.round(st + sh - h) + 'px';
        }
        if (isShape(img)) O.renderShape(img, w, h);
        O.refresh();
        syncSizeFields();
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', up);
        Lb.history.commit();
        Lb.layout.refresh();
        O.select(img);
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
      window.addEventListener('pointercancel', up);
    });
  }

  O.setSize = (img, w, h) => {
    img.style.width = Math.round(w) + 'px';
    img.style.height = Math.round(h) + 'px';
    if (isShape(img)) O.renderShape(img, w, h);
  };

  O.remove = () => {
    const img = O.selected();
    if (!img) return;
    Lb.history.checkpoint();
    const after = img.nextSibling, parent = img.parentNode;
    O.deselect();
    img.remove();
    if (parent && !parent.textContent.replace(/\u200B/g, '') && !parent.querySelector('img,br,.lb-video') && Lb.isBlock(parent)) parent.innerHTML = '<br>';
    const r = document.createRange();
    if (after && after.parentNode === parent) r.setStartBefore(after); else r.selectNodeContents(parent), r.collapse(false);
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    Lb.history.commit();
    Lb.layout.refresh();
  };

  /* ---------- format pane ---------- */
  let syncSizeFields = () => {};
  const commitLater = Lb.util.debounce(() => Lb.history.commit(), 350);

  O.showPane = () => {
    const img = O.selected();
    if (!img) return;
    const h = Lb.ui.h;
    const shape = isShape(img);
    const video = isVideo(img);
    const body = h('div');

    // --- size ---
    const wIn = h('input', { type: 'number', step: '0.01', min: '0.1' });
    const hIn = h('input', { type: 'number', step: '0.01', min: '0.1' });
    const lock = h('input', { type: 'checkbox' });
    lock.checked = img.dataset.lock === '1';
    syncSizeFields = () => {
      if (document.activeElement !== wIn) wIn.value = pxToCm(img.offsetWidth).toFixed(2);
      if (document.activeElement !== hIn) hIn.value = pxToCm(img.offsetHeight).toFixed(2);
    };
    syncSizeFields();
    const applySize = (which) => {
      const w0 = img.offsetWidth, h0 = img.offsetHeight;
      let w = cmToPx(+wIn.value || 0.1), hh = cmToPx(+hIn.value || 0.1);
      if (lock.checked) { if (which === 'w') hh = w * h0 / w0; else w = hh * w0 / h0; }
      Lb.history.checkpoint();
      O.setSize(img, w, hh);
      Lb.history.commit();
      Lb.layout.refresh();
      O.refresh(); syncSizeFields();
    };
    wIn.addEventListener('change', () => applySize('w'));
    hIn.addEventListener('change', () => applySize('h'));
    lock.addEventListener('change', () => { Lb.history.checkpoint(); if (lock.checked) img.dataset.lock = '1'; else delete img.dataset.lock; Lb.history.commit(); });
    const sizeSec = h('div', { class: 'sec' }, h('h3', null, 'Size'),
      h('div', { class: 'frow' }, h('label', null, 'Width'), wIn, h('span', { class: 'unit' }, 'cm')),
      h('div', { class: 'frow' }, h('label', null, 'Height'), hIn, h('span', { class: 'unit' }, 'cm')),
      h('div', { class: 'frow' }, h('label', null, ''), h('label', { class: 'check' }, lock, 'Lock aspect ratio')));
    const sizeBtns = h('div', { class: 'btn-row', style: { marginTop: '8px' } });
    const resizeBy = (fn) => { Lb.history.checkpoint(); fn(); Lb.history.commit(); Lb.layout.refresh(); O.refresh(); syncSizeFields(); };
    for (const pct of [50, 75, 150]) {
      sizeBtns.append(h('button', { class: 'btn sm', onclick: () => resizeBy(() => O.setSize(img, img.offsetWidth * pct / 100, img.offsetHeight * pct / 100)) }, pct + '%'));
    }
    sizeBtns.append(h('button', { class: 'btn sm', onclick: () => resizeBy(() => {
      const m = Lb.settings.margins;
      const maxW = Lb.pageW() - Lb.mm(m.left + m.right);
      O.setSize(img, maxW, img.offsetHeight * maxW / img.offsetWidth);
    }) }, 'Fit width'));
    if (!shape && !video) {
      sizeBtns.append(h('button', { class: 'btn sm', onclick: () => {
        const p = new Image();
        p.onload = () => {
          const m = Lb.settings.margins;
          const maxW = Lb.pageW() - Lb.mm(m.left + m.right);
          const k = Math.min(1, maxW / p.naturalWidth);
          Lb.history.checkpoint(); O.setSize(img, p.naturalWidth * k, p.naturalHeight * k); Lb.history.commit(); Lb.layout.refresh(); O.refresh(); syncSizeFields();
        };
        p.src = img.src;
      } }, 'Reset'));
    }
    sizeSec.append(sizeBtns);
    body.append(sizeSec);

    // --- shape style ---
    if (shape) {
      const sel = h('select');
      let cat = '';
      let group = null;
      for (const s of window.LbShapes.list) {
        if (s.cat !== cat) { cat = s.cat; group = h('optgroup', { label: cat }); sel.append(group); }
        group.append(h('option', { value: s.id, selected: s.id === img.dataset.shape }, s.name));
      }
      if (img.dataset.shape === 'freeform') sel.prepend(h('option', { value: 'freeform', selected: true }, 'Freeform (drawn)'));
      sel.addEventListener('change', () => { Lb.history.checkpoint(); img.dataset.shape = sel.value; img.alt = window.LbShapes.get(sel.value).name; O.renderShape(img); Lb.history.commit(); });
      const swIn = h('input', { type: 'range', min: '0', max: '16', step: '0.5', value: img.dataset.sw != null ? img.dataset.sw : 2 });
      const swVal = h('span', { class: 'val' }, swIn.value + ' px');
      swIn.addEventListener('input', () => {
        img.dataset.sw = swIn.value;
        if (+swIn.value > 0) delete img.dataset.nostroke;
        swVal.textContent = swIn.value + ' px';
        O.renderShape(img);
        commitLater();
        if (Lb.wrap) Lb.wrap.syncRibbon();
      });
      // colour buttons open the full palette: theme, standard and recent colours, the system picker
      const colorBtn = (menu, cls, label) => h('button', { class: 'btn sm color-pick', type: 'button', 'data-menu': menu, title: label },
        h('i', { class: 'sw ' + cls }), h('span', null, label), Lb.ui.icon('chevronDown'));
      const sysBtn = (key) => h('button', { class: 'btn sm', type: 'button', title: 'The Windows or Android colour picker', onclick: async () => {
        const c = await Lb.ui.systemColor(key === 'fill' ? img.dataset.fill : img.dataset.stroke);
        if (c) { Lb.ui.rememberColor(c); Lb.wrap.setShapeStyle(img, key === 'fill' ? { fill: c } : { stroke: c }); }
      } }, Lb.ui.icon('palette'));
      body.append(h('div', { class: 'sec' }, h('h3', null, 'Shape'),
        h('div', { class: 'frow' }, h('label', null, 'Type'), sel),
        h('div', { class: 'frow' }, h('label', null, 'Fill'), colorBtn('shapeFillMenu', 'sw-fill', 'Colors'), sysBtn('fill')),
        h('div', { class: 'frow' }, h('label', null, 'Outline'), colorBtn('shapeOutlineMenu', 'sw-outline', 'Colors'), sysBtn('stroke')),
        h('div', { class: 'frow' }, h('label', null, 'Line width'), swIn, swVal)));
      setTimeout(() => Lb.wrap && Lb.wrap.syncRibbon(), 0);
      if (img.dataset.shape === 'freeform') {
        const closed = h('input', { type: 'checkbox' });
        closed.checked = img.dataset.closed !== '0';
        closed.addEventListener('change', () => { Lb.history.checkpoint(); img.dataset.closed = closed.checked ? '1' : '0'; O.renderShape(img); Lb.history.commit(); });
        body.lastChild.append(h('div', { class: 'frow' }, h('label', null, 'Outline'), h('label', { class: 'check' }, closed, 'Closed shape (filled)')));
      }
    }

    // --- video ---
    if (video) {
      const v = img.querySelector('video');
      const rec = Lb.media && Lb.media.get(img.dataset.vid);
      body.append(h('div', { class: 'sec' }, h('h3', null, 'Video'),
        h('div', { class: 'btn-row' },
          h('button', { class: 'btn sm', onclick: () => { if (v) { if (v.paused) v.play(); else v.pause(); } } }, 'Play / Pause'),
          h('button', { class: 'btn sm', onclick: () => { if (v) { v.pause(); v.currentTime = 0; } } }, 'Back to start')),
        h('p', { class: 'hint' }, rec ? `${rec.name} · ${(rec.blob.size / 1048576).toFixed(1)} MB. Saved inside the .docx; PDFs show a still picture.` : 'The video file is missing.')));
    }

    // --- colour correction (pictures and shapes) ---
    const corr = h('div', { class: 'sec' }, h('h3', null, shape ? 'Color Adjust' : 'Color Correction'));
    const presets = h('div', { class: 'chip-row' });
    const sliders = {};
    const a0 = adj(img);
    for (const [name, vals] of PRESETS) {
      const chip = h('button', { class: 'chip', title: name });
      const thumb = h('i');
      const tmp = { dataset: {} };
      for (const k of Object.keys(ADJ)) tmp.dataset['a' + k] = vals[k] != null ? vals[k] : ADJ[k].def;
      thumb.style.filter = O.filterOf(tmp);
      if (!shape) { thumb.style.background = `center/cover no-repeat url("${img.src.length < 3e6 ? img.src : ''}")`; }
      chip.append(thumb, name);
      chip.addEventListener('click', () => {
        Lb.history.checkpoint();
        for (const k of Object.keys(ADJ)) {
          const v = vals[k] != null ? vals[k] : ADJ[k].def;
          if (v === ADJ[k].def) delete img.dataset['a' + k]; else img.dataset['a' + k] = v;
          sliders[k].input.value = v; sliders[k].val.textContent = v + ADJ[k].unit;
        }
        O.applyFilter(img);
        Lb.history.commit();
      });
      presets.append(chip);
    }
    corr.append(presets);
    for (const [k, d] of Object.entries(ADJ)) {
      const input = h('input', { type: 'range', min: d.min, max: d.max, step: 1, value: a0[k] });
      const val = h('span', { class: 'val' }, a0[k] + d.unit);
      input.addEventListener('input', () => {
        const v = +input.value;
        if (v === d.def) delete img.dataset['a' + k]; else img.dataset['a' + k] = v;
        val.textContent = v + d.unit;
        O.applyFilter(img);
        commitLater();
      });
      input.addEventListener('dblclick', () => { input.value = d.def; input.dispatchEvent(new Event('input')); });
      sliders[k] = { input, val };
      corr.append(h('div', { class: 'frow' }, h('label', null, d.label), input, val));
    }
    corr.append(h('div', { class: 'btn-row', style: { marginTop: '8px' } },
      h('button', { class: 'btn sm', onclick: () => presets.firstChild.click() }, 'Reset colors')));
    corr.append(h('p', { class: 'hint' }, 'Double-click a slider to reset it.'));
    if (!video) body.append(corr);

    // --- text wrapping, position and order ---
    const arrange = h('div', { class: 'sec' }, h('h3', null, 'Layout'));
    if (Lb.wrap && Lb.wrap.canWrap(img)) {
      const mode = Lb.wrap.mode(img);
      const modes = h('div', { class: 'wrap-grid' });
      for (const [m, label, icon] of Lb.wrap.MODES) {
        const b = h('button', { class: 'tool' + (m === mode ? ' on' : ''), title: label, type: 'button' }, Lb.ui.icon(icon), label);
        b.addEventListener('click', () => { Lb.wrap.setMode(img, m); O.showPane(); });
        modes.append(b);
      }
      arrange.append(h('div', { class: 'sub' }, 'Text wrapping'), modes);
    }
    const mode = Lb.wrap ? Lb.wrap.mode(img) : 'inline';
    const alignRow = h('div', { class: 'tool-grid' });
    const sides = mode === 'square' || mode === 'tight' ? [['left', 'alignLeft', 'Left'], ['right', 'alignRight', 'Right']]
      : mode === 'behind' || mode === 'front' ? [] : [['left', 'alignLeft', 'Left'], ['center', 'alignCenter', 'Center'], ['right', 'alignRight', 'Right']];
    const curSide = img.dataset.side || 'left';
    for (const [a, icon, label] of sides) {
      const on = mode !== 'inline' && curSide === a;
      const b = h('button', { class: 'tool' + (on ? ' on' : ''), title: 'Position ' + label, type: 'button' }, Lb.ui.icon(icon), label);
      b.addEventListener('click', () => {
        if (mode !== 'inline') { Lb.wrap.setSide(img, a); O.showPane(); return; }
        const blk = Lb.closestBlock(img);
        if (!blk) return;
        Lb.history.checkpoint();
        blk.style.textAlign = a === 'left' ? '' : a;
        Lb.history.commit();
        O.refresh();
      });
      alignRow.append(b);
    }
    if (sides.length) arrange.append(h('div', { class: 'sub' }, 'Position'), alignRow);
    if (mode === 'behind' || mode === 'front') arrange.append(h('p', { class: 'hint' }, 'Drag it to move it anywhere on the page.'));
    else if (mode !== 'inline') arrange.append(h('p', { class: 'hint' }, 'Drag it into the text to move it; the side follows where you drop it.'));
    const orderRow = h('div', { class: 'tool-grid' });
    if (Lb.wrap && Lb.wrap.canWrap(img)) {
      for (const [how, icon, label] of [['front', 'bringFront', 'To Front'], ['forward', 'bringForward', 'Forward'], ['backward', 'sendBackward', 'Backward'], ['back', 'sendBack', 'To Back']]) {
        const b = h('button', { class: 'tool', title: { front: 'Bring to Front', forward: 'Bring Forward', backward: 'Send Backward', back: 'Send to Back' }[how], type: 'button' }, Lb.ui.icon(icon), label);
        b.addEventListener('click', () => { Lb.wrap.order(img, how); O.showPane(); });
        orderRow.append(b);
      }
      arrange.append(h('div', { class: 'sub' }, 'Order'), orderRow);
    }
    const del = h('button', { class: 'btn sm danger', type: 'button', style: { marginTop: '10px' } }, Lb.ui.icon('trash'), 'Delete');
    del.addEventListener('click', () => O.remove());
    arrange.append(del);
    body.append(arrange);

    Lb.openSidebar(shape ? 'Format Shape' : video ? 'Format Video' : 'Format Picture', body, 'object');
  };

  O.init = () => {
    const ed = Lb.els.editor;
    const objAt = (t) => (t && t.closest ? t.closest('img, .lb-video') : null);
    ed.addEventListener('click', (e) => {
      const o = objAt(e.target);
      if (o && isObj(o) && o !== selected) O.select(o);
    });
    ed.addEventListener('dblclick', (e) => {
      const o = objAt(e.target);
      if (o && isObj(o)) { O.select(o); O.showPane(); }
    });
    document.addEventListener('selectionchange', () => {
      if (!selected) return;
      const r = Lb.sel.range();
      if (!r) return;
      const exact = r.startContainer === r.endContainer && r.endOffset - r.startOffset === 1 && r.startContainer.childNodes[r.startOffset] === selected;
      if (!exact && Lb.sel.inEditor(r)) O.deselect();
    });
    Lb.on('layout', () => { if (selected) O.refresh(); });
    Lb.on('restored', () => { selected = null; Lb.els.overlay.hidden = true; showFormatTab(false); if (Lb.sidebarMode === 'object') Lb.closeSidebar(); });
    setupHandles();
  };

  Lb.objects = O;
})();
