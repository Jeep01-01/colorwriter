/* Écritoire — phone and tablet bridge (Capacitor, Android and iOS).
 * Provides the `window.ecritoire` API the editor uses for files, implemented
 * with the system file picker, storage, share sheet, clipboard and (Android)
 * the back button. Loaded before core.js; does nothing outside the apps.
 *
 * Native plugins used:
 *   @capacitor/app, @capacitor/filesystem, @capacitor/share,
 *   @capawesome-team/capacitor-file-opener, @capacitor/clipboard
 */
(function () {
  'use strict';
  const Cap = window.Capacitor;
  if (!Cap || !Cap.isNativePlatform || !Cap.isNativePlatform()) return;

  document.documentElement.classList.add('is-mobile', 'is-' + Cap.getPlatform());

  const plugin = (name) => (Cap.Plugins && Cap.Plugins[name]) || (Cap.registerPlugin ? Cap.registerPlugin(name) : null);
  const Filesystem = () => plugin('Filesystem');
  const Share = () => plugin('Share');
  const App = () => plugin('App');
  const FileOpener = () => plugin('FileOpener');
  const Clipboard = () => plugin('Clipboard');

  const IOS = Cap.getPlatform() === 'ios';
  // Android: Documents › Ecritoire. iOS: the app's own folder in the Files app
  // (Files › On My iPhone › Écritoire), so no extra sub-folder there.
  const FOLDER = 'Ecritoire';
  const PLACE = IOS ? 'Files › On My iPhone › Écritoire' : `Documents › ${FOLDER}`;
  const MIME = {
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    pdf: 'application/pdf'
  };
  const extOf = (name) => ((/\.([a-z0-9]+)$/i.exec(name || '') || [])[1] || '').toLowerCase();
  const baseName = (name) => String(name || 'Document').split(/[\\/]/).pop().replace(/\.[^.]+$/, '');
  const safeName = (name) => baseName(name).replace(/[\\/:*?"<>|]+/g, '_').trim() || 'Document';
  const ui = () => window.Lb && window.Lb.ui;
  const toast = (m, k, ms) => { const u = ui(); if (u) u.toast(m, k, ms); };

  /* ---------- building file contents ---------- */
  async function contentFor(format, req) {
    if (format === 'pdf') {
      toast('Creating PDF…', '', 1500);
      return window.LbPdf.fromEditor({
        pages: req && req.pages,
        onProgress: (d, t) => { if (t > 3 && (d === t || d % 5 === 0)) toast(`PDF page ${d} of ${t}`, '', 900); }
      });
    }
    const model = req.model || await window.Lb.exporter.buildModel();
    return window.LbDocxWriter.buildDocx(model); // base64
  }

  /* ---------- storage ---------- */
  let permissionAsked = false;
  async function ensurePermission() {
    if (permissionAsked) return;
    permissionAsked = true;
    try {
      const fs = Filesystem();
      const st = await fs.checkPermissions();
      if (st && st.publicStorage && st.publicStorage !== 'granted') await fs.requestPermissions();
    } catch (_) { /* Android 11+ needs no permission for its own files */ }
  }

  async function writeDocuments(fileName, base64) {
    await ensurePermission();
    const res = await Filesystem().writeFile({ path: IOS ? fileName : `${FOLDER}/${fileName}`, data: base64, directory: 'DOCUMENTS', recursive: true });
    return { uri: res.uri, path: IOS ? `On My iPhone/Écritoire/${fileName}` : `Documents/${FOLDER}/${fileName}` };
  }

  async function writeCache(fileName, base64) {
    const res = await Filesystem().writeFile({ path: `share/${fileName}`, data: base64, directory: 'CACHE', recursive: true });
    return res.uri;
  }

  async function shareFile(fileName, base64, title) {
    const uri = await writeCache(fileName, base64);
    await Share().share({ title: title || fileName, dialogTitle: 'Share ' + fileName, files: [uri] });
  }

  /* ---------- the Save As sheet ---------- */
  async function saveSheet(opts) {
    const o = opts || {};
    const name = safeName(o.defaultPath);
    const formats = o.pdfOnly ? [['pdf', 'PDF document (.pdf)']] : [['docx', 'DOCX document (.docx)'], ['pdf', 'PDF document (.pdf)']];
    const current = o.pdfOnly ? 'pdf' : (extOf(o.defaultPath) === 'pdf' ? 'pdf' : 'docx');
    const res = await ui().modal({
      title: o.pdfOnly ? 'Save as PDF' : 'Save As',
      width: 460,
      body: `
        <div class="mrow"><label>File name</label><input type="text" id="msName" value="${name.replace(/"/g, '&quot;')}" style="flex:1;min-width:0"></div>
        <div class="mrow"><label>Format</label><select id="msFmt" style="flex:1">${formats.map(([v, l]) => `<option value="${v}"${v === current ? ' selected' : ''}>${l}</option>`).join('')}</select></div>
        <p class="hint">Saved in <b>${PLACE}</b> on this device. Use <b>Share</b> in the File menu to send it to ${IOS ? 'iCloud Drive, Mail or Messages' : 'Drive, email or WhatsApp'}.</p>`,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Save', value: 'ok', primary: true }]
    });
    if (res.value !== 'ok') return null;
    const n = safeName(res.root.querySelector('#msName').value);
    return `${n}.${res.root.querySelector('#msFmt').value}`;
  }

  /* ---------- opening ---------- */
  function pickFile() {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.docx,.doc,' + MIME.docx + ',application/msword';
      input.style.display = 'none';
      document.body.append(input);
      const done = (v) => { input.remove(); resolve(v); };
      input.addEventListener('change', () => done(input.files[0] || null));
      input.addEventListener('cancel', () => done(null));
      input.click();
    });
  }

  async function openDialog() {
    const file = await pickFile();
    if (!file) return { canceled: true };
    const data = new Uint8Array(await file.arrayBuffer());
    const isZip = data[0] === 0x50 && data[1] === 0x4b;
    if (!isZip) {
      return {
        error: extOf(file.name) === 'doc'
          ? 'Older .doc files cannot be opened here. Save the file as .docx in another editor first.'
          : 'This file is not a .docx document.'
      };
    }
    return { name: file.name.replace(/\.doc$/i, '.docx'), ext: '.docx', path: null, data };
  }

  /* ---------- back button / closing (Android only; iPhones have no back button) ---------- */
  let closeHandler = null;
  if (!IOS) try {
    App().addListener('backButton', () => {
      const Lb = window.Lb;
      if (document.querySelector('.modal-backdrop')) { document.querySelector('.modal-backdrop .btn:not(.primary)')?.click(); return; }
      if (document.querySelector('.popover')) { ui().closePopover(); return; }
      if (Lb && Lb.sidebarMode) { Lb.closeSidebar(); if (Lb.objects) Lb.objects.deselect(); return; }
      if (Lb && Lb.state.dirty && closeHandler) closeHandler();
      else App().exitApp();
    });
  } catch (e) { console.warn('Back button handler not available', e); }

  /* ---------- the bridge ---------- */
  window.ecritoire = {
    platform: Cap.getPlatform(),
    openDialog,
    openPath: async () => ({ error: 'Opening by path is not supported on this device.' }),
    saveDialog: saveSheet,

    async save(req) {
      try {
        const fileName = String(req.path).split(/[\\/]/).pop();
        const format = extOf(fileName) === 'pdf' ? 'pdf' : 'docx';
        const finalName = format === 'docx' ? fileName.replace(/\.doc$/i, '.docx') : fileName;
        const data = await contentFor(format, req);
        try {
          const out = await writeDocuments(finalName, data);
          return { ok: true, path: out.path, format };
        } catch (err) {
          // storage refused: hand the file to the share sheet instead
          console.warn('Documents write failed, sharing instead', err);
          await shareFile(finalName, data);
          return { ok: true, path: finalName, format, shared: true };
        }
      } catch (err) {
        return { error: (err && err.message) || String(err) };
      }
    },

    async share(req) {
      const format = req.format === 'pdf' ? 'pdf' : 'docx';
      const fileName = `${safeName(req.name)}.${format}`;
      const data = await contentFor(format, req);
      await shareFile(fileName, data, req.name);
      return { ok: true };
    },

    async print(req) {
      try {
        const name = safeName(window.Lb.state.title) + '.pdf';
        const data = await contentFor('pdf', req || {});
        const uri = await writeCache(name, data);
        try {
          await FileOpener().openFile({ path: uri, mimeType: MIME.pdf });
          toast(IOS ? 'Tap the Share button, then Print.' : 'Use your PDF viewer’s Print option to print.', '', 4500);
        } catch (_) {
          await Share().share({ title: name, dialogTitle: 'Print or share ' + name, files: [uri] });
        }
        return { ok: true };
      } catch (err) {
        return { ok: false, reason: (err && err.message) || String(err) };
      }
    },

    /** The phone's clipboard: { type, value } (text, or a picture as a data URL). */
    async readClipboard() {
      const c = Clipboard();
      if (!c) return null;
      try { return await c.read(); } catch (e) { console.warn('Clipboard read failed', e); return null; }
    },
    async writeClipboard(text) {
      const c = Clipboard();
      if (!c) return false;
      try { await c.write({ string: text, label: 'Écritoire' }); return true; } catch (e) { console.warn('Clipboard write failed', e); return false; }
    },

    info: async () => {
      let version = '';
      try { version = (await App().getInfo()).version; } catch (_) { /* ignore */ }
      return { version: version || '', platform: Cap.getPlatform(), hasLibreOffice: false, mobile: true };
    },
    initialPath: async () => null,
    setState: () => {},
    confirmClose: () => { if (!IOS) { try { App().exitApp(); } catch (_) { /* ignore */ } } },
    newWindow: () => toast('Écritoire opens one document at a time.'),
    onCommand: () => {},
    onRequestClose: (cb) => { closeHandler = cb; }
  };
})();
