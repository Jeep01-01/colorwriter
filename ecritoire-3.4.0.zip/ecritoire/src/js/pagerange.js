/* Écritoire — page ranges for printing, like Word's "Pages" box:
 *   "1, 2, 6"   pages 1, 2 and 6
 *   "3-5"       pages 3 to 5
 *   "8-"        page 8 to the end      "-3"  pages 1 to 3
 * Commas, semicolons or spaces separate parts; en dashes work too.
 * Works in the browser (window.LbPageRange) and in Node (for tests).
 */
(function (root) {
  'use strict';

  /**
   * @param {string} text
   * @param {number} count  number of pages in the document
   * @returns {{pages: number[], error: string|null}}  1-based page numbers, in order, no repeats
   */
  function parse(text, count) {
    const src = String(text || '').trim();
    if (!src) return { pages: [], error: 'Type the pages to print, for example 1, 2, 6 or 3-5.' };
    const set = new Set();
    const outside = [];
    for (const raw of src.split(/[,;\s]+/).filter(Boolean)) {
      const part = raw.replace(/[–—]/g, '-');
      let m;
      if ((m = /^(\d+)$/.exec(part))) {
        const p = +m[1];
        if (p >= 1 && p <= count) set.add(p); else outside.push(p);
      } else if ((m = /^(\d*)-(\d*)$/.exec(part)) && (m[1] || m[2])) {
        let a = m[1] ? +m[1] : 1;
        let b = m[2] ? +m[2] : count;
        if (a > b) [a, b] = [b, a];
        if (b < 1 || a > count) { outside.push(part); continue; }
        for (let p = Math.max(1, a); p <= Math.min(count, b); p++) set.add(p);
      } else {
        return { pages: [], error: `“${raw}” isn’t a page number or range. Use numbers like 1, 2, 6 or 3-5.` };
      }
    }
    const pages = [...set].sort((x, y) => x - y);
    if (!pages.length) return { pages, error: count === 1 ? 'This document has only 1 page.' : `This document has pages 1 to ${count}.` };
    return { pages, error: outside.length ? `Page ${outside.join(', ')} isn’t in this document (pages 1 to ${count}); left out.` : null };
  }

  /** The shortest text for a set of pages: [1,2,3,6] → "1-3, 6". */
  function format(pages) {
    const ps = [...new Set(pages)].sort((x, y) => x - y);
    const out = [];
    for (let i = 0; i < ps.length; i++) {
      let j = i;
      while (j + 1 < ps.length && ps[j + 1] === ps[j] + 1) j++;
      out.push(j > i + 1 ? `${ps[i]}-${ps[j]}` : j === i + 1 ? `${ps[i]}, ${ps[j]}` : String(ps[i]));
      i = j;
    }
    return out.join(', ');
  }

  const api = { parse, format };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.LbPageRange = api;
})(typeof window !== 'undefined' ? window : globalThis);
