/* Écritoire — document templates.
 *
 * Every template is built from ordinary Écritoire content (paragraphs, headings,
 * tables, a cover page, a table of contents, footnotes, header and footer), so
 * everything stays editable and saves to .docx and PDF. Text in [brackets] is
 * meant to be replaced. All wording and artwork here is original.
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { esc } = Lb.util;

  /* ------------------------------------------------------------ */
  /* Small HTML helpers                                            */
  /* ------------------------------------------------------------ */
  const span = (text, css) => (css ? `<span style="${css}">${text}</span>` : text);
  const P = (html, css) => `<p${css ? ` style="${css}"` : ''}>${html}</p>`;
  const H = (level, text, color) => `<h${level}>${span(esc(text), color ? `color:${color}` : '')}</h${level}>`;
  const UL = (items) => `<ul data-list="disc" style="list-style-type:disc">${items.map((t) => `<li>${t}</li>`).join('')}</ul>`;
  const OL = (items) => `<ol data-list="decimal" style="list-style-type:decimal">${items.map((t) => `<li>${t}</li>`).join('')}</ol>`;
  const FN = (note) => `<sup class="lb-fn" contenteditable="false" data-note="${esc(note)}">#</sup>`;
  const BREAK = '<div class="lb-page-break" contenteditable="false"></div>';
  const today = () => new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });

  /** A table with a coloured heading row. widths are fractions of the text width. */
  function table(head, rows, color, widths) {
    const w = Lb.docparts.contentBox().w;
    const fr = widths || head.map(() => 1 / head.length);
    const cols = fr.map((f) => `<col style="width:${Math.round(w * f)}px">`).join('');
    const border = '#cbd5e1';
    const cell = (html, css) => `<td style="border:1px solid ${border}${css ? ';' + css : ''}"><p style="margin:0">${html}</p></td>`;
    return `<table class="lb-table"><colgroup>${cols}</colgroup><tbody>` +
      `<tr>${head.map((x) => cell(span(esc(x), 'font-weight:bold;color:#ffffff'), `background-color:${color}`)).join('')}</tr>` +
      rows.map((r, i) => `<tr>${r.map((x) => cell(x, i % 2 ? 'background-color:#f1f5f9' : '')).join('')}</tr>`).join('') +
      '</tbody></table>';
  }
  /** Label / value pairs without visible borders. */
  function details(pairs, color) {
    const w = Lb.docparts.contentBox().w;
    const lw = Math.round(w * 0.28);
    const cell = (html) => `<td style="border:1px solid #ffffff;padding:2pt 0"><p style="margin:0">${html}</p></td>`;
    return `<table class="lb-table"><colgroup><col style="width:${lw}px"><col style="width:${w - lw}px"></colgroup><tbody>` +
      pairs.map(([k, v]) => `<tr>${cell(span(esc(k), `font-size:9pt;font-weight:bold;letter-spacing:1pt;text-transform:uppercase;color:${color}`))}${cell(v)}</tr>`).join('') +
      '</tbody></table>';
  }
  const caption = (t) => P(span(esc(t), 'font-size:9pt;font-style:italic;color:#475569'), 'margin:0 0 12pt');
  const grey = (t) => span(t, 'color:#64748b');

  /* ------------------------------------------------------------ */
  /* Templates                                                     */
  /* ------------------------------------------------------------ */
  const T = [];

  T.push({
    id: 'report',
    name: 'Technical Report',
    desc: 'Cover page, table of contents, numbered sections, tables, footnotes, header and footer.',
    color: '#1e3a8a',
    margins: { top: 25.4, right: 25.4, bottom: 25.4, left: 25.4 },
    hf: { header: ['[Project or Report Title]', '', '[Company Name]'], footer: ['Report TR-[0001] · Rev [A]', '', 'Page {page} of {pages}'], firstDifferent: true },
    build(c) {
      return Lb.docparts.coverHtml({
        design: 'facets', color: c, kicker: 'Technical Report',
        title: '[Project or Report Title]',
        subtitle: '[One line describing the study, system or test]',
        details: [['Prepared by', '[Your Name], [Position]'], ['Prepared for', '[Client or Department]'], ['Organisation', '[Company Name]'],
          ['Report no.', 'TR-[0001]'], ['Revision', '[A] · Issued for review'], ['Date', today()]]
      }) +
      Lb.docparts.tocHtml({ title: 'Contents', levels: 2, color: c }) + BREAK +
      H(1, '1 Introduction', c) +
      P(`This report presents the [study, design review, test or investigation] carried out for [Client or Department] on [subject]. It records the approach taken, the results obtained and the recommendations that follow, in accordance with the applicable standard${FN('Replace with the standard, code or company procedure that applies to this work.')}.`) +
      H(2, '1.1 Purpose', c) +
      P('[State the question this report answers or the decision it supports. Keep it to two or three sentences.]') +
      H(2, '1.2 Scope', c) +
      P('[Describe what is included and what is not, for example the systems, locations, dates or versions covered.]') +
      H(1, '2 Background', c) +
      P('[Give the context a reader needs: the history of the project, earlier findings, and any constraints or assumptions.]') +
      H(1, '3 Methodology', c) +
      H(2, '3.1 Approach', c) +
      P('The work was carried out in the following stages:') +
      OL(['[Stage one, for example data collection or site survey]', '[Stage two, for example analysis or calculation]', '[Stage three, for example testing or verification]']) +
      H(2, '3.2 Equipment and Materials', c) +
      caption('Table 1 – Equipment used') +
      table(['Item', 'Description', 'Quantity'], [
        ['[Instrument]', '[Make, model and calibration date]', '1'],
        ['[Software]', '[Name and version]', '1'],
        ['[Material]', '[Grade or specification]', '[0]']
      ], c, [0.25, 0.55, 0.2]) +
      H(1, '4 Results', c) +
      P(`The results are summarised in Table 2. Measured values were rounded to two decimal places${FN('Rounding follows the method described in Section 3.1.')}.`) +
      caption('Table 2 – Summary of results') +
      table(['Test', 'Requirement', 'Measured', 'Result'], [
        ['[Test 1]', '[≤ 0.00]', '[0.00]', span('Pass', 'color:#15803d;font-weight:bold')],
        ['[Test 2]', '[≥ 0.00]', '[0.00]', span('Pass', 'color:#15803d;font-weight:bold')],
        ['[Test 3]', '[0.00 ± 0.00]', '[0.00]', span('Review', 'color:#b45309;font-weight:bold')]
      ], c, [0.3, 0.25, 0.25, 0.2]) +
      H(1, '5 Discussion', c) +
      P('[Explain what the results mean, compare them with the requirements or earlier work, and note any limitations or uncertainties.]') +
      H(1, '6 Conclusions and Recommendations', c) +
      P('Based on the results, the following actions are recommended:') +
      UL(['[Recommendation one, with the reason and the expected benefit]', '[Recommendation two]', '[Recommendation three]']) +
      H(1, 'References', c) +
      OL(['[Author], [Title of document], [Publisher or organisation], [Year].', '[Author], [Title of standard or paper], [Edition], [Year].']) +
      H(1, 'Appendix A – Supporting Data', c) +
      P('[Add raw data, calculations, drawings or photographs that support the report.]');
    }
  });

  T.push({
    id: 'job',
    name: 'Job Application',
    desc: 'Cover page, cover letter and a CV, with your name in the header and page numbers.',
    color: '#0f766e',
    margins: { top: 22, right: 22, bottom: 22, left: 22 },
    hf: { header: ['[Your Full Name]', '', 'Application: [Position Title]'], footer: ['', 'Page {page} of {pages}', ''], firstDifferent: true },
    build(c) {
      return Lb.docparts.coverHtml({
        design: 'band', color: c, kicker: 'Job Application',
        title: '[Position Title]',
        subtitle: '[Company Name] · Reference [Job Ref]',
        details: [['Applicant', '[Your Full Name]'], ['Email', '[name@example.com]'], ['Phone', '[+00 000 000 0000]'], ['Location', '[City, Country]'], ['Date', today()]]
      }) +
      // cover letter
      P(span('Cover Letter', `font-size:11pt;font-weight:bold;letter-spacing:2pt;text-transform:uppercase;color:${c}`), 'margin:0 0 14pt') +
      P('[Your Full Name]<br>[Street Address]<br>[City, Postcode]<br>[name@example.com] · [+00 000 000 0000]', 'margin:0 0 14pt') +
      P(today(), 'margin:0 0 14pt') +
      P('[Hiring Manager Name]<br>[Their Job Title]<br>[Company Name]<br>[Company Address]', 'margin:0 0 14pt') +
      P(span('Re: Application for [Position Title] (Reference [Job Ref])', 'font-weight:bold'), 'margin:0 0 12pt') +
      P('Dear [Hiring Manager Name],') +
      P('I am writing to apply for the position of [Position Title] advertised on [where you saw the vacancy]. With [number] years of experience in [your field], I am confident that my skills in [key skill] and [key skill] will allow me to contribute to [Company Name] from the first day.', 'text-align:justify') +
      P('In my current role as [Current Job Title] at [Current Employer], I [describe a key achievement with a measurable result, for example “reduced processing time by 20%”]. I have also [another relevant responsibility or achievement], which matches the requirements described in your advertisement.', 'text-align:justify') +
      P('I am particularly interested in [Company Name] because [a specific reason, such as its projects, values or reputation]. I would welcome the opportunity to discuss how my experience can support your team. My CV is enclosed for your review.', 'text-align:justify') +
      P('Thank you for considering my application. I look forward to hearing from you.', 'text-align:justify') +
      P('Yours sincerely,', 'margin:14pt 0 30pt') +
      P(span('[Your Full Name]', 'font-weight:bold')) +
      BREAK +
      // CV
      P(span('Curriculum Vitae', `font-size:10pt;font-weight:bold;letter-spacing:2pt;text-transform:uppercase;color:${c}`), 'margin:0 0 4pt') +
      P(span('[Your Full Name]', 'font-size:26pt;font-weight:bold;color:#111827'), 'margin:0 0 4pt;line-height:1.05') +
      P(grey('[name@example.com] · [+00 000 000 0000] · [City, Country] · [LinkedIn or portfolio link]'), 'margin:0 0 10pt') +
      H(2, 'Profile', c) +
      P('[Two or three sentences about who you are professionally, your main strengths and the kind of role you are looking for.]', 'text-align:justify') +
      H(2, 'Work Experience', c) +
      P(span('[Job Title] — [Employer]', 'font-weight:bold'), 'margin:0 0 2pt') +
      P(grey('[Month Year] – Present · [City]'), 'margin:0 0 4pt') +
      UL(['[Responsibility or achievement with a result]', '[Responsibility or achievement with a result]', '[Responsibility or achievement with a result]']) +
      P(span('[Job Title] — [Employer]', 'font-weight:bold'), 'margin:6pt 0 2pt') +
      P(grey('[Month Year] – [Month Year] · [City]'), 'margin:0 0 4pt') +
      UL(['[Responsibility or achievement with a result]', '[Responsibility or achievement with a result]']) +
      H(2, 'Education', c) +
      P(span('[Degree, Field of Study] — [University or College]', 'font-weight:bold'), 'margin:0 0 2pt') +
      P(grey('[Year] – [Year] · [Grade or honours]')) +
      H(2, 'Skills', c) +
      UL(['<b>Technical:</b> [skill], [skill], [skill]', '<b>Software:</b> [program], [program], [program]', '<b>Personal:</b> [skill], [skill], [skill]']) +
      H(2, 'Certifications and Training', c) +
      UL(['[Certificate name], [Issuing body], [Year]', '[Course name], [Provider], [Year]']) +
      H(2, 'Languages', c) +
      P('[Language] (native) · [Language] (fluent) · [Language] (basic)') +
      H(2, 'References', c) +
      P('Available on request.');
    }
  });

  T.push({
    id: 'letter',
    name: 'Business Letter',
    desc: 'Letterhead with a banner, recipient block, subject line and signature.',
    color: '#334155',
    margins: { top: 20, right: 22, bottom: 22, left: 22 },
    hf: { header: ['', '', ''], footer: ['', '[Company Name] · [Website] · [Phone]', ''], firstDifferent: false },
    build(c) {
      const box = Lb.docparts.contentBox();
      const bh = Math.round(box.h * 0.09);
      const banner = Lb.docparts.coverImage('waves', c, box.w, bh);
      return P(`<img class="lb-picture" data-lock="1" src="${banner}" style="width:${box.w}px;height:${bh}px" alt="">`, 'margin:0 0 10pt;line-height:1') +
        P(span('[Company Name]', `font-size:20pt;font-weight:bold;color:${c}`), 'margin:0 0 2pt') +
        P(grey('[Street Address] · [City, Postcode] · [Phone] · [Email]'), 'margin:0 0 26pt') +
        P(today(), 'margin:0 0 14pt') +
        P('[Recipient Name]<br>[Their Job Title]<br>[Company Name]<br>[Street Address]<br>[City, Postcode]', 'margin:0 0 16pt') +
        P(span('Subject: [What this letter is about]', 'font-weight:bold'), 'margin:0 0 12pt') +
        P('Dear [Recipient Name],') +
        P('[Opening paragraph: say why you are writing, and refer to any earlier letter, meeting or call.]', 'text-align:justify') +
        P('[Main paragraph: give the details, facts or proposal. Keep each paragraph to one idea.]', 'text-align:justify') +
        P('[Closing paragraph: say what you would like to happen next and by when, and how the reader can contact you.]', 'text-align:justify') +
        P('Yours sincerely,', 'margin:14pt 0 30pt') +
        P(span('[Your Name]', 'font-weight:bold') + '<br>' + grey('[Your Job Title]'));
    }
  });

  T.push({
    id: 'minutes',
    name: 'Meeting Minutes',
    desc: 'Meeting details, attendees, agenda, decisions and an action table.',
    color: '#4c1d95',
    margins: { top: 25.4, right: 22, bottom: 25.4, left: 22 },
    hf: { header: ['[Organisation Name]', '', 'Meeting Minutes'], footer: ['', 'Page {page} of {pages}', ''], firstDifferent: false },
    build(c) {
      return P(span('Meeting Minutes', `font-size:10pt;font-weight:bold;letter-spacing:2pt;text-transform:uppercase;color:${c}`), 'margin:0 0 4pt') +
        P(span('[Meeting Name]', 'font-size:24pt;font-weight:bold;color:#111827'), 'margin:0 0 12pt;line-height:1.05') +
        details([['Date', today()], ['Time', '[00:00] – [00:00]'], ['Location', '[Room or online link]'], ['Chair', '[Name]'], ['Minutes by', '[Name]']], c) +
        H(2, 'Attendees', c) +
        P('[Name], [Name], [Name], [Name]') +
        H(2, 'Apologies', c) +
        P('[Name], [Name]') +
        H(2, 'Agenda', c) +
        OL(['Review of the previous minutes', '[Agenda item]', '[Agenda item]', 'Any other business']) +
        H(2, 'Discussion', c) +
        H(3, '1. Review of the previous minutes') +
        P('[The minutes of the meeting held on [date] were approved / approved with changes.]') +
        H(3, '2. [Agenda item]') +
        P('[Summary of the discussion.]') +
        P(span('Decision:', 'font-weight:bold') + ' [What was agreed.]') +
        H(3, '3. [Agenda item]') +
        P('[Summary of the discussion.]') +
        P(span('Decision:', 'font-weight:bold') + ' [What was agreed.]') +
        H(2, 'Action Items', c) +
        table(['No.', 'Action', 'Owner', 'Due', 'Status'], [
          ['1', '[What needs to be done]', '[Name]', '[Date]', '[Open]'],
          ['2', '[What needs to be done]', '[Name]', '[Date]', '[Open]'],
          ['3', '[What needs to be done]', '[Name]', '[Date]', '[Done]']
        ], c, [0.08, 0.44, 0.18, 0.15, 0.15]) +
        H(2, 'Next Meeting', c) +
        P('[Date, time and location of the next meeting.]');
    }
  });

  /* ------------------------------------------------------------ */
  /* Thumbnails (simple page sketches)                             */
  /* ------------------------------------------------------------ */
  function thumb(t) {
    const c = t.color;
    const line = (y, w, x, h, col) => `<rect x="${x || 22}" y="${y}" width="${w}" height="${h || 5}" rx="2" fill="${col || '#cbd5e1'}"/>`;
    let body = '';
    if (t.id === 'report' || t.id === 'job') {
      body += `<rect x="22" y="22" width="166" height="96" fill="${c}"/><polygon points="22,118 70,118 22,80" fill="#f59e0b"/>` +
        `<polygon points="110,22 188,22 188,118 80,118" fill="#ffffff" opacity="0.14"/>` +
        line(136, 50, 22, 6, c) + line(150, 140, 22, 14, '#1f2937') + line(172, 110, 22, 8, '#94a3b8') +
        [200, 214, 228, 242].map((y) => line(y, 40, 22, 5, c) + line(y, 90, 70, 5)).join('');
    } else if (t.id === 'letter') {
      body += `<rect x="22" y="18" width="166" height="20" fill="${c}" opacity="0.25"/><path d="M22 34 Q70 22 120 32 T188 28 V38 H22z" fill="${c}" opacity="0.5"/>` +
        line(46, 80, 22, 10, c) + line(60, 120) + line(84, 40) + [100, 108, 116].map((y) => line(y, 60)).join('') + line(132, 100, 22, 6, '#475569') +
        [148, 156, 164, 172, 186, 194, 202, 210, 224, 232, 240].map((y, i) => line(y, i % 4 === 3 ? 110 : 166)).join('') + line(262, 50, 22, 6, '#475569');
    } else {
      body += line(20, 166, 22, 2, '#cbd5e1') + line(30, 50, 22, 5, c) + line(40, 120, 22, 12, '#1f2937') +
        [62, 72, 82, 92].map((y) => line(y, 30, 22, 5, c) + line(y, 80, 60)).join('') + line(110, 50, 22, 7, c) + line(122, 140) +
        line(140, 50, 22, 7, c) + [152, 162, 172].map((y) => line(y, 120, 34)).join('') + line(190, 60, 22, 7, c) +
        `<rect x="22" y="202" width="166" height="10" fill="${c}"/>` + [214, 226, 238].map((y) => `<rect x="22" y="${y}" width="166" height="10" fill="${y % 24 ? '#f1f5f9' : '#ffffff'}" stroke="#cbd5e1" stroke-width="0.6"/>`).join('');
    }
    return `<svg viewBox="0 0 210 297" xmlns="http://www.w3.org/2000/svg"><rect width="210" height="297" fill="#ffffff"/>${body}</svg>`;
  }

  /* ------------------------------------------------------------ */
  /* Gallery and applying a template                               */
  /* ------------------------------------------------------------ */
  async function apply(t) {
    if (!(await Lb.docparts.gate('template'))) return;
    if (!(await Lb.app.confirmDiscard())) return;
    // build at the template's margins on the current paper size (portrait)
    Lb.settings.margins = Object.assign({}, t.margins);
    Lb.settings.orientation = 'portrait';
    Lb.layout.applyMargins();
    const html = t.build(t.color);
    Lb.app.loadDocument(html, {
      margins: t.margins, paper: Lb.settings.paper, orientation: 'portrait', hf: t.hf
    }, { title: t.name, ext: '.docx' });
    Lb.state.dirty = false;
    Lb.ui.toast('Replace the text in [brackets] with your own.', '', 4500);
  }

  async function gallery() {
    const locked = !!(Lb.pro && !Lb.pro.has());
    let chosen = T[0];
    const body = Lb.ui.h('div');
    body.innerHTML = `<p class="hint" style="margin-top:0">Pick a template to start a new document. Everything in it can be edited.</p><div class="tpl-grid"></div>`;
    const grid = body.querySelector('.tpl-grid');
    for (const t of T) {
      const card = Lb.ui.h('button', { type: 'button', class: 'tpl-card' + (t === chosen ? ' on' : ''), title: t.name });
      card.innerHTML = `<div class="tpl-thumb">${thumb(t)}</div><div class="tpl-name">${esc(t.name)}${locked ? '<span class="tpl-pro">PRO</span>' : ''}</div><div class="tpl-desc">${esc(t.desc)}</div>`;
      card.addEventListener('click', () => {
        chosen = t;
        for (const x of grid.children) x.classList.toggle('on', x === card);
        for (const x of grid.children) x.style.borderColor = x === card ? 'var(--amber)' : '';
      });
      card.addEventListener('dblclick', () => { chosen = t; body.closest('.modal').querySelector('footer .btn.primary').click(); });
      grid.append(card);
    }
    grid.firstChild.style.borderColor = 'var(--amber)';
    const res = await Lb.ui.modal({
      title: 'Templates', width: 720, body,
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: locked ? 'Use template · Pro' : 'Use template', value: 'use', primary: true }]
    });
    if (res.value === 'use') await apply(chosen);
  }

  Lb.register('templates', () => gallery());
  Lb.templates = { list: T, apply, gallery, thumb };
})();
