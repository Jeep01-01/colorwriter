/* Écritoire — text wrapping and layering for pictures and shapes (like Word's
 * Layout Options): In Line with Text, Square, Tight, Top and Bottom, Behind Text,
 * In Front of Text; Bring to Front / Forward, Send to Back / Backward; moving a
 * floating object by dragging it; Shape Fill and Shape Outline menus.
 *
 * The state lives on the element (see content.css):
 *   data-wrap  square | tight | topbottom | behind | front   (none = in line)
 *   data-side  left | right (square, tight) · left | center | right (topbottom)
 *   data-z     stacking order of free objects (behind and front)
 *   style.left / style.top   position of a free object inside its paragraph
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const W = {};
  const MODES = [
    ['inline', 'In Line with Text', 'wrapInline'],
    ['square', 'Square', 'wrapSquare'],
    ['tight', 'Tight', 'wrapTight'],
    ['topbottom', 'Top and Bottom', 'wrapTopBottom'],
    ['behind', 'Behind Text', 'wrapBehind'],
    ['front', 'In Front of Text', 'wrapFront']
  ];
  W.MODES = MODES;
  const FREE = new Set(['behind', 'front']);
  const z = () => Lb.state.zoom;
  const ed = () => Lb.els.editor;

  W.mode = (img) => (img && img.dataset.wrap) || 'inline';
  W.isFree = (img) => FREE.has(W.mode(img));
  W.canWrap = (img) => !!img && img.tagName === 'IMG' && ed().contains(img);
  const allFree = () => [...ed().querySelectorAll('img[data-wrap="behind"], img[data-wrap="front"]')];

  /** Apply the inline styles that follow from the data attributes. */
  W.sync = (img) => {
    const m = W.mode(img);
    if (FREE.has(m)) {
      const zi = +img.dataset.z || 1;
      img.style.zIndex = String(m === 'behind' ? -1000 + zi : 10 + zi);
    } else {
      img.style.removeProperty('z-index');
      img.style.removeProperty('left');
      img.style.removeProperty('top');
    }
    // tight: text follows the outline of a shape (pictures keep their box)
    if (m === 'tight' && img.classList.contains('lb-shape') && img.src) img.style.shapeOutside = `url("${img.src}")`;
    else img.style.removeProperty('shape-outside');
    if (!img.getAttribute('style')) img.removeAttribute('style');
  };

  /** The paragraph (or cell) a free object is positioned in. */
  function anchorOf(img) {
    let a = img.parentElement;
    while (a && a !== ed() && !a.matches('p,h1,h2,h3,h4,h5,h6,li,blockquote,pre,td,th')) a = a.parentElement;
    return a && a !== ed() ? a : null;
  }
  /** Position a free object so its top-left corner lands on (x, y) in page coordinates (unzoomed px). */
  function placeAt(img, x, y) {
    const a = anchorOf(img);
    if (!a) return;
    const pr = Lb.els.page.getBoundingClientRect();
    const ar = a.getBoundingClientRect();
    const ax = (ar.left - pr.left) / z() + a.clientLeft, ay = (ar.top - pr.top) / z() + a.clientTop;
    img.style.left = Math.round(x - ax) + 'px';
    img.style.top = Math.round(y - ay) + 'px';
  }
  const pageXY = (r) => {
    const pr = Lb.els.page.getBoundingClientRect();
    return { x: (r.left - pr.left) / z(), y: (r.top - pr.top) / z() };
  };

  /** Make sure the object sits inside a paragraph (never directly in the document). */
  function ensureAnchor(img) {
    if (anchorOf(img)) return;
    const p = document.createElement('p');
    img.before(p);
    p.append(img);
  }

  /** Change how text wraps around the object, keeping it where it is on the page. */
  W.setMode = (img, mode, opts) => {
    if (!W.canWrap(img)) return;
    const o = opts || {};
    const was = W.mode(img);
    if (was === mode && !o.side) return;
    if (!o.inHistory) Lb.history.checkpoint();
    const before = pageXY(img.getBoundingClientRect());
    ensureAnchor(img);
    if (mode === 'inline') { delete img.dataset.wrap; delete img.dataset.side; delete img.dataset.z; }
    else img.dataset.wrap = mode;
    if (mode === 'square' || mode === 'tight') {
      if (o.side) img.dataset.side = o.side;
      else if (img.dataset.side !== 'right') {
        // keep it on the side of the page it was on
        const a = anchorOf(img);
        const mid = a ? (a.getBoundingClientRect().left + a.getBoundingClientRect().width / 2) : 0;
        if (a && img.getBoundingClientRect().left + img.getBoundingClientRect().width / 2 > mid + 1) img.dataset.side = 'right';
        else delete img.dataset.side;
      }
    } else if (mode === 'topbottom') {
      img.dataset.side = o.side || (img.closest('[style*="text-align: center"],[style*="text-align:center"]') ? 'center' : (img.dataset.side === 'right' ? 'right' : 'left'));
      if (img.dataset.side === 'left') delete img.dataset.side;
    } else if (FREE.has(mode)) {
      delete img.dataset.side;
      if (!FREE.has(was) || !img.dataset.z) img.dataset.z = String(topZ(mode) + 1);
    }
    W.sync(img);
    if (FREE.has(mode)) placeAt(img, before.x, before.y);
    Lb.layout.refresh();
    if (!o.inHistory) Lb.history.commit();
    Lb.objects.refresh();
  };
  W.setSide = (img, side) => {
    const m = W.mode(img);
    if (m === 'inline' || FREE.has(m)) return;
    Lb.history.checkpoint();
    if (side === 'left') delete img.dataset.side; else img.dataset.side = side;
    W.sync(img);
    Lb.layout.refresh();
    Lb.history.commit();
    Lb.objects.refresh();
  };

  /* ---------- layering ---------- */
  function topZ(mode) {
    let m = 0;
    for (const o of allFree()) if (W.mode(o) === mode) m = Math.max(m, +o.dataset.z || 0);
    return m;
  }
  /** Renumber 1..n inside each layer, keeping the order. */
  function renumber() {
    for (const mode of FREE) {
      const list = allFree().filter((o) => W.mode(o) === mode).sort((a, b) => (+a.dataset.z || 0) - (+b.dataset.z || 0));
      list.forEach((o, i) => { o.dataset.z = String(i + 1); W.sync(o); });
    }
  }
  /**
   * Bring to Front / Forward and Send Backward / to Back. An object that isn't free
   * yet becomes "In Front of Text" (front, forward) or "Behind Text" (back,
   * backward), since only free objects can overlap.
   */
  W.order = (img, how) => {
    if (!W.canWrap(img)) return;
    Lb.history.checkpoint();
    if (!W.isFree(img)) {
      const to = how === 'front' || how === 'forward' ? 'front' : 'behind';
      W.setMode(img, to, { inHistory: true });
      Lb.ui.toast(to === 'front' ? 'Changed to “In Front of Text” so it can be layered.' : 'Changed to “Behind Text” so it can be layered.');
    }
    const mode = W.mode(img);
    const list = allFree().filter((o) => W.mode(o) === mode).sort((a, b) => (+a.dataset.z || 0) - (+b.dataset.z || 0));
    const i = list.indexOf(img);
    list.splice(i, 1);
    const at = how === 'front' ? list.length : how === 'back' ? 0 : how === 'forward' ? Math.min(list.length, i + 1) : Math.max(0, i - 1);
    list.splice(at, 0, img);
    list.forEach((o, k) => { o.dataset.z = String(k + 1); W.sync(o); });
    Lb.history.commit();
    Lb.objects.refresh();
  };

  /* ---------- moving by dragging ---------- */
  function blockAtPoint(x, y) {
    let r = null;
    if (document.caretRangeFromPoint) r = document.caretRangeFromPoint(x, y);
    else if (document.caretPositionFromPoint) {
      const p = document.caretPositionFromPoint(x, y);
      if (p) { r = document.createRange(); r.setStart(p.offsetNode, p.offset); r.collapse(true); }
    }
    if (!r || !ed().contains(r.startContainer)) return { range: null };
    const n = r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement;
    if (n.closest('img,.lb-video,.lb-page-break,.lb-toc')) return { range: null };
    return { range: r };
  }

  function startDrag(e, img) {
    const mode = W.mode(img);
    if (mode === 'inline') return;
    e.preventDefault(); e.stopPropagation();
    const sx = e.clientX, sy = e.clientY;
    const start = pageXY(img.getBoundingClientRect());
    let moved = false;
    Lb.history.checkpoint();
    const ov = Lb.els.overlay;
    const move = (ev) => {
      const dx = (ev.clientX - sx) / z(), dy = (ev.clientY - sy) / z();
      if (!moved && Math.abs(dx) + Math.abs(dy) < 3) return;
      moved = true;
      if (FREE.has(mode)) {
        const pw = Lb.pageW();
        const x = Math.max(-img.offsetWidth + 20, Math.min(pw - 20, start.x + dx));
        placeAt(img, x, start.y + dy);
      } else {
        img.style.transform = `translate(${dx}px, ${dy}px)`;
        img.style.opacity = '0.6';
      }
      Lb.objects.refresh();
    };
    const up = (ev) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      ov.classList.remove('dragging');
      if (!moved) { Lb.history.commit(); return; }
      if (FREE.has(mode)) reanchor(img);
      else dropFloat(img, ev.clientX, ev.clientY);
      Lb.layout.refresh();
      Lb.history.commit();
      Lb.objects.select(img);
    };
    ov.classList.add('dragging');
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
  }

  /** After a free object moved, belong to the paragraph it now sits next to (so it moves with that text). */
  function reanchor(img) {
    const r = img.getBoundingClientRect();
    const keep = pageXY(r);
    const prevVis = img.style.visibility;
    img.style.visibility = 'hidden';
    const edR = ed().getBoundingClientRect();
    const probeX = Math.min(Math.max(r.left + 4, edR.left + 2), edR.right - 2);
    const probeY = Math.min(Math.max(r.top + 2, edR.top + 2), edR.bottom - 2);
    const { range } = blockAtPoint(probeX, probeY);
    img.style.visibility = prevVis;
    if (range) {
      const block = Lb.closestBlock(range.startContainer);
      if (block && block !== anchorOf(img) && !block.closest('.lb-toc') && !block.contains(img)) {
        const old = img.parentNode;
        block.prepend(img);
        tidyEmpty(old);
      }
    }
    placeAt(img, keep.x, keep.y);
  }

  /** Square / tight / top and bottom: drop at a place in the text; the side follows the pointer. */
  function dropFloat(img, cx, cy) {
    img.style.removeProperty('transform');
    img.style.removeProperty('opacity');
    const mode = W.mode(img);
    img.style.visibility = 'hidden';
    const { range } = blockAtPoint(cx, cy);
    img.style.visibility = '';
    if (!img.getAttribute('style')) img.removeAttribute('style');
    const edR = ed().getBoundingClientRect();
    const t = (cx - edR.left) / edR.width;
    if (mode === 'topbottom') img.dataset.side = t < 0.34 ? 'left' : t > 0.66 ? 'right' : 'center';
    else img.dataset.side = t < 0.5 ? 'left' : 'right';
    if (img.dataset.side === 'left') delete img.dataset.side;
    if (range) {
      const old = img.parentNode;
      // floats are placed at the start of the line they're dropped on
      const r = range.cloneRange();
      try {
        r.insertNode(img);
      } catch (_) { /* leave it where it was */ }
      if (old !== img.parentNode) tidyEmpty(old);
    }
    W.sync(img);
  }

  function tidyEmpty(el) {
    if (!el || el === ed() || !Lb.isBlock(el)) return;
    if (!el.textContent.replace(/​/g, '').trim() && !el.querySelector('img,br,.lb-video,table')) el.innerHTML = '<br>';
  }

  /* ---------- selecting objects that are behind the text ---------- */
  function overText(x, y) {
    const r = document.caretRangeFromPoint ? document.caretRangeFromPoint(x, y) : null;
    if (!r || r.startContainer.nodeType !== 3) return false;
    const t = r.startContainer;
    for (const off of [r.startOffset - 1, r.startOffset]) {
      if (off < 0 || off >= t.length) continue;
      const cr = document.createRange();
      cr.setStart(t, off); cr.setEnd(t, off + 1);
      for (const b of cr.getClientRects()) if (x >= b.left - 1 && x <= b.right + 1 && y >= b.top - 1 && y <= b.bottom + 1) return true;
    }
    return false;
  }
  function behindAt(x, y) {
    for (const el of document.elementsFromPoint(x, y)) {
      if (el.tagName === 'IMG' && el.dataset.wrap === 'behind' && ed().contains(el)) return el;
    }
    return null;
  }

  /* ---------- menus ---------- */
  const sel = () => Lb.objects.selected();
  const item = (label, fn, o) => Lb.ui.menuItem(label, fn, o);

  function wrapItems(img, withOrder) {
    const h = Lb.ui.h;
    const box = h('div', { class: 'wrap-menu' });
    const cur = W.mode(img);
    box.append(Lb.ui.menuTitle('Text wrapping'));
    for (const [m, label, icon] of MODES) box.append(item(label, () => W.setMode(img, m), { icon, checkable: true, checked: cur === m }));
    if (cur === 'square' || cur === 'tight' || cur === 'topbottom') {
      box.append(Lb.ui.menuSep(), Lb.ui.menuTitle('Position'));
      const side = img.dataset.side || 'left';
      const sides = cur === 'topbottom' ? [['left', 'Left'], ['center', 'Center'], ['right', 'Right']] : [['left', 'Left'], ['right', 'Right']];
      for (const [s, label] of sides) box.append(item(label, () => W.setSide(img, s), { icon: s === 'left' ? 'alignLeft' : s === 'right' ? 'alignRight' : 'alignCenter', checkable: true, checked: side === s }));
    }
    if (withOrder) {
      box.append(Lb.ui.menuSep(), Lb.ui.menuTitle('Arrange'));
      box.append(...orderItems(img));
    }
    return box;
  }
  function orderItems(img) {
    return [
      item('Bring to Front', () => W.order(img, 'front'), { icon: 'bringFront' }),
      item('Bring Forward', () => W.order(img, 'forward'), { icon: 'bringForward' }),
      item('Send Backward', () => W.order(img, 'backward'), { icon: 'sendBackward' }),
      item('Send to Back', () => W.order(img, 'back'), { icon: 'sendBack' })
    ];
  }

  Lb.menus.wrapMenu = () => { const img = sel(); return img && W.canWrap(img) ? wrapItems(img, false) : null; };
  Lb.menus.layoutOptionsMenu = () => { const img = sel(); return img && W.canWrap(img) ? wrapItems(img, true) : null; };
  Lb.menus.bringMenu = () => {
    const img = sel(); if (!img || !W.canWrap(img)) return null;
    const box = Lb.ui.h('div');
    box.append(item('Bring to Front', () => W.order(img, 'front'), { icon: 'bringFront' }),
      item('Bring Forward', () => W.order(img, 'forward'), { icon: 'bringForward' }),
      item('Bring in Front of Text', () => W.setMode(img, 'front'), { icon: 'wrapFront' }));
    return box;
  };
  Lb.menus.sendMenu = () => {
    const img = sel(); if (!img || !W.canWrap(img)) return null;
    const box = Lb.ui.h('div');
    box.append(item('Send to Back', () => W.order(img, 'back'), { icon: 'sendBack' }),
      item('Send Backward', () => W.order(img, 'backward'), { icon: 'sendBackward' }),
      item('Send Behind Text', () => W.setMode(img, 'behind'), { icon: 'wrapBehind' }));
    return box;
  };

  /* ---------- shape fill and outline ---------- */
  const WEIGHTS = [0.5, 1, 1.5, 2, 3, 4.5, 6, 8, 12];
  W.setShapeStyle = (img, change) => {
    if (!img || !img.classList.contains('lb-shape')) return;
    Lb.history.checkpoint();
    if ('fill' in change) { if (change.fill) { img.dataset.fill = change.fill; delete img.dataset.nofill; } else img.dataset.nofill = '1'; }
    if ('stroke' in change) { if (change.stroke) { img.dataset.stroke = change.stroke; delete img.dataset.nostroke; } else img.dataset.nostroke = '1'; }
    if ('sw' in change) { img.dataset.sw = String(change.sw); delete img.dataset.nostroke; }
    Lb.objects.renderShape(img);
    Lb.history.commit();
    Lb.emit('shapeStyle', img);
    syncSwatches();
  };
  Lb.menus.shapeFillMenu = () => {
    const img = sel(); if (!img || !img.classList.contains('lb-shape')) return null;
    return Lb.ui.palette((c) => W.setShapeStyle(img, { fill: c }), { autoLabel: 'No Fill', autoIcon: 'close', current: img.dataset.nofill === '1' ? null : (img.dataset.fill || '#f59e0b') });
  };
  Lb.menus.shapeOutlineMenu = () => {
    const img = sel(); if (!img || !img.classList.contains('lb-shape')) return null;
    const cur = img.dataset.sw != null ? +img.dataset.sw : 2;
    const weights = [Lb.ui.menuSep(), Lb.ui.menuTitle('Weight')];
    for (const w of WEIGHTS) {
      const line = Lb.ui.h('i', { class: 'weight-line', style: { height: Math.max(1, Math.min(8, w)) + 'px' } });
      const b = item(w + ' px', () => W.setShapeStyle(img, { sw: w }), { checkable: true, checked: img.dataset.nostroke !== '1' && cur === w });
      b.prepend(line);
      weights.push(b);
    }
    return Lb.ui.palette((c) => W.setShapeStyle(img, { stroke: c }), { autoLabel: 'No Outline', autoIcon: 'close', current: img.dataset.nostroke === '1' ? null : (img.dataset.stroke || '#1f1f1f'), extra: weights });
  };
  function syncSwatches() {
    const img = sel();
    const f = document.getElementById('shapeFillSwatch'), s = document.getElementById('shapeOutlineSwatch');
    if (!img || !img.classList.contains('lb-shape')) return;
    const none = 'repeating-linear-gradient(45deg,#fff 0 3px,#d33 3px 4px)';
    const fillBg = img.dataset.nofill === '1' ? none : (img.dataset.fill || '#f59e0b');
    const lineBg = img.dataset.nostroke === '1' ? none : (img.dataset.stroke || '#1f1f1f');
    if (f) f.style.background = fillBg;
    if (s) s.style.background = lineBg;
    for (const el of document.querySelectorAll('.sidebar .sw-fill')) el.style.background = fillBg;
    for (const el of document.querySelectorAll('.sidebar .sw-outline')) el.style.background = lineBg;
  }
  W.syncRibbon = () => {
    const img = sel();
    const shape = !!img && img.classList.contains('lb-shape');
    const wrappable = !!img && W.canWrap(img);
    for (const g of document.querySelectorAll('[data-panel="format"] [data-for]')) {
      const f = g.dataset.for;
      g.hidden = f === 'shape' ? !shape : f === 'wrap' ? !wrappable : false;
    }
    syncSwatches();
    const lo = document.getElementById('layoutOptionsBtn');
    if (lo) lo.hidden = !wrappable;
  };

  /* ---------- after opening a document ---------- */
  /** Where Word measured a position from, as a range on the page: [start, size] in px. */
  function wordBase(rel, axis, img, k) {
    const m = Lb.settings.margins, pw = Lb.pageW(), ph = Lb.pageH();
    const ml = Lb.mm(m.left), mr = Lb.mm(m.right), mt = Lb.mm(m.top), mb = Lb.mm(m.bottom);
    const a = anchorOf(img);
    const ar = a ? a.getBoundingClientRect() : null;
    if (axis === 'h') {
      const cell = img.closest('td,th');
      if (cell && (rel === 'column' || rel === 'character')) {
        const r = cell.getBoundingClientRect();
        return [pageXY(r).x, r.width / z()];
      }
      if (rel === 'page') return [0, pw];
      if (rel === 'leftMargin' || rel === 'insideMargin') return [0, ml];
      if (rel === 'rightMargin' || rel === 'outsideMargin') return [pw - mr, mr];
      return [ml, pw - ml - mr];
    }
    const top = k * ph;
    if (rel === 'page') return [top, ph];
    if (rel === 'margin') return [top + mt, ph - mt - mb];
    if (rel === 'topMargin') return [top, mt];
    if (rel === 'bottomMargin') return [top + ph - mb, mb];
    return ar ? [pageXY(ar).y, ar.height / z()] : [top + mt, 0];
  }
  function wordPos(spec, axis, img, k, size) {
    const [rel, a, b] = String(spec || '').split(':');
    const [start, len] = wordBase(rel, axis, img, k);
    if (a === 'align') {
      if (b === 'center') return start + (len - size) / 2;
      if (b === 'right' || b === 'bottom' || b === 'outside') return start + len - size;
      return start;
    }
    return start + (+a || 0);
  }

  /**
   * After a .docx is opened: shapes saved by Écritoire become editable again, and
   * pictures that float in Word get their side (square, tight, top and bottom) or
   * their place on the page (behind or in front of text).
   */
  W.afterLoad = () => {
    for (const img of ed().querySelectorAll('img.lb-shape[data-restore]')) {
      delete img.dataset.restore;
      Lb.objects.renderShape(img);
      Lb.objects.applyFilter(img);
    }
    const list = [...ed().querySelectorAll('img[data-ah], img[data-av]')];
    if (list.length) {
      const ph = Lb.pageH();
      const pageOf = (img) => { const a = anchorOf(img) || img; return Math.max(0, Math.floor(pageXY(a.getBoundingClientRect()).y / ph)); };
      for (const img of list) {
        ensureAnchor(img);
        if (FREE.has(W.mode(img))) continue;
        const w = img.offsetWidth || parseFloat(img.style.width) || 0;
        const x = wordPos(img.dataset.ah, 'h', img, pageOf(img), w);
        const [cl, cw] = wordBase('column', 'h', img, 0);
        const t = (x + w / 2 - cl) / (cw || 1);
        if (W.mode(img) === 'topbottom') img.dataset.side = t < 0.34 ? 'left' : t > 0.66 ? 'right' : 'center';
        else img.dataset.side = t > 0.5 ? 'right' : 'left';
        if (img.dataset.side === 'left') delete img.dataset.side;
      }
      Lb.layout.refresh();
      for (const img of list) {
        if (FREE.has(W.mode(img))) {
          W.sync(img);
          const k = pageOf(img);
          const w = img.offsetWidth || 0, hh = img.offsetHeight || 0;
          placeAt(img, wordPos(img.dataset.ah, 'h', img, k, w), wordPos(img.dataset.av, 'v', img, k, hh));
        }
        delete img.dataset.ah; delete img.dataset.av;
      }
    }
    for (const img of ed().querySelectorAll('img[data-tight]')) {
      if (img.dataset.wrap === 'square') img.dataset.wrap = 'tight';
      delete img.dataset.tight;
    }
    for (const img of ed().querySelectorAll('img[data-z]')) if (!FREE.has(W.mode(img))) delete img.dataset.z;
    renumber();
    for (const img of ed().querySelectorAll('img[data-wrap]')) W.sync(img);
  };

  W.init = () => {
    // a small button beside the selected picture or shape opens the layout options (like Word)
    const ov = Lb.els.overlay;
    const lo = Lb.ui.h('button', { class: 'lo-btn', id: 'layoutOptionsBtn', type: 'button', title: 'Layout options: text wrapping and arrange', 'data-menu': 'layoutOptionsMenu' });
    lo.append(Lb.ui.icon('layoutOptions'));
    ov.append(lo);
    const frame = ov.querySelector('.obj-frame');
    frame.addEventListener('pointerdown', (e) => {
      const img = sel();
      if (img && W.mode(img) !== 'inline' && e.button === 0) startDrag(e, img);
    });
    frame.addEventListener('dblclick', () => Lb.objects.showPane());
    // a click on empty space over an object behind the text selects that object
    ed().addEventListener('click', (e) => {
      if (e.target.closest && e.target.closest('img,.lb-video')) return;
      const b = behindAt(e.clientX, e.clientY);
      if (b && !overText(e.clientX, e.clientY)) Lb.objects.select(b);
    });
    Lb.on('restored', () => { for (const img of ed().querySelectorAll('img[data-wrap]')) W.sync(img); });
  };

  Lb.wrap = W;
})();
