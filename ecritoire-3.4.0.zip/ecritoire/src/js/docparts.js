/* Écritoire — document parts: header & footer, footnotes, table of contents and cover pages.
 *
 *  - Header & footer: left / centre / right text on every page, {page} and {pages}
 *    become page numbers; optionally nothing on the first (cover) page.
 *  - Footnotes: <sup class="lb-fn" data-note="…">, numbered automatically and shown
 *    at the bottom of the page where they appear (the layout keeps room for them).
 *  - Table of contents: <div class="lb-toc">, rebuilt from Heading 1–3 with page numbers.
 *  - Cover page: an original banner picture drawn here, a title block and details.
 * All included in this edition (a later paid edition can check a purchase through Lb.pro).
 */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { esc } = Lb.util;
  const D = {};

  /* ------------------------------------------------------------ */
  /* Settings                                                      */
  /* ------------------------------------------------------------ */
  const emptyHf = () => ({ header: ['', '', ''], footer: ['', '', ''], firstDifferent: false });
  D.normalizeHf = (hf) => {
    const o = emptyHf();
    if (!hf) return o;
    for (const k of ['header', 'footer']) if (Array.isArray(hf[k])) o[k] = [0, 1, 2].map((i) => String(hf[k][i] || ''));
    o.firstDifferent = !!hf.firstDifferent;
    return o;
  };
  Lb.settings.hf = emptyHf();
  const hf = () => Lb.settings.hf || (Lb.settings.hf = emptyHf());
  const filled = (slots) => Array.isArray(slots) && slots.some((t) => t && String(t).trim());
  D.hasAnyHf = () => filled(hf().header) || filled(hf().footer);
  D.hasHeader = (k) => filled(hf().header) && !(k === 0 && hf().firstDifferent);
  D.hasFooter = (k) => filled(hf().footer) && !(k === 0 && hf().firstDifferent);

  /** The caret position when a command starts (dialogs move the focus away). */
  function takeCaret() {
    const ed = Lb.els.editor;
    const r = Lb.sel.range();
    if (r && Lb.sel.inEditor(r)) return r.cloneRange();
    return Lb.savedRange && ed.contains(Lb.savedRange.commonAncestorContainer) ? Lb.savedRange.cloneRange() : null;
  }
  /** Put the caret back exactly where it was (falls back to the end of the document). */
  function giveCaret(saved) {
    const ed = Lb.els.editor;
    ed.focus({ preventScroll: true });
    const s = window.getSelection();
    s.removeAllRanges();
    if (saved && ed.contains(saved.commonAncestorContainer)) s.addRange(saved);
    else { const r = document.createRange(); r.selectNodeContents(ed.lastElementChild || ed); r.collapse(false); s.addRange(r); }
    Lb.sel.save();
    return s.getRangeAt(0);
  }

  /** Purchase check for a later paid edition; without Lb.pro everything is unlocked. */
  async function gate(reason) {
    if (!Lb.pro) return true;
    return (await Lb.pro.require(reason || 'feature')) === 'pro';
  }
  D.gate = gate;

  /* ------------------------------------------------------------ */
  /* Page decorations: header, footer and footnotes of page k      */
  /* (positions are relative to the top of that page)              */
  /* ------------------------------------------------------------ */
  const fillTokens = (t, k, n) => esc(t || '').replace(/\{page\}/g, String(k + 1)).replace(/\{pages\}/g, String(n));

  D.pageDecor = (k, n) => {
    const m = Lb.settings.margins;
    const ph = Lb.pageH();
    const l = Lb.mm(m.left), r = Lb.mm(m.right), mt = Lb.mm(m.top), mb = Lb.mm(m.bottom);
    const row = (slots, cls, pos) => `<div class="lb-hf ${cls}" style="${pos};left:${l}px;right:${r}px">` +
      slots.map((t, i) => (t && t.trim() ? `<span class="s${i}">${fillTokens(t, k, n)}</span>` : '')).join('') + '</div>';
    let html = '';
    if (D.hasHeader(k)) html += row(hf().header, 'lb-header', `top:${Math.max(4, Math.min(Lb.mm(12.7), mt * 0.45))}px`);
    if (D.hasFooter(k)) html += row(hf().footer, 'lb-footer', `bottom:${Math.max(4, Math.min(Lb.mm(12.7), mb * 0.45))}px`);
    const notes = Lb.layout.notePages()[k];
    if (notes && notes.length) {
      const top = ph - mb - (Lb.layout.noteReserve()[k] || 0);
      html += `<div class="lb-content lb-notes" style="top:${top}px;left:${l}px;right:${r}px"><div class="lb-notes-sep"></div>` +
        notes.map((f) => `<div class="lb-note" data-n="${esc(f.textContent)}"><sup>${esc(f.textContent)}</sup><span>${esc(f.dataset.note || '')}</span></div>`).join('') + '</div>';
    }
    return html;
  };

  let decor = null;
  function renderDecor() {
    if (!decor) return;
    if (!Lb.state.preview) { decor.innerHTML = ''; return; }
    const n = Lb.layout.pageCount();
    const ph = Lb.pageH();
    let html = '';
    for (let k = 0; k < n; k++) {
      const inner = D.pageDecor(k, n);
      if (inner) html += `<div class="lb-pd" style="top:${k * ph}px;height:${ph}px">${inner}</div>`;
    }
    if (decor.innerHTML !== html) decor.innerHTML = html;
  }

  /* ------------------------------------------------------------ */
  /* Header & footer dialog                                        */
  /* ------------------------------------------------------------ */
  async function headerFooterDialog() {
    if (!D.hasAnyHf() && !(await gate('feature'))) return;
    const cur = hf();
    const inputs = (key, label) => `<div class="hf-row"><div class="hf-label">${label}</div><div class="hf-slots">` +
      ['Left', 'Centre', 'Right'].map((p, i) => `<input type="text" data-k="${key}" data-i="${i}" placeholder="${p}" value="${esc(cur[key][i])}">`).join('') + '</div></div>';
    const body = `
      ${inputs('header', 'Header')}
      ${inputs('footer', 'Footer')}
      <div class="hf-tools">
        <button type="button" class="btn small" id="hfNum">Add page numbers</button>
        <span class="hint">{page} is the page number, {pages} the number of pages.</span>
      </div>
      <label class="check"><input type="checkbox" id="hfFirst"${cur.firstDifferent ? ' checked' : ''}> Different first page (nothing on the cover page)</label>`;
    const buttons = [{ label: 'Cancel', value: 'cancel' }, { label: 'Apply', value: 'ok', primary: true }];
    if (D.hasAnyHf()) buttons.unshift({ label: 'Remove', value: 'remove', danger: true, left: true });
    const res = await Lb.ui.modal({
      title: 'Header & Footer', width: 560, body, buttons,
      init: (dlg) => {
        dlg.querySelector('#hfNum').addEventListener('click', () => {
          const f = [...dlg.querySelectorAll('input[data-k="footer"]')];
          const target = !f[1].value.trim() ? f[1] : !f[2].value.trim() ? f[2] : f[1];
          target.value = 'Page {page} of {pages}';
          target.focus();
        });
      }
    });
    if (res.value === 'cancel') return;
    if (res.value === 'remove') Lb.settings.hf = emptyHf();
    else {
      const next = emptyHf();
      for (const inp of res.root.querySelectorAll('input[data-k]')) next[inp.dataset.k][+inp.dataset.i] = inp.value;
      next.firstDifferent = res.root.querySelector('#hfFirst').checked;
      Lb.settings.hf = next;
    }
    Lb.emit('settings');
    Lb.layout.refresh();
  }

  /* ------------------------------------------------------------ */
  /* Footnotes                                                     */
  /* ------------------------------------------------------------ */
  async function footnoteDialog(existing) {
    const body = `<p class="hint" style="margin-top:0">${existing ? 'Edit the text of footnote ' + esc(existing.textContent) + '.' : 'The number is added where the cursor is, and the note appears at the bottom of that page.'}</p>
      <textarea id="fnText" rows="4" style="width:100%;resize:vertical" placeholder="Footnote text">${existing ? esc(existing.dataset.note || '') : ''}</textarea>`;
    const buttons = existing
      ? [{ label: 'Delete', value: 'delete', danger: true, left: true }, { label: 'Cancel', value: 'cancel' }, { label: 'Save', value: 'ok', primary: true }]
      : [{ label: 'Cancel', value: 'cancel' }, { label: 'Insert', value: 'ok', primary: true }];
    const res = await Lb.ui.modal({ title: existing ? 'Footnote' : 'Insert Footnote', width: 460, body, buttons });
    if (res.value === 'cancel') return null;
    return { action: res.value, text: res.root.querySelector('#fnText').value.trim() };
  }

  async function insertFootnote() {
    const saved = takeCaret();
    if (!(await gate('feature'))) return;
    const v = await footnoteDialog(null);
    if (!v || !v.text) return;
    const r = giveCaret(saved).cloneRange();
    if (!Lb.sel.inEditor(r) || (r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement).closest('.lb-toc')) {
      Lb.ui.toast('Put the cursor in the text first.');
      return;
    }
    Lb.history.checkpoint();
    r.collapse(false);
    const fn = document.createElement('sup');
    fn.className = 'lb-fn';
    fn.setAttribute('contenteditable', 'false');
    fn.dataset.note = v.text;
    fn.textContent = '#';
    const after = document.createTextNode('​');
    r.insertNode(after);
    r.insertNode(fn);
    // a <br> placeholder after the marker in an empty paragraph is not needed
    const s = window.getSelection();
    const cr = document.createRange();
    cr.setStart(after, 1); cr.collapse(true);
    s.removeAllRanges(); s.addRange(cr);
    Lb.sel.save();
    Lb.history.commit();
    Lb.emit('changed');
    Lb.layout.refresh();
  }

  async function editFootnote(fn) {
    const v = await footnoteDialog(fn);
    if (!v) return;
    Lb.history.checkpoint();
    if (v.action === 'delete' || !v.text) fn.remove();
    else fn.dataset.note = v.text;
    Lb.history.commit();
    Lb.emit('changed');
    Lb.layout.refresh();
  }

  /* ------------------------------------------------------------ */
  /* Table of contents                                             */
  /* ------------------------------------------------------------ */
  const headingText = (hEl) => hEl.textContent.replace(/​/g, '').replace(/\s+/g, ' ').trim();
  function headings(levels) {
    const max = levels || 3;
    return [...Lb.els.editor.querySelectorAll('h1,h2,h3')]
      .filter((x) => +x.tagName[1] <= max && !x.closest('td,th,.lb-toc') && headingText(x));
  }

  /** Rebuild every table of contents; returns true when one changed (the layout then runs again). */
  function updateTocs() {
    const tocs = Lb.els.editor.querySelectorAll('.lb-toc');
    if (!tocs.length) return false;
    const pr = Lb.els.page.getBoundingClientRect();
    const z = Lb.state.zoom;
    const ph = Lb.pageH();
    const all = headings(3).map((hEl) => ({
      el: hEl, level: +hEl.tagName[1], text: headingText(hEl),
      page: Math.max(1, Math.floor(((hEl.getBoundingClientRect().top - pr.top) / z) / ph) + 1)
    }));
    let changed = false;
    for (const toc of tocs) {
      const levels = Math.min(3, Math.max(1, +toc.dataset.levels || 3));
      const title = toc.dataset.title || 'Contents';
      const color = toc.dataset.color || '';
      const entries = all.filter((e) => e.level <= levels);
      const sig = JSON.stringify([title, color, entries.map((e) => [e.level, e.text, e.page])]);
      if (toc.dataset.sig === sig && toc.querySelector('.lb-toc-title')) continue;
      toc.dataset.sig = sig;
      toc.setAttribute('contenteditable', 'false');
      toc.innerHTML = `<div class="lb-toc-title"${color ? ` style="color:${esc(color)}"` : ''}>${esc(title)}</div>` +
        (entries.length
          ? entries.map((e) => `<div class="lb-toc-e l${e.level}" data-i="${all.indexOf(e)}"><span class="lb-toc-t">${esc(e.text)}</span><span class="lb-toc-d"></span><span class="lb-toc-n">${e.page}</span></div>`).join('')
          : '<div class="lb-toc-empty">Headings you write with the Heading 1, Heading 2 and Heading 3 styles appear here, with their page numbers.</div>');
      changed = true;
    }
    return changed;
  }
  D.updateTocs = updateTocs;

  D.tocHtml = (opts) => {
    const o = opts || {};
    return `<div class="lb-toc" contenteditable="false" data-title="${esc(o.title || 'Contents')}" data-levels="${o.levels || 3}"${o.color ? ` data-color="${esc(o.color)}"` : ''}></div>`;
  };

  async function tocDialog(existing) {
    const levels = existing ? +existing.dataset.levels || 3 : 3;
    const title = existing ? existing.dataset.title || 'Contents' : 'Contents';
    const body = `
      <div class="mrow"><label style="min-width:90px">Title</label><input type="text" id="tocTitle" value="${esc(title)}" style="flex:1"></div>
      <div class="mrow"><label style="min-width:90px">Show</label><select id="tocLevels" style="flex:1">
        <option value="1"${levels === 1 ? ' selected' : ''}>Heading 1 only</option>
        <option value="2"${levels === 2 ? ' selected' : ''}>Headings 1 and 2</option>
        <option value="3"${levels === 3 ? ' selected' : ''}>Headings 1, 2 and 3</option></select></div>
      <p class="hint">The table updates by itself as you write. Tap an entry to jump to that heading.</p>`;
    const buttons = existing
      ? [{ label: 'Remove', value: 'remove', danger: true, left: true }, { label: 'Cancel', value: 'cancel' }, { label: 'Apply', value: 'ok', primary: true }]
      : [{ label: 'Cancel', value: 'cancel' }, { label: 'Insert', value: 'ok', primary: true }];
    const res = await Lb.ui.modal({ title: 'Table of Contents', width: 440, body, buttons });
    if (res.value === 'cancel') return null;
    return { action: res.value, title: res.root.querySelector('#tocTitle').value.trim() || 'Contents', levels: +res.root.querySelector('#tocLevels').value };
  }

  async function insertToc() {
    const ed = Lb.els.editor;
    const existing = ed.querySelector('.lb-toc');
    if (existing) { await editToc(existing); return; }
    const saved = takeCaret();
    if (!(await gate('feature'))) return;
    const v = await tocDialog(null);
    if (!v) return;
    const r = giveCaret(saved);
    Lb.history.checkpoint();
    let top = r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement;
    while (top && top !== ed && top.parentElement !== ed) top = top.parentElement;
    const tmp = document.createElement('div');
    tmp.innerHTML = D.tocHtml(v);
    const toc = tmp.firstChild;
    if (top && top.parentElement === ed) {
      const empty = !top.textContent.replace(/[​\s]/g, '') && !top.querySelector('img,table');
      // at the very start of a block the table goes before it, otherwise after it
      const pre = document.createRange();
      pre.setStart(top, 0); pre.setEnd(r.startContainer, r.startOffset);
      if (empty) top.replaceWith(toc);
      else if (!pre.toString().replace(/[​\s]/g, '')) top.before(toc);
      else top.after(toc);
    } else ed.prepend(toc);
    if (!toc.nextElementSibling) { const p = document.createElement('p'); p.innerHTML = '<br>'; toc.after(p); }
    Lb.app.normalizeEditor();
    Lb.history.commit();
    Lb.emit('changed');
    Lb.layout.refresh();
    if (!headings(3).length) Lb.ui.toast('Use the Heading 1, 2 and 3 styles for your titles and they will appear in the table.', '', 5000);
  }

  async function editToc(toc) {
    const v = await tocDialog(toc);
    if (!v) return;
    Lb.history.checkpoint();
    if (v.action === 'remove') toc.remove();
    else { toc.dataset.title = v.title; toc.dataset.levels = String(v.levels); toc.removeAttribute('data-sig'); }
    Lb.app.normalizeEditor();
    Lb.history.commit();
    Lb.emit('changed');
    Lb.layout.refresh();
  }

  function goToHeading(i) {
    const hEl = headings(3)[i];
    if (!hEl) return;
    const sc = Lb.els.scroller;
    sc.scrollTop += hEl.getBoundingClientRect().top - sc.getBoundingClientRect().top - 24;
    Lb.sel.placeCaretAtEnd(hEl);
    Lb.sel.save();
  }

  /* ------------------------------------------------------------ */
  /* Cover pages                                                   */
  /* ------------------------------------------------------------ */
  // small deterministic random numbers, so a design always looks the same
  function rng(seed) {
    let x = seed >>> 0 || 1;
    return () => { x ^= x << 13; x >>>= 0; x ^= x >> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; };
  }
  const hexRgb = (c) => { const n = parseInt(String(c).replace('#', ''), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const mix = (c, t, a) => { const p = hexRgb(c), q = hexRgb(t); return `rgb(${p.map((v, i) => Math.round(v * (1 - a) + q[i] * a)).join(',')})`; };

  D.COVERS = [
    { id: 'facets', name: 'Facets' },
    { id: 'band', name: 'Band' },
    { id: 'waves', name: 'Waves' }
  ];
  D.COVER_COLORS = ['#1e3a8a', '#0f766e', '#7c2d12', '#4c1d95', '#334155', '#b45309'];

  /** Draw a cover banner (original artwork) and return it as a PNG data URL. */
  D.coverImage = (design, color, w, h, scale) => {
    const s = scale || 2;
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w * s)); c.height = Math.max(1, Math.round(h * s));
    const g = c.getContext('2d');
    g.scale(s, s);
    const R = rng(97 + design.length * 31);
    if (design === 'band') {
      g.fillStyle = color; g.fillRect(0, 0, w, h);
      g.fillStyle = mix(color, '#ffffff', 0.12);
      g.beginPath(); g.moveTo(w * 0.52, 0); g.lineTo(w, 0); g.lineTo(w, h); g.lineTo(w * 0.30, h); g.closePath(); g.fill();
      g.fillStyle = mix(color, '#000000', 0.25);
      g.beginPath(); g.moveTo(w * 0.78, 0); g.lineTo(w, 0); g.lineTo(w, h); g.lineTo(w * 0.62, h); g.closePath(); g.fill();
      g.fillStyle = '#f59e0b';
      g.fillRect(0, h - Math.max(4, h * 0.035), w * 0.42, Math.max(4, h * 0.035));
      g.strokeStyle = 'rgba(255,255,255,0.18)'; g.lineWidth = 1;
      for (let i = 0; i < 9; i++) { const y = h * 0.14 + i * h * 0.07; g.beginPath(); g.moveTo(w * 0.06, y); g.lineTo(w * 0.06 + w * (0.10 + R() * 0.16), y); g.stroke(); }
    } else if (design === 'waves') {
      g.fillStyle = mix(color, '#ffffff', 0.92); g.fillRect(0, 0, w, h);
      for (let k = 0; k < 5; k++) {
        const base = h * (0.38 + k * 0.13), amp = h * (0.06 + R() * 0.05), ph = R() * Math.PI * 2, len = w * (0.55 + R() * 0.4);
        g.fillStyle = mix(color, '#ffffff', 0.72 - k * 0.16);
        g.beginPath(); g.moveTo(0, h);
        for (let x = 0; x <= w; x += 4) g.lineTo(x, base + Math.sin(x / len * Math.PI * 2 + ph) * amp);
        g.lineTo(w, h); g.closePath(); g.fill();
      }
      g.fillStyle = '#f59e0b';
      g.beginPath(); g.arc(w * 0.86, h * 0.22, Math.min(w, h) * 0.075, 0, Math.PI * 2); g.fill();
    } else { // facets
      g.fillStyle = mix(color, '#000000', 0.18); g.fillRect(0, 0, w, h);
      const cols = 9, rows = 5, cw = w / (cols - 1), rh = h / (rows - 1);
      const pts = [];
      for (let r = 0; r < rows; r++) {
        pts.push([]);
        for (let q = 0; q < cols; q++) {
          const edge = r === 0 || q === 0 || r === rows - 1 || q === cols - 1;
          pts[r].push([q * cw + (edge ? 0 : (R() - 0.5) * cw * 0.7), r * rh + (edge ? 0 : (R() - 0.5) * rh * 0.7)]);
        }
      }
      for (let r = 0; r < rows - 1; r++) {
        for (let q = 0; q < cols - 1; q++) {
          const a = pts[r][q], b = pts[r][q + 1], cc = pts[r + 1][q + 1], d = pts[r + 1][q];
          for (const tri of [[a, b, cc], [a, cc, d]]) {
            const light = (q / cols) * 0.55 + R() * 0.22;
            g.fillStyle = mix(color, '#ffffff', Math.min(0.75, light * 0.6));
            g.beginPath(); g.moveTo(tri[0][0], tri[0][1]); g.lineTo(tri[1][0], tri[1][1]); g.lineTo(tri[2][0], tri[2][1]); g.closePath(); g.fill();
            g.strokeStyle = 'rgba(255,255,255,0.08)'; g.lineWidth = 1; g.stroke();
          }
        }
      }
      g.fillStyle = 'rgba(245,158,11,0.9)';
      g.beginPath(); g.moveTo(0, h); g.lineTo(w * 0.28, h); g.lineTo(0, h * 0.62); g.closePath(); g.fill();
    }
    return c.toDataURL('image/png');
  };

  /** Width and height of the text area in px. */
  D.contentBox = () => {
    const m = Lb.settings.margins;
    return { w: Math.floor(Lb.pageW() - Lb.mm(m.left) - Lb.mm(m.right)), h: Math.floor(Lb.pageH() - Lb.mm(m.top) - Lb.mm(m.bottom)) };
  };

  /**
   * HTML of a cover page (ends with a page break).
   * o: { design, color, kicker, title, subtitle, details: [[label, value]…] }
   */
  D.coverHtml = (o) => {
    const box = D.contentBox();
    const bh = Math.round(box.h * (o.bannerRatio || 0.42));
    const src = D.coverImage(o.design || 'facets', o.color || D.COVER_COLORS[0], box.w, bh);
    const color = o.color || D.COVER_COLORS[0];
    let html = `<p data-lb-cover="1" style="margin:0 0 22pt;line-height:1"><img class="lb-picture" data-lock="1" src="${src}" style="width:${box.w}px;height:${bh}px" alt=""></p>`;
    if (o.kicker) html += `<p data-lb-cover="1" style="margin:0 0 6pt"><span style="font-size:11pt;font-weight:bold;letter-spacing:2pt;text-transform:uppercase;color:${color}">${esc(o.kicker)}</span></p>`;
    html += `<p data-lb-cover="1" style="margin:0 0 8pt;line-height:1.05"><span style="font-size:30pt;font-weight:bold;color:#111827">${esc(o.title || 'Document Title')}</span></p>`;
    if (o.subtitle) html += `<p data-lb-cover="1" style="margin:0 0 26pt"><span style="font-size:15pt;color:#4b5563">${esc(o.subtitle)}</span></p>`;
    if (o.details && o.details.length) {
      const lw = Math.round(box.w * 0.3);
      html += `<table class="lb-table" data-lb-cover="1"><colgroup><col style="width:${lw}px"><col style="width:${box.w - lw}px"></colgroup><tbody>` +
        o.details.map(([k, v]) => `<tr><td style="border:1px solid #ffffff;padding:3pt 0"><p style="margin:0"><span style="font-size:9pt;font-weight:bold;letter-spacing:1pt;text-transform:uppercase;color:${color}">${esc(k)}</span></p></td>` +
          `<td style="border:1px solid #ffffff;padding:3pt 0"><p style="margin:0">${esc(v)}</p></td></tr>`).join('') + '</tbody></table>';
    }
    return html + '<div class="lb-page-break" data-lb-cover="1" contenteditable="false"></div>';
  };

  async function coverDialog() {
    if (!(await gate('feature'))) return;
    let design = 'facets', color = D.COVER_COLORS[0];
    const body = Lb.ui.h('div', { class: 'cover-dlg' });
    body.innerHTML = `
      <div class="cover-designs"></div>
      <div class="cover-colors"></div>
      <div class="mrow"><label style="min-width:80px">Label</label><input type="text" id="cvKicker" value="Report" style="flex:1"></div>
      <div class="mrow"><label style="min-width:80px">Title</label><input type="text" id="cvTitle" value="${esc(Lb.state.title && Lb.state.title !== 'Untitled' ? Lb.state.title.replace(/\.(docx?|pdf)$/i, '') : 'Document Title')}" style="flex:1"></div>
      <div class="mrow"><label style="min-width:80px">Subtitle</label><input type="text" id="cvSub" value="A short description" style="flex:1"></div>
      <div class="mrow"><label style="min-width:80px">Author</label><input type="text" id="cvBy" value="Your Name" style="flex:1"></div>
      <p class="hint">The cover is added as the first page. Every part stays editable.</p>`;
    const designs = body.querySelector('.cover-designs');
    const colors = body.querySelector('.cover-colors');
    const paint = () => {
      designs.innerHTML = '';
      for (const d of D.COVERS) {
        const b = Lb.ui.h('button', { type: 'button', class: 'cover-card' + (d.id === design ? ' on' : ''), title: d.name });
        b.append(Lb.ui.h('img', { src: D.coverImage(d.id, color, 120, 64, 1), alt: '' }), Lb.ui.h('span', null, d.name));
        b.addEventListener('click', () => { design = d.id; paint(); });
        designs.append(b);
      }
      colors.innerHTML = '';
      for (const c of D.COVER_COLORS) {
        const b = Lb.ui.h('button', { type: 'button', class: 'cover-color' + (c === color ? ' on' : ''), style: { background: c }, title: c });
        b.addEventListener('click', () => { color = c; paint(); });
        colors.append(b);
      }
    };
    paint();
    const res = await Lb.ui.modal({ title: 'Cover Page', width: 520, body, buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Insert', value: 'ok', primary: true }] });
    if (res.value !== 'ok') return;
    const v = (id) => res.root.querySelector(id).value.trim();
    const today = new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
    const html = D.coverHtml({ design, color, kicker: v('#cvKicker'), title: v('#cvTitle'), subtitle: v('#cvSub'), details: [['Prepared by', v('#cvBy') || 'Your Name'], ['Date', today]] });
    const ed = Lb.els.editor;
    Lb.history.checkpoint();
    for (const el of ed.querySelectorAll('[data-lb-cover]')) el.remove();
    ed.insertAdjacentHTML('afterbegin', html);
    if (D.hasAnyHf()) Lb.settings.hf.firstDifferent = true;
    Lb.app.normalizeEditor();
    Lb.history.commit();
    Lb.emit('changed');
    Lb.layout.refresh();
    Lb.els.scroller.scrollTop = 0;
  }

  /* ------------------------------------------------------------ */
  /* Wiring                                                        */
  /* ------------------------------------------------------------ */
  D.init = () => {
    decor = document.createElement('div');
    decor.className = 'page-decor';
    decor.id = 'pageDecor';
    Lb.els.page.insertBefore(decor, Lb.els.guides);
    Lb.layout.after.push(updateTocs);
    Lb.on('layout', renderDecor);
    const ed = Lb.els.editor;
    ed.addEventListener('click', (e) => {
      const fn = e.target.closest && e.target.closest('.lb-fn');
      if (fn && ed.contains(fn)) { e.preventDefault(); editFootnote(fn); return; }
      const entry = e.target.closest && e.target.closest('.lb-toc-e');
      if (entry) { e.preventDefault(); goToHeading(+entry.dataset.i); return; }
      const toc = e.target.closest && e.target.closest('.lb-toc');
      if (toc) { e.preventDefault(); editToc(toc); }
    });
    decor.addEventListener('click', (e) => {
      if (e.target.closest('.lb-hf')) { headerFooterDialog(); return; }
      const note = e.target.closest('.lb-note');
      if (note) { const fn = ed.querySelectorAll('.lb-fn')[+note.dataset.n - 1]; if (fn) editFootnote(fn); }
    });
    decor.addEventListener('mousedown', (e) => { if (e.target.closest('.lb-hf,.lb-note')) e.preventDefault(); });
  };

  Lb.register('headerFooter', () => headerFooterDialog());
  Lb.register('footnote', () => insertFootnote());
  Lb.register('toc', () => insertToc());
  Lb.register('coverPage', () => coverDialog());

  Lb.docparts = D;
})();
