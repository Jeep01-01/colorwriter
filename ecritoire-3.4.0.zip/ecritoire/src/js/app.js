/* Écritoire — application wiring: commands, shortcuts, files, status. */
(function () {
  'use strict';
  const Lb = window.Lb;
  const { $, esc } = Lb.util;
  const F = () => Lb.format;
  const bridge = Lb.bridge;
  const isMobile = !!(bridge && bridge.platform && bridge.platform !== 'desktop');
  Lb.isMobile = isMobile;
  const savedMsg = (res) => (isMobile && !res.shared ? 'Saved to ' + res.path : 'Saved ' + Lb.util.fileBase(res.path));

  /* ------------------------------------------------------------ */
  /* Elements                                                      */
  /* ------------------------------------------------------------ */
  Object.assign(Lb.els, {
    editor: $('editor'), page: $('page'), pageWrap: $('pageWrap'), scroller: $('scroller'),
    workspace: $('workspace'), guides: $('pageGuides'), overlay: $('objOverlay'),
    rulerH: $('rulerH'), rulerV: $('rulerV'), sidebar: $('sidebar'), sideBody: $('sideBody')
  });
  const ed = Lb.els.editor;

  /* ------------------------------------------------------------ */
  /* Tabs, sidebar, contextual panel                               */
  /* ------------------------------------------------------------ */
  Lb.switchTab = (name) => {
    for (const t of document.querySelectorAll('.tab')) t.classList.toggle('active', t.dataset.tab === name);
    for (const p of document.querySelectorAll('.panel')) p.classList.toggle('active', p.dataset.panel === name);
  };
  let formatMode = 'object';
  let objectPanelHtml = null;
  Lb.setFormatPanel = (mode) => {
    const panel = document.querySelector('[data-panel="format"]');
    if (!objectPanelHtml) objectPanelHtml = panel.innerHTML;
    if (mode === formatMode) return;
    formatMode = mode;
    if (mode === 'table') { panel.innerHTML = ''; panel.append(Lb.tables.buildPanel()); }
    else { panel.innerHTML = objectPanelHtml; Lb.ui.hydrateIcons(panel); }
  };
  Lb.sidebarMode = null;
  Lb.openSidebar = (title, body, mode) => {
    $('sideTitle').textContent = title;
    Lb.els.sideBody.innerHTML = '';
    Lb.els.sideBody.append(body);
    Lb.els.sidebar.hidden = false;
    Lb.sidebarMode = mode || null;
    Lb.layout.drawRulers();
    // phones: the pane is a bottom sheet, so make room to scroll the selected
    // object above it
    if (getComputedStyle(Lb.els.sidebar).position === 'fixed') {
      const sc = Lb.els.scroller;
      sc.style.paddingBottom = Lb.els.sidebar.offsetHeight + 'px';
      const obj = Lb.objects.selected();
      if (obj) {
        const top = obj.getBoundingClientRect().top - sc.getBoundingClientRect().top;
        const room = sc.clientHeight - Lb.els.sidebar.offsetHeight;
        if (top < 8 || top + obj.getBoundingClientRect().height > room - 8) sc.scrollTop += top - 24;
        requestAnimationFrame(() => Lb.objects.refresh());
      }
    }
  };
  Lb.closeSidebar = () => {
    Lb.els.sidebar.hidden = true;
    Lb.sidebarMode = null;
    Lb.els.scroller.style.paddingBottom = '';
    Lb.layout.drawRulers();
  };

  /* ------------------------------------------------------------ */
  /* Document state                                                */
  /* ------------------------------------------------------------ */
  function setDirty(d) {
    Lb.state.dirty = !!d;
    $('docDirty').hidden = !Lb.state.dirty;
    pushState();
  }
  function pushState() {
    $('docTitle').textContent = Lb.state.title;
    document.title = `${Lb.state.dirty ? '• ' : ''}${Lb.state.title} — Écritoire`;
    if (bridge) bridge.setState({ dirty: Lb.state.dirty, title: Lb.state.title, path: Lb.state.path });
  }

  function normalizeEditor() {
    Lb.fixStructure();
    // top-level text or inline nodes get wrapped in paragraphs
    let p = null;
    for (const n of [...ed.childNodes]) {
      const inline = n.nodeType === 3 ? n.nodeValue.trim() !== '' : (n.nodeType === 1 && !/^(P|H[1-6]|UL|OL|TABLE|BLOCKQUOTE|PRE|DIV|HR)$/.test(n.tagName));
      if (inline) {
        if (!p) { p = document.createElement('p'); n.before(p); }
        p.append(n);
      } else {
        p = null;
        if (n.nodeType === 3) n.remove();
      }
    }
    if (!ed.firstElementChild) ed.innerHTML = '<p><br></p>';
    // the editor must not end with an un-editable element
    const last = ed.lastElementChild;
    if (last && (last.tagName === 'TABLE' || last.classList.contains('lb-page-break') || last.classList.contains('lb-toc'))) {
      const np = document.createElement('p'); np.innerHTML = '<br>'; ed.append(np);
    }
    for (const img of ed.querySelectorAll('img.lb-picture:not([data-lock])')) img.dataset.lock = '1';
    for (const pb of ed.querySelectorAll('.lb-page-break,.lb-toc,.lb-fn,.lb-video')) pb.setAttribute('contenteditable', 'false');
  }

  function loadDocument(html, settings, meta) {
    Lb.objects.deselect();
    Lb.closeSidebar();
    ed.innerHTML = html || '<p><br></p>';
    normalizeEditor();
    if (Lb.media) Lb.media.hydrate((meta && meta.media) || null);
    Lb.settings.margins = Object.assign({}, Lb.DEFAULT_MARGINS, (settings && settings.margins) || {});
    Lb.settings.paper = (settings && Lb.PAPERS[settings.paper]) ? settings.paper : 'A4';
    Lb.settings.orientation = (settings && settings.orientation === 'landscape') ? 'landscape' : 'portrait';
    Lb.settings.hf = Lb.docparts.normalizeHf(settings && settings.hf);
    Lb.state.path = meta.path || null;
    Lb.state.ext = meta.ext || '.docx';
    Lb.state.title = meta.title || 'Untitled';
    Lb.settings.title = Lb.state.title;
    Lb.layout.applyMargins();
    Lb.layout.refresh();
    if (Lb.wrap) { Lb.wrap.afterLoad(); Lb.layout.refresh(); }
    Lb.history.reset();
    setDirty(false);
    Lb.els.scroller.scrollTop = 0;
    ed.focus({ preventScroll: true });
    const r = document.createRange();
    r.setStart(ed.firstElementChild || ed, 0); r.collapse(true);
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    Lb.sel.save();
    updateStatus();
    F().reflect();
  }

  async function confirmDiscard() {
    if (!Lb.state.dirty) return true;
    const v = await Lb.ui.confirmUnsaved(Lb.state.title);
    if (v === 'save') return save();
    return v === 'discard';
  }

  /* ------------------------------------------------------------ */
  /* File commands                                                 */
  /* ------------------------------------------------------------ */
  async function newDoc() {
    if (!(await confirmDiscard())) return;
    loadDocument('<p><br></p>', { margins: Lb.DEFAULT_MARGINS }, { title: 'Untitled' });
  }

  async function openBytes(data, meta) {
    try {
      const res = await window.LbDocxReader.read(data);
      loadDocument(res.html, res.settings, Object.assign({ media: res.media }, meta));
      if (res.warnings && res.warnings.length) Lb.ui.toast(res.warnings.join(' '), '', 7000);
      else Lb.ui.toast(`Opened ${meta.title}`);
    } catch (e) {
      console.error(e);
      Lb.ui.alert('Could not open document', e.message || String(e));
    }
  }

  async function handleOpenResult(res) {
    if (!res || res.canceled) return;
    if (res.error) { Lb.ui.alert('Could not open document', res.error); return; }
    await openBytes(res.data, { path: res.path, ext: res.ext, title: res.name });
  }

  async function open() {
    if (!(await confirmDiscard())) return;
    if (bridge) { await handleOpenResult(await bridge.openDialog()); return; }
    // browser fallback
    const input = document.createElement('input');
    input.type = 'file'; input.accept = '.docx';
    input.onchange = async () => {
      const f = input.files[0];
      if (f) await openBytes(new Uint8Array(await f.arrayBuffer()), { title: f.name, ext: '.docx' });
    };
    input.click();
  }

  async function openPath(p) {
    if (!bridge || !p) return;
    if (!(await confirmDiscard())) return;
    await handleOpenResult(await bridge.openPath(p));
  }

  function suggestedPath(ext) {
    const base = (Lb.state.title || 'Document').replace(/\.(docx?|pdf)$/i, '');
    if (Lb.state.path) return Lb.state.path.replace(/\.[^.\\/]+$/, '') + ext;
    return base + ext;
  }

  async function writeTo(path, opts) {
    const pages = opts && opts.pages && opts.pages.length ? opts.pages : null;
    if (!bridge) { Lb.ui.toast('Saving files needs the Écritoire app.', 'error'); return false; }
    const isPdf = /\.pdf$/i.test(path);
    // A later paid edition can check a purchase here (Lb.pro); this edition has everything unlocked.
    if (!isPdf && Lb.pro) {
      const g = await Lb.pro.require('save');
      if (g !== 'pro') return false;
    }
    Lb.objects.deselect();
    if (!isMobile || !isPdf) Lb.ui.toast(isPdf ? 'Exporting PDF…' : 'Saving…', '', 1200);
    const req = { path, settings: Object.assign({ title: Lb.state.title }, Lb.settings) };
    if (isPdf && !isMobile) { req.html = await pagedHtml(pages); req.paged = true; } else if (isPdf) { req.html = Lb.exporter.cleanHtml(); if (pages) req.pages = pages; }
    else req.model = await Lb.exporter.buildModel();
    const res = await bridge.save(req);
    if (res && res.ok) return res;
    if (res && res.code === 'NO_SOFFICE') {
      const yes = await Lb.ui.confirm('LibreOffice needed', 'Saving in the older .doc format needs LibreOffice, which was not found. Save as .docx instead?', 'Save as .docx');
      if (yes) return saveAs('.docx');
      return false;
    }
    Lb.ui.alert('Could not save', (res && res.error) || 'Unknown error');
    return false;
  }

  async function save() {
    if (!Lb.state.path || !/\.(docx|doc)$/i.test(Lb.state.path)) return saveAs();
    const res = await writeTo(Lb.state.path);
    if (res && res.ok && res.format === 'pdf') { Lb.ui.toast(savedMsg(res)); return true; }
    if (res && res.ok) { setDirty(false); Lb.ui.toast(savedMsg(res)); return true; }
    return !!res;
  }

  async function saveAs(forceExt) {
    if (!bridge) { Lb.ui.toast('Saving files needs the Écritoire app.', 'error'); return false; }
    const ext = forceExt || (Lb.state.ext === '.doc' ? '.doc' : '.docx');
    const path = await bridge.saveDialog({ defaultPath: suggestedPath(ext) });
    if (!path) return false;
    const res = await writeTo(path);
    if (!res || !res.ok) return !!res;
    if (res.format === 'pdf') { Lb.ui.toast(savedMsg(res)); return true; }
    Lb.state.path = res.path;
    Lb.state.ext = '.' + res.format;
    Lb.state.title = Lb.util.fileBase(res.path);
    setDirty(false);
    Lb.ui.toast(savedMsg(res));
    return true;
  }

  async function share() {
    if (!bridge || !bridge.share) { Lb.ui.toast('Sharing is available in the Écritoire app.'); return; }
    const res = await Lb.ui.modal({
      title: 'Share', width: 420,
      body: '<p>Send this document to another app: email, messages, cloud storage and more.</p><div class="mrow"><label>Send as</label><select id="shFmt" style="flex:1">' +
        '<option value="docx">DOCX document (.docx)</option><option value="pdf">PDF document (.pdf)</option></select></div>',
      buttons: [{ label: 'Cancel', value: 'cancel' }, { label: 'Share', value: 'ok', primary: true }]
    });
    if (res.value !== 'ok') return;
    const format = res.root.querySelector('#shFmt').value;
    if (format === 'docx' && Lb.pro && (await Lb.pro.require('share')) !== 'pro') return;
    Lb.objects.deselect();
    try {
      await bridge.share({ name: Lb.state.title, format, model: format === 'docx' ? await Lb.exporter.buildModel() : null });
    } catch (e) {
      if (!/cancel/i.test(String(e && e.message))) Lb.ui.toast('Could not share: ' + ((e && e.message) || e), 'error');
    }
  }

  /** Desktop PDF and printing: the laid-out pages, with each video shown as its still picture. */
  /** Desktop PDF and printing: the laid-out pages, with each video shown as its still picture. */
  async function pagedPages() {
    const undo = Lb.media ? await Lb.media.beforeCapture() : () => {};
    try { return Lb.exporter.pagedPages(); } finally { undo(); }
  }
  /** pages: 1-based page numbers to keep (all when left out). Headers, footers and page numbers stay as in the whole document. */
  async function pagedHtml(pages) {
    const all = await pagedPages();
    return pages && pages.length ? pages.filter((p) => p >= 1 && p <= all.length).map((p) => all[p - 1]).join('') : all.join('');
  }

  async function exportPdf(opts) {
    if (!bridge) { Lb.ui.toast('PDF export needs the Écritoire app — using the print dialog instead.'); window.print(); return false; }
    const path = await bridge.saveDialog({ defaultPath: suggestedPath('.pdf'), pdfOnly: true });
    if (!path) return false;
    const res = await writeTo(path, opts);
    if (res && res.ok) Lb.ui.toast(isMobile ? savedMsg(res) : 'Exported ' + Lb.util.fileBase(res.path));
    return !!(res && res.ok);
  }

  /** Print now: pages = 1-based page numbers (all when left out). */
  async function printPages(pages) {
    Lb.objects.deselect();
    if (!bridge) { window.print(); return true; }
    const list = pages && pages.length ? pages : null;
    const res = isMobile ? await bridge.print({ html: Lb.exporter.cleanHtml(), settings: Lb.settings, pages: list })
      : await bridge.print({ html: await pagedHtml(list), paged: true, settings: Lb.settings });
    if (res && !res.ok && res.reason && !/cancel/i.test(res.reason)) { Lb.ui.toast('Printing failed: ' + res.reason, 'error'); return false; }
    return !(res && !res.ok);
  }
  // Print opens Print Preview first, as in Word: choose pages there, then print
  const print = () => (Lb.printPreview ? Lb.printPreview.open() : printPages());
  Lb.printing = { pagedPages, printPages, exportPdf };

  /* ------------------------------------------------------------ */
  /* Paste & drop                                                  */
  /* ------------------------------------------------------------ */
  const ALLOWED = new Set(['P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'UL', 'OL', 'LI', 'B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'DEL', 'INS', 'SUB', 'SUP', 'SPAN', 'A', 'BR', 'TABLE', 'THEAD', 'TBODY', 'TFOOT', 'TR', 'TD', 'TH', 'IMG', 'BLOCKQUOTE', 'PRE', 'DIV', 'FONT', 'CODE', 'COLGROUP', 'COL', 'SMALL', 'MARK']);
  const DROP = new Set(['SCRIPT', 'STYLE', 'META', 'LINK', 'IFRAME', 'OBJECT', 'EMBED', 'TITLE', 'HEAD', 'NOSCRIPT', 'TEMPLATE', 'SVG', 'MATH', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'FORM', 'VIDEO', 'AUDIO', 'CANVAS']);
  const STYLE_OK = ['font-family', 'font-size', 'font-weight', 'font-style', 'text-decoration', 'text-decoration-line', 'color', 'background-color', 'text-align', 'margin-left', 'margin-top', 'margin-bottom', 'text-indent', 'line-height', 'vertical-align', 'list-style-type', 'width', 'height', 'text-transform', 'letter-spacing'];

  Lb.sanitize = (html) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const clean = (node) => {
      for (const n of [...node.childNodes]) {
        if (n.nodeType === 8) { n.remove(); continue; }
        if (n.nodeType !== 1) continue;
        const tag = n.tagName.toUpperCase();
        if (DROP.has(tag) || tag.includes(':')) {
          if (tag.includes(':') && !DROP.has(tag)) { clean(n); n.replaceWith(...n.childNodes); } else n.remove();
          continue;
        }
        clean(n);
        if (!ALLOWED.has(tag)) { n.replaceWith(...n.childNodes); continue; }
        // attributes
        const keep = {};
        const st = n.style;
        const styles = [];
        for (const p of STYLE_OK) {
          const v = st.getPropertyValue(p);
          if (v && !/mso|var\(/.test(v)) styles.push(`${p}:${v}`);
        }
        if (tag === 'IMG') {
          const src = n.getAttribute('src') || '';
          if (!/^data:image\//.test(src)) { n.remove(); continue; }
          keep.src = src;
          const w = parseFloat(n.getAttribute('width')) || parseFloat(st.width);
          const h = parseFloat(n.getAttribute('height')) || parseFloat(st.height);
          keep.class = n.classList.contains('lb-shape') ? 'lb-shape' : 'lb-picture';
          for (const [k, v] of Object.entries(n.dataset)) keep['data-' + k.replace(/[A-Z]/g, (c) => '-' + c.toLowerCase())] = v;
          styles.length = 0;
          if (w) styles.push(`width:${w}px`);
          if (h) styles.push(`height:${h}px`);
          if (n.style.filter) styles.push(`filter:${n.style.filter}`);
        }
        if (tag === 'A') { const href = n.getAttribute('href') || ''; if (/^(https?:|mailto:)/i.test(href)) keep.href = href; }
        if (tag === 'TD' || tag === 'TH') {
          if (n.getAttribute('colspan')) keep.colspan = n.getAttribute('colspan');
          if (n.getAttribute('rowspan')) keep.rowspan = n.getAttribute('rowspan');
        }
        if ((tag === 'OL' || tag === 'UL') && n.dataset.list) keep['data-list'] = n.dataset.list;
        if (tag === 'OL' && n.getAttribute('start')) keep.start = n.getAttribute('start');
        if (tag === 'FONT') {
          if (n.getAttribute('color')) styles.push(`color:${n.getAttribute('color')}`);
          if (n.getAttribute('face')) styles.push(`font-family:${n.getAttribute('face')}`);
        }
        const lbClasses = [...n.classList].filter((c) => /^lb-(tab|page-break|table|fn)$/.test(c));
        if (tag === 'SUP' && lbClasses.includes('lb-fn') && n.dataset.note) keep['data-note'] = n.dataset.note;
        for (const a of [...n.attributes]) n.removeAttribute(a.name);
        for (const [k, v] of Object.entries(keep)) n.setAttribute(k, v);
        if (lbClasses.length && tag !== 'IMG') n.className = lbClasses.join(' ');
        if (styles.length) n.setAttribute('style', styles.join(';'));
        if (n.classList.contains('lb-page-break') || n.classList.contains('lb-fn')) n.setAttribute('contenteditable', 'false');
      }
    };
    clean(doc.body);
    return doc.body.innerHTML;
  };

  function insertHtml(html) {
    Lb.sel.restore();
    Lb.history.checkpoint();
    document.execCommand('insertHTML', false, html);
    normalizeEditor();
    Lb.history.commit();
    Lb.layout.refresh();
  }
  function insertPlain(text) {
    const lines = text.replace(/\r\n?/g, '\n').split('\n');
    if (lines.length === 1) { Lb.sel.restore(); Lb.history.checkpoint(); document.execCommand('insertText', false, text); Lb.history.commit(); return; }
    insertHtml(lines.map((l) => `<p>${l ? esc(l).replace(/\t/g, '<span class="lb-tab">\t</span>') : '<br>'}</p>`).join(''));
  }

  ed.addEventListener('paste', (e) => {
    const dt = e.clipboardData;
    if (!dt) return;
    const files = [...dt.files].filter((f) => /^image\//.test(f.type));
    const html = dt.getData('text/html');
    e.preventDefault();
    if (files.length && !html) { Lb.sel.save(); files.forEach((f) => Lb.objects.insertPictureFile(f)); return; }
    if (html && !Lb.pastePlainNext) insertHtml(Lb.sanitize(html));
    else insertPlain(dt.getData('text/plain'));
    Lb.pastePlainNext = false;
  });

  Lb.els.scroller.addEventListener('dragover', (e) => { if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) e.preventDefault(); });
  Lb.els.scroller.addEventListener('drop', async (e) => {
    const files = e.dataTransfer ? [...e.dataTransfer.files] : [];
    if (!files.length) return;
    e.preventDefault();
    const doc = files.find((f) => /\.(docx?|DOCX?)$/.test(f.name));
    if (doc) {
      const p = bridge && bridge.pathForFile ? bridge.pathForFile(doc) : null;
      if (p) { openPath(p); return; }
      if (/\.docx$/i.test(doc.name)) {
        if (!(await confirmDiscard())) return;
        openBytes(new Uint8Array(await doc.arrayBuffer()), { title: doc.name, ext: '.docx' });
      }
      return;
    }
    const pos = document.caretRangeFromPoint ? document.caretRangeFromPoint(e.clientX, e.clientY) : null;
    if (pos && ed.contains(pos.startContainer)) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(pos); Lb.sel.save(); }
    for (const f of files.filter((x) => /^image\//.test(x.type))) await Lb.objects.insertPictureFile(f);
  });

  /* ------------------------------------------------------------ */
  /* Dialogs: about / shortcuts                                    */
  /* ------------------------------------------------------------ */
  async function about() {
    const info = bridge ? await bridge.info() : { version: 'web', hasLibreOffice: false };
    Lb.ui.modal({
      title: 'About Écritoire', width: 440,
      body: `<div style="display:flex;gap:16px;align-items:center;margin-bottom:12px">
          <img src="icon.png" width="64" height="64" alt="" style="border-radius:14px">
          <div><div style="font-size:20px;font-weight:700;color:var(--amber)">Écritoire</div>
          <div style="color:var(--muted)">Version ${esc(info.version)}</div></div></div>
        <p>A complete document editor for Windows, phones and tablets. Opens .docx documents and saves to .docx or PDF, with templates, cover pages, a table of contents, headers, footers and footnotes.</p>
        <p style="color:var(--dim)">“Écritoire” is French for a writing desk. Full edition: every feature is included.</p>`
    });
  }
  function shortcuts() {
    const rows = [
      ['New / Open / Save', 'Ctrl+N · Ctrl+O · Ctrl+S'], ['Save As', 'Ctrl+Shift+S'], ['Export to PDF', 'Ctrl+Shift+E'], ['Print', 'Ctrl+P'],
      ['Undo / Redo', 'Ctrl+Z · Ctrl+Y'], ['Bold / Italic / Underline', 'Ctrl+B · Ctrl+I · Ctrl+U'],
      ['Font dialog', 'Ctrl+D'], ['Bigger / smaller text', 'Ctrl+] · Ctrl+['], ['Align left / center / right / justify', 'Ctrl+L · Ctrl+E · Ctrl+R · Ctrl+J'],
      ['Bullets', 'Ctrl+Shift+L'], ['Page break', 'Ctrl+Enter'], ['Zoom in / out / 100%', 'Ctrl+= · Ctrl+- · Ctrl+0'], ['Zoom with mouse', 'Ctrl+Wheel'],
      ['Page break preview', 'Ctrl+Alt+P'], ['Ruler', 'Ctrl+Alt+R'], ['Find', 'Ctrl+F'], ['Paste as plain text', 'Ctrl+Shift+V'],
      ['Next / previous table cell', 'Tab · Shift+Tab'], ['Resize keeping proportions', 'Shift + drag handle']
    ];
    Lb.ui.modal({
      title: 'Keyboard Shortcuts', width: 520,
      body: `<table class="kbd-table">${rows.map(([a, b]) => `<tr><td>${esc(a)}</td><td>${b.split(' · ').map((k) => `<kbd>${esc(k)}</kbd>`).join(' ')}</td></tr>`).join('')}</table>`
    });
  }

  /* ------------------------------------------------------------ */
  /* Find                                                          */
  /* ------------------------------------------------------------ */
  function openFind() {
    const bar = $('findbar');
    bar.hidden = false;
    const r = Lb.sel.range();
    if (r && !r.collapsed && Lb.sel.inEditor(r) && r.toString().length < 80) $('findInput').value = r.toString();
    $('findInput').focus(); $('findInput').select();
  }
  function find(back) {
    const q = $('findInput').value;
    if (!q) return;
    ed.focus({ preventScroll: true });
    const ok = window.find(q, false, !!back, true, false, false, false);
    if (!ok) Lb.ui.toast(`"${q}" was not found.`);
    $('findInput').focus();
  }
  $('findInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); find(e.shiftKey); }
    if (e.key === 'Escape') { $('findbar').hidden = true; ed.focus(); }
  });
  $('findNext').addEventListener('click', () => find(false));
  $('findPrev').addEventListener('click', () => find(true));
  $('findClose').addEventListener('click', () => { $('findbar').hidden = true; ed.focus(); });

  /* ------------------------------------------------------------ */
  /* Commands                                                      */
  /* ------------------------------------------------------------ */
  const R = Lb.register;
  R('new', newDoc); R('open', open); R('save', save); R('saveAs', () => saveAs());
  R('exportPdf', () => exportPdf()); R('print', print); R('printPreview', print); R('share', share); R('pageSetup', () => F().pageSetupDialog());
  R('newWindow', () => (bridge ? bridge.newWindow() : window.open(location.href)));
  R('about', about); R('shortcuts', shortcuts); R('find', openFind);
  R('undo', () => { Lb.history.undo(); Lb.layout.refresh(); });
  R('redo', () => { Lb.history.redo(); Lb.layout.refresh(); });
  /* Clipboard. Android uses the phone's clipboard through the bridge; the desktop
     app lets Electron paste; a plain browser falls back to its own clipboard. */
  const selectedText = () => { const s = window.getSelection(); return s ? s.toString() : ''; };
  const clipboardHint = () => Lb.ui.toast(isMobile ? 'Long-press in the document and choose Paste.' : 'Use Ctrl+V to paste.');
  async function pasteFromPhone() {
    const clip = await bridge.readClipboard();
    const value = clip && clip.value;
    if (!value) { Lb.ui.toast('The clipboard is empty.'); return; }
    if (/^image\//.test(clip.type || '') || /^data:image\//.test(value)) { Lb.sel.save(); await Lb.objects.insertPictureFromDataUrl(value); return; }
    insertPlain(value);
  }
  R('cut', async () => {
    Lb.sel.restore();
    if (bridge && bridge.writeClipboard) {
      const t = selectedText();
      if (!t) { Lb.ui.toast('Select some text first.'); return; }
      if (await bridge.writeClipboard(t)) { Lb.history.checkpoint(); document.execCommand('delete'); Lb.history.commit(); }
      return;
    }
    Lb.history.checkpoint(); document.execCommand('cut'); Lb.history.commit();
  });
  R('copy', async () => {
    Lb.sel.restore();
    if (bridge && bridge.writeClipboard) {
      const t = selectedText();
      if (!t) { Lb.ui.toast('Select some text first.'); return; }
      if (await bridge.writeClipboard(t)) Lb.ui.toast('Copied.', '', 1200);
      return;
    }
    document.execCommand('copy');
  });
  R('paste', async () => {
    Lb.sel.restore();
    if (bridge && bridge.readClipboard) { await pasteFromPhone(); return; }
    if (bridge && bridge.paste) { bridge.paste(false); return; }
    try { const t = await navigator.clipboard.readText(); insertPlain(t); } catch (_) { clipboardHint(); }
  });
  R('pastePlain', async () => {
    Lb.sel.restore();
    if (bridge && bridge.readClipboard) { await pasteFromPhone(); return; } // the phone clipboard gives plain text
    Lb.pastePlainNext = true;
    if (bridge && bridge.paste) { bridge.paste(true); return; }
    try { const t = await navigator.clipboard.readText(); insertPlain(t); } catch (_) { clipboardHint(); }
  });
  for (const c of ['bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript']) R(c, () => F().exec(c));
  R('foreColor', () => F().applyInline({ color: F().foreColor }));
  R('hiliteColor', () => F().applyInline({ 'background-color': F().hiliteColor }));
  R('growFont', () => F().grow(1)); R('shrinkFont', () => F().grow(-1));
  R('clearFormat', () => F().clearFormatting());
  R('fontDialog', () => F().fontDialog());
  R('paragraphDialog', () => F().paragraphDialog());
  R('bullets', () => F().list('ul')); R('numbering', () => F().list('ol'));
  R('indent', () => F().indent(1)); R('outdent', () => F().indent(-1));
  R('alignLeft', () => F().align('left')); R('alignCenter', () => F().align('center'));
  R('alignRight', () => F().align('right')); R('alignJustify', () => F().align('justify'));
  R('insertPicture', () => Lb.objects.pickPicture());
  R('insertShape', () => { const b = document.querySelector('.leftpane [data-menu="shapeMenu"]'); Lb.leftPane.reveal(b); Lb.ui.openMenu('shapeMenu', b); });
  R('insertTable', () => Lb.tables.dialog());
  R('pageBreak', () => F().pageBreak());
  R('zoomIn', () => Lb.layout.zoomIn()); R('zoomOut', () => Lb.layout.zoomOut());
  R('zoomReset', () => Lb.layout.setZoom(1)); R('zoomFit', () => Lb.layout.fitWidth()); R('zoomPage', () => Lb.layout.fitPage());
  R('togglePreview', () => Lb.layout.setPreview(!Lb.state.preview));
  R('toggleRuler', () => Lb.layout.setRuler(!Lb.state.ruler));
  R('showFormatPane', () => { if (Lb.objects.selected()) Lb.objects.showPane(); });
  R('deleteObject', () => Lb.objects.remove());
  R('closeSidebar', () => Lb.closeSidebar());
  R('tableRowAbove', () => Lb.tables.insertRow(false)); R('tableRowBelow', () => Lb.tables.insertRow(true));
  R('tableColLeft', () => Lb.tables.insertCol(false)); R('tableColRight', () => Lb.tables.insertCol(true));
  R('tableDelRow', () => Lb.tables.deleteRow()); R('tableDelCol', () => Lb.tables.deleteCol());
  R('tableDelete', () => Lb.tables.deleteTable());
  R('tableMerge', () => Lb.tables.mergeRight()); R('tableSplit', () => Lb.tables.split());

  /* ---------- shape gallery ---------- */
  Lb.menus.shapeMenu = () => {
    const h = Lb.ui.h;
    const wrap = h('div', { class: 'shape-gallery' });
    wrap.append(Lb.ui.menuItem('Freeform: draw your own shape', () => Lb.run('freeform'), { icon: 'freeform' }), Lb.ui.menuSep());
    let grid = null; let cat = '';
    for (const s of window.LbShapes.list) {
      if (s.cat !== cat) { cat = s.cat; wrap.append(Lb.ui.menuTitle(cat)); grid = h('div', { class: 'sg' }); wrap.append(grid); }
      const b = h('button', { title: s.name });
      b.append(h('img', { src: window.LbShapes.dataUrl(s.id, { w: 26, h: 26, fill: '#f59e0b', stroke: '#fde68a', strokeWidth: 1.2 }), alt: s.name }));
      b.addEventListener('click', () => { Lb.ui.closePopover(); Lb.objects.insertShape(s.id); });
      grid.append(b);
    }
    wrap.append(h('div', { class: 'hint', style: { padding: '8px 2px 0' } }, `${window.LbShapes.list.length} shapes · select a shape to resize it and change its colors`));
    return wrap;
  };
  Lb.menus.zoomMenu = () => {
    const wrap = Lb.ui.h('div', { style: { width: '150px' } });
    for (const z of [0.5, 0.75, 1, 1.25, 1.5, 2, 3]) wrap.append(Lb.ui.menuItem(Math.round(z * 100) + '%', () => Lb.layout.setZoom(z), { checkable: true, checked: Math.abs(Lb.state.zoom - z) < 0.001 }));
    wrap.append(Lb.ui.menuSep());
    wrap.append(Lb.ui.menuItem('Page Width', () => Lb.layout.fitWidth(), { icon: 'fitWidth' }));
    wrap.append(Lb.ui.menuItem('Whole Page', () => Lb.layout.fitPage(), { icon: 'pageSetup' }));
    return wrap;
  };

  /* ------------------------------------------------------------ */
  /* UI event delegation                                           */
  /* ------------------------------------------------------------ */
  document.addEventListener('mousedown', (e) => {
    const b = e.target.closest('button');
    // keep the caret in the document when clicking toolbar buttons
    if (b && !b.closest('.modal') && !b.closest('.sidebar') && !b.closest('.findbar')) e.preventDefault();
  });
  document.addEventListener('click', (e) => {
    const tab = e.target.closest('.tab');
    if (tab) { Lb.switchTab(tab.dataset.tab); return; }
    const m = e.target.closest('[data-menu]');
    if (m && !m.closest('.popover')) { Lb.ui.openMenu(m.dataset.menu, m); return; }
    const c = e.target.closest('[data-cmd]');
    if (c && c.dataset.cmd && !c.closest('.popover')) Lb.run(c.dataset.cmd);
    const chip = e.target.closest('.style-chip');
    if (chip) F().setBlock(chip.dataset.style);
  });

  // font family / size inputs
  const famIn = $('fontFamily'), sizeIn = $('fontSize');
  for (const inp of [famIn, sizeIn]) {
    inp.addEventListener('mousedown', () => Lb.sel.save());
    inp.addEventListener('focus', () => { Lb.sel.save(); inp.select(); });
  }
  famIn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); F().setFontFamily(famIn.value.trim()); }
    if (e.key === 'Escape') { F().reflect(); Lb.sel.restore(); }
  });
  sizeIn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); F().setFontSize(sizeIn.value); }
    if (e.key === 'Escape') { F().reflect(); Lb.sel.restore(); }
  });

  // zoom slider
  const slider = $('zoomSlider');
  slider.addEventListener('input', () => Lb.layout.setZoom(+slider.value / 100));
  Lb.on('zoom', (z) => { slider.value = Math.round(z * 100); $('zoomPct').textContent = Math.round(z * 100) + '%'; });

  /* ------------------------------------------------------------ */
  /* Keyboard                                                      */
  /* ------------------------------------------------------------ */
  const KEYS = {
    'ctrl+n': 'new', 'ctrl+o': 'open', 'ctrl+s': 'save', 'ctrl+shift+s': 'saveAs', 'ctrl+shift+e': 'exportPdf',
    'ctrl+p': 'print', 'ctrl+z': 'undo', 'ctrl+y': 'redo', 'ctrl+shift+z': 'redo', 'ctrl+f': 'find', 'ctrl+d': 'fontDialog',
    'ctrl+b': 'bold', 'ctrl+i': 'italic', 'ctrl+u': 'underline', 'ctrl+l': 'alignLeft', 'ctrl+e': 'alignCenter',
    'ctrl+r': 'alignRight', 'ctrl+j': 'alignJustify', 'ctrl+]': 'growFont', 'ctrl+[': 'shrinkFont', 'ctrl+enter': 'pageBreak',
    'ctrl+=': 'zoomIn', 'ctrl++': 'zoomIn', 'ctrl+-': 'zoomOut', 'ctrl+0': 'zoomReset', 'ctrl+shift+n': 'newWindow',
    'ctrl+alt+p': 'togglePreview', 'ctrl+alt+r': 'toggleRuler', 'ctrl+shift+v': 'pastePlain', 'ctrl+shift+l': 'bullets'
  };
  document.addEventListener('keydown', (e) => {
    if (document.querySelector('.modal-backdrop')) return;
    if (Lb.printPreview && Lb.printPreview.isOpen()) return; // the preview handles its own keys
    const mod = e.ctrlKey || e.metaKey;
    if (mod) {
      let k = e.key.toLowerCase();
      if (k === ' ') k = 'space';
      const combo = 'ctrl+' + (e.altKey ? 'alt+' : '') + (e.shiftKey ? 'shift+' : '') + k;
      const cmd = KEYS[combo] || KEYS['ctrl+' + (e.altKey ? 'alt+' : '') + k];
      if (cmd && (combo in KEYS)) {
        if (cmd === 'pastePlain') { Lb.pastePlainNext = true; return; } // let the native paste event run
        e.preventDefault();
        Lb.run(cmd, null, { source: 'key' });
        return;
      }
    }
    if (e.key === 'Escape') { Lb.ui.closePopover(); if (Lb.objects.selected()) { Lb.objects.deselect(); ed.focus(); } }
  }, true);

  ed.addEventListener('keydown', (e) => {
    const obj = Lb.objects.selected();
    if (obj && (e.key === 'Delete' || e.key === 'Backspace')) { e.preventDefault(); Lb.objects.remove(); return; }
    if (e.key === 'Tab') {
      if (Lb.tables.onTab(e)) return;
      e.preventDefault();
      const blocks = Lb.selectedBlocks();
      if (blocks.some((b) => b.tagName === 'LI')) { F().indent(e.shiftKey ? -1 : 1); return; }
      if (!e.shiftKey) { Lb.history.checkpoint(); document.execCommand('insertHTML', false, '<span class="lb-tab">\t</span>​'); Lb.history.commit(); }
    }
    // Backspace right after a page break removes the break
    if (e.key === 'Backspace') {
      const r = Lb.sel.range();
      if (r && r.collapsed && r.startOffset === 0) {
        const blk = Lb.closestBlock(r.startContainer);
        if (blk && blk.previousElementSibling && blk.previousElementSibling.classList.contains('lb-page-break')) {
          const rr = document.createRange(); rr.selectNodeContents(blk); rr.setEnd(r.startContainer, r.startOffset);
          if (!rr.toString()) { e.preventDefault(); Lb.history.checkpoint(); blk.previousElementSibling.remove(); Lb.history.commit(); Lb.layout.refresh(); }
        }
      }
    }
  });
  ed.addEventListener('beforeinput', (e) => {
    if (e.inputType === 'historyUndo') { e.preventDefault(); Lb.run('undo'); }
    if (e.inputType === 'historyRedo') { e.preventDefault(); Lb.run('redo'); }
  });

  /* ------------------------------------------------------------ */
  /* Change tracking & status                                      */
  /* ------------------------------------------------------------ */
  ed.addEventListener('input', () => {
    if (Lb.history.restoring) return;
    Lb.history.typed();
    Lb.layout.schedule();
    if (!Lb.state.dirty) setDirty(true);
    statusSoon();
  });
  Lb.on('changed', () => { if (!Lb.state.dirty) setDirty(true); Lb.layout.schedule(); statusSoon(); });
  Lb.on('settings', () => { if (!Lb.state.dirty) setDirty(true); });
  Lb.on('state', () => {
    for (const b of document.querySelectorAll('[data-state="preview"]')) b.classList.toggle('on', Lb.state.preview);
    for (const b of document.querySelectorAll('[data-state="ruler"]')) b.classList.toggle('on', Lb.state.ruler);
    $('stInfo').textContent = Lb.state.preview ? '' : 'Draft view';
  });

  // clicking the empty part of the sheet puts the caret at the end
  Lb.els.page.addEventListener('mousedown', (e) => {
    if (e.target !== Lb.els.page && e.target !== Lb.els.guides) return;
    e.preventDefault();
    ed.focus({ preventScroll: true });
    const pr = ed.getBoundingClientRect();
    if (e.clientY > pr.bottom) Lb.sel.placeCaretAtEnd(ed.lastElementChild || ed);
    else {
      const pos = document.caretRangeFromPoint && document.caretRangeFromPoint(Math.min(Math.max(e.clientX, pr.left + 2), pr.right - 2), e.clientY);
      if (pos && ed.contains(pos.startContainer)) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(pos); }
    }
  });

  function wordCount() {
    const t = ed.innerText || '';
    const words = t.trim() ? t.trim().split(/\s+/).length : 0;
    return { words, chars: t.replace(/\n/g, '').length };
  }
  function updateStatus() {
    const n = Lb.layout.pageCount();
    const cur = Lb.layout.caretPage() || Lb.layout.currentPage();
    $('stPage').textContent = `Page ${cur} of ${n}`;
    const wc = wordCount();
    $('stWords').textContent = `${wc.words.toLocaleString()} word${wc.words === 1 ? '' : 's'}`;
    $('stChars').textContent = `${wc.chars.toLocaleString()} characters`;
  }
  const statusSoon = Lb.util.debounce(updateStatus, 250);
  Lb.on('layout', statusSoon);
  Lb.on('scroll', statusSoon);

  let reflectRaf = 0;
  document.addEventListener('selectionchange', () => {
    if (Lb.sel.inEditor()) Lb.sel.save();
    if (reflectRaf) return;
    reflectRaf = requestAnimationFrame(() => {
      reflectRaf = 0;
      if (Lb.sel.inEditor()) { F().reflect(); Lb.layout.drawRulers(); statusSoon(); }
    });
  });

  /* ------------------------------------------------------------ */
  /* Bridge (desktop)                                              */
  /* ------------------------------------------------------------ */
  if (bridge) {
    bridge.onCommand((cmd) => Lb.run(cmd, null, { source: 'menu' }));
    bridge.onRequestClose(async () => { if (await confirmDiscard()) bridge.confirmClose(); });
  }

  /* ------------------------------------------------------------ */
  /* Init                                                          */
  /* ------------------------------------------------------------ */
  function init() {
    Lb.ui.hydrateIcons();
    document.execCommand('defaultParagraphSeparator', false, 'p');
    document.execCommand('styleWithCSS', false, true);
    Lb.layout.init();
    Lb.objects.init();
    Lb.wrap.init();
    Lb.tables.init();
    Lb.docparts.init();
    Lb.leftPane.init();
    Lb.media.init();
    F().bindLayoutFields();
    Lb.history.reset();
    Lb.emit('state');
    Lb.emit('zoom', Lb.state.zoom);
    pushState();
    updateStatus();
    ed.focus({ preventScroll: true });
    // phones: no rulers, and fit the page on smaller screens
    if (window.innerWidth < 700) Lb.layout.setRuler(false);
    if (Lb.els.scroller.clientWidth < Lb.pageW() + 60) Lb.layout.fitWidth();
    window.addEventListener('orientationchange', () => setTimeout(() => { if (Lb.els.scroller.clientWidth < Lb.pageW() * Lb.state.zoom + 40) Lb.layout.fitWidth(); }, 300));
    if (bridge) bridge.initialPath().then((p) => { if (p) openPath(p); });
  }

  Lb.app = { loadDocument, openBytes, save, saveAs, exportPdf, print, share, newDoc, normalizeEditor, confirmDiscard };
  init();
})();
