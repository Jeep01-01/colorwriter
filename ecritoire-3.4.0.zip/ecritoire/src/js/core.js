/* Écritoire — core namespace, shared state and helpers. */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);

  const Lb = {
    MM: 96 / 25.4,                 // CSS px per millimetre
    // paper sizes in millimetres (portrait)
    PAPERS: {
      A4: { w: 210, h: 297, label: 'A4', sub: '21 × 29.7 cm' },
      A5: { w: 148, h: 210, label: 'A5', sub: '14.8 × 21 cm' },
      A3: { w: 297, h: 420, label: 'A3', sub: '29.7 × 42 cm' },
      Letter: { w: 215.9, h: 279.4, label: 'Letter', sub: '21.59 × 27.94 cm' }
    },
    DEFAULT_MARGINS: { top: 25.4, right: 25.4, bottom: 25.4, left: 25.4 },
    els: {},
    settings: null,
    state: { path: null, ext: '.docx', title: 'Untitled', dirty: false, zoom: 1, preview: true, ruler: true },
    commands: Object.create(null),
    savedRange: null,
    bridge: window.ecritoire || null // null when running in a plain browser (demo/tests)
  };
  Lb.settings = { margins: Object.assign({}, Lb.DEFAULT_MARGINS), paper: 'A4', orientation: 'portrait', title: 'Untitled' };
  // current page size in millimetres, following paper size and orientation
  const paperDims = () => {
    const p = Lb.PAPERS[Lb.settings.paper] || Lb.PAPERS.A4;
    return Lb.settings.orientation === 'landscape' ? [p.h, p.w] : [p.w, p.h];
  };
  Object.defineProperty(Lb, 'PAGE_W_MM', { get: () => paperDims()[0], enumerable: true });
  Object.defineProperty(Lb, 'PAGE_H_MM', { get: () => paperDims()[1], enumerable: true });
  /** Name of the paper that best matches a size in mm (either orientation), or null. */
  Lb.paperFor = (wMm, hMm) => {
    const a = Math.min(wMm, hMm), b = Math.max(wMm, hMm);
    for (const [k, p] of Object.entries(Lb.PAPERS)) if (Math.abs(p.w - a) < 3 && Math.abs(p.h - b) < 3) return k;
    return null;
  };
  Lb.paperLabel = () => {
    const p = Lb.PAPERS[Lb.settings.paper] || Lb.PAPERS.A4;
    return `${p.label} ${Lb.settings.orientation === 'landscape' ? 'Landscape' : 'Portrait'}`;
  };
  Lb.pageW = () => Lb.PAGE_W_MM * Lb.MM;
  Lb.pageH = () => Lb.PAGE_H_MM * Lb.MM;
  Lb.mm = (v) => v * Lb.MM;

  /* ---------- events ---------- */
  const listeners = {};
  Lb.on = (ev, fn) => { (listeners[ev] = listeners[ev] || []).push(fn); };
  Lb.emit = (ev, ...args) => { (listeners[ev] || []).forEach((fn) => { try { fn(...args); } catch (e) { console.error(e); } }); };

  /* ---------- commands ---------- */
  const lastRun = {};
  Lb.register = (name, fn) => { Lb.commands[name] = fn; };
  Lb.run = (name, arg, opts) => {
    const fn = Lb.commands[name];
    if (!fn) { console.warn('Unknown command', name); return; }
    // de-duplicate: on macOS a shortcut may arrive both from the native menu
    // and from the page; ignore the second copy coming from the other source
    const now = Date.now();
    const src = opts && opts.source;
    const last = lastRun[name];
    if (src && last && last.src && last.src !== src && now - last.t < 150) return;
    lastRun[name] = { t: now, src };
    try { return fn(arg); } catch (e) { console.error(e); Lb.ui && Lb.ui.toast('Something went wrong: ' + e.message, 'error'); }
  };

  /* ---------- utils ---------- */
  Lb.util = {
    $,
    clamp: (v, a, b) => Math.min(b, Math.max(a, v)),
    round: (v, d) => { const f = Math.pow(10, d || 0); return Math.round(v * f) / f; },
    debounce(fn, ms) {
      let t;
      const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
      d.flush = (...a) => { clearTimeout(t); fn(...a); };
      d.cancel = () => clearTimeout(t);
      return d;
    },
    esc: (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    rgbToHex(c) {
      if (!c) return null;
      if (c[0] === '#') return c.length === 4 ? '#' + [...c.slice(1)].map((x) => x + x).join('') : c.toLowerCase();
      const m = c.match(/rgba?\(([^)]+)\)/);
      if (!m) return null;
      const p = m[1].split(/[,\s/]+/).filter(Boolean).map(Number);
      if (p.length > 3 && p[3] === 0) return null; // transparent
      return '#' + p.slice(0, 3).map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
    },
    isTransparent: (c) => !c || c === 'transparent' || /rgba\([^)]*,\s*0\s*\)$/.test(c),
    pxToPt: (px) => Math.round(px * 0.75 * 2) / 2,
    ptToPx: (pt) => pt / 0.75,
    cmToPx: (cm) => cm * 10 * Lb.MM,
    pxToCm: (px) => Math.round((px / Lb.MM / 10) * 100) / 100,
    firstFamily(ff) { return (ff || '').split(',')[0].trim().replace(/^["']|["']$/g, ''); },
    fileBase: (p) => (p ? p.split(/[\\/]/).pop() : 'Untitled')
  };

  /* ---------- selection ---------- */
  Lb.sel = {
    range() {
      const s = window.getSelection();
      return s && s.rangeCount ? s.getRangeAt(0) : null;
    },
    inEditor(range) {
      const r = range || Lb.sel.range();
      return !!(r && Lb.els.editor && Lb.els.editor.contains(r.commonAncestorContainer));
    },
    save() {
      const r = Lb.sel.range();
      if (r && Lb.sel.inEditor(r)) Lb.savedRange = r.cloneRange();
    },
    restore() {
      const ed = Lb.els.editor;
      if (document.activeElement !== ed) ed.focus({ preventScroll: true });
      const r = Lb.sel.range();
      if (r && Lb.sel.inEditor(r) && !Lb.restoreForced) return r;
      if (Lb.savedRange && ed.contains(Lb.savedRange.commonAncestorContainer)) {
        const s = window.getSelection();
        s.removeAllRanges();
        s.addRange(Lb.savedRange);
        return Lb.savedRange;
      }
      // fall back to the start of the document
      const rr = document.createRange();
      rr.selectNodeContents(ed.firstElementChild || ed);
      rr.collapse(true);
      const s = window.getSelection();
      s.removeAllRanges(); s.addRange(rr);
      return rr;
    },
    focusElement() {
      const r = Lb.sel.range();
      if (!r) return null;
      let n = r.endContainer;
      if (n.nodeType === 1) {
        // descend to the inline content the caret actually touches
        const child = r.collapsed ? (n.childNodes[r.endOffset] || n.childNodes[r.endOffset - 1]) : n.childNodes[r.endOffset - 1];
        if (child) {
          n = child;
          while (n.nodeType === 1 && n.firstChild && !/^(IMG|BR|TABLE|UL|OL)$/.test(n.tagName)) n = n.firstChild;
        }
      }
      if (n.nodeType !== 1) n = n.parentElement;
      if (n && n.tagName === 'BR') n = n.parentElement;
      return n;
    },
    placeCaretAtEnd(el) {
      const r = document.createRange();
      r.selectNodeContents(el);
      r.collapse(false);
      const s = window.getSelection();
      s.removeAllRanges(); s.addRange(r);
    }
  };

  /* ---------- blocks ---------- */
  const BLOCK_SEL = 'p,h1,h2,h3,h4,h5,h6,li,blockquote,pre,div:not(.lb-page-break)';
  Lb.BLOCK_SEL = BLOCK_SEL;
  Lb.isBlock = (el) => el && el.nodeType === 1 && el.matches(BLOCK_SEL) && el !== Lb.els.editor;
  Lb.closestBlock = (node) => {
    let n = node && (node.nodeType === 1 ? node : node.parentElement);
    while (n && n !== Lb.els.editor) {
      if (Lb.isBlock(n)) return n;
      if (/^(TD|TH)$/.test(n.tagName)) return null;
      n = n.parentElement;
    }
    return null;
  };
  /** Text blocks touched by the current selection (innermost only). */
  Lb.selectedBlocks = () => {
    const r = Lb.sel.range();
    if (!r || !Lb.sel.inEditor(r)) return [];
    const ed = Lb.els.editor;
    const out = [];
    if (r.collapsed) {
      const b = Lb.closestBlock(r.startContainer);
      return b ? [b] : [];
    }
    for (const el of ed.querySelectorAll(BLOCK_SEL)) {
      if (r.intersectsNode(el)) out.push(el);
    }
    // keep innermost blocks (drop containers of other selected blocks), but keep
    // list items whose own text is selected even if they contain nested lists
    return out.filter((el) => !out.some((o) => o !== el && el.contains(o) && !(el.tagName === 'LI' && o.closest('ul,ol') !== el.closest('ul,ol') && liOwnTextSelected(el, r))));
  };
  function liOwnTextSelected(li, r) {
    for (const n of li.childNodes) {
      if (n.nodeType === 1 && /^(UL|OL)$/.test(n.tagName)) continue;
      if (r.intersectsNode(n)) return true;
    }
    return false;
  }

  /** Make sure loose inline content (e.g. directly in a table cell) is wrapped in a paragraph. */
  Lb.ensureBlocks = () => {
    const r = Lb.sel.range();
    if (!r || !Lb.sel.inEditor(r)) return;
    const b = Lb.closestBlock(r.startContainer);
    if (!b) document.execCommand('formatBlock', false, 'p');
  };

  /**
   * Repair invalid nesting the browser's editing commands sometimes produce,
   * e.g. <p><ul>…</ul></p> after "insert list" in an empty paragraph.
   */
  Lb.fixStructure = () => {
    const ed = Lb.els.editor;
    let guard = 0;
    let bad;
    while ((bad = ed.querySelector('p > ul, p > ol, p > table, p > p, p > h1, p > h2, p > h3, p > h4, p > h5, p > h6, p > blockquote, p > div, h1 > ul, h2 > ul, h3 > ul, h1 > ol, h2 > ol, h3 > ol')) && guard++ < 500) {
      const parent = bad.parentElement;
      const tail = parent.cloneNode(false);
      while (bad.nextSibling) tail.appendChild(bad.nextSibling);
      parent.after(bad);
      const hasContent = (el) => el.textContent.replace(/[\u200B\s]/g, '') || el.querySelector('img,br,table');
      if (hasContent(tail)) bad.after(tail);
      if (!parent.textContent.replace(/[\u200B\s]/g, '') && !parent.querySelector('img')) parent.remove();
    }
  };

  window.Lb = Lb;
})();
