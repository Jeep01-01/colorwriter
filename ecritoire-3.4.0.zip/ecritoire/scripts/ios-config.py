#!/usr/bin/env python3
"""Apply Écritoire's icon, splash screen and Info.plist settings to the iOS project.

Run after `npx cap add ios` (the iOS workflow does this for you). Safe to run again.

    python3 scripts/ios-config.py

Icon source, first one found:
    ios-res/AppIcon-1024.png   (full square 1024 x 1024 iOS icon; iOS rounds the corners)
    build/icon.png
    build/logo.png
Needs Pillow:  pip install pillow
"""
import json
import plistlib
import shutil
import sys
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "ios" / "App" / "App"
ASSETS = APP / "Assets.xcassets"
BACKGROUND = (11, 11, 12)  # Écritoire's near-black

if not APP.is_dir():
    sys.exit("ios/App/App not found: run `npx cap add ios` first.")


def source_image() -> Image.Image:
    for rel in ("ios-res/AppIcon-1024.png", "build/icon.png", "build/logo.png"):
        p = ROOT / rel
        if p.is_file():
            print(f"icon source: {rel}")
            return Image.open(p).convert("RGBA")
    sys.exit("No icon source found (ios-res/AppIcon-1024.png, build/icon.png or build/logo.png).")


def flatten(img: Image.Image, size: int) -> Image.Image:
    """Square, opaque RGB image: the App Store rejects icons with transparency."""
    img = img.copy()
    img.thumbnail((size, size), Image.LANCZOS)
    canvas = Image.new("RGB", (size, size), BACKGROUND)
    canvas.paste(img, ((size - img.width) // 2, (size - img.height) // 2), img)
    return canvas


def write_contents(folder: Path, contents: dict) -> None:
    (folder / "Contents.json").write_text(json.dumps(contents, indent=2) + "\n")


src = source_image()

# --- App icon: one 1024 x 1024 image, Xcode makes every other size ------------
icon_dir = ASSETS / "AppIcon.appiconset"
if icon_dir.exists():
    shutil.rmtree(icon_dir)
icon_dir.mkdir(parents=True)
flatten(src, 1024).save(icon_dir / "AppIcon-1024.png", optimize=True)
write_contents(icon_dir, {
    "images": [{"filename": "AppIcon-1024.png", "idiom": "universal",
                "platform": "ios", "size": "1024x1024"}],
    "info": {"author": "xcode", "version": 1},
})

# --- Splash: logo centred on near-black, 2732 x 2732 covers every iPhone and iPad
splash_dir = ASSETS / "Splash.imageset"
if splash_dir.exists():
    shutil.rmtree(splash_dir)
splash_dir.mkdir(parents=True)
logo_path = ROOT / "build" / "logo.png"
logo = Image.open(logo_path).convert("RGBA") if logo_path.is_file() else src
mark = logo.copy()
mark.thumbnail((560, 560), Image.LANCZOS)
splash = Image.new("RGB", (2732, 2732), BACKGROUND)
splash.paste(mark, ((2732 - mark.width) // 2, (2732 - mark.height) // 2), mark)
names = ["splash-2732x2732.png", "splash-2732x2732-1.png", "splash-2732x2732-2.png"]
for name in names:
    splash.save(splash_dir / name, optimize=True)
write_contents(splash_dir, {
    "images": [{"idiom": "universal", "filename": n, "scale": s}
               for n, s in zip(names, ("1x", "2x", "3x"))],
    "info": {"author": "xcode", "version": 1},
})

# --- Info.plist ------------------------------------------------------------------
plist_path = APP / "Info.plist"
with plist_path.open("rb") as f:
    info = plistlib.load(f)

info.update({
    "CFBundleDisplayName": "Écritoire",
    # Only standard HTTPS/OS encryption: skips the export-compliance question per upload.
    "ITSAppUsesNonExemptEncryption": False,
    # Saved documents show up in the Files app under "On My iPhone › Écritoire".
    "UIFileSharingEnabled": True,
    "LSSupportsOpeningDocumentsInPlace": True,
    # The picture picker in a web view can offer "Take Photo"; without these
    # strings iOS closes the app when it is chosen.
    "NSCameraUsageDescription":
        "Écritoire uses the camera only when you choose to take a photo to insert into your document.",
    "NSPhotoLibraryUsageDescription":
        "Écritoire opens your photo library only when you choose a picture to insert into your document.",
    "UIStatusBarStyle": "UIStatusBarStyleLightContent",
    "UIViewControllerBasedStatusBarAppearance": True,
})
# iPad: allow every orientation so the app supports Split View and Stage Manager.
info["UISupportedInterfaceOrientations~ipad"] = [
    "UIInterfaceOrientationPortrait",
    "UIInterfaceOrientationPortraitUpsideDown",
    "UIInterfaceOrientationLandscapeLeft",
    "UIInterfaceOrientationLandscapeRight",
]

with plist_path.open("wb") as f:
    plistlib.dump(info, f)

print("iOS icon, splash and Info.plist updated.")
