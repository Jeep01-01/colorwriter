#!/usr/bin/env python3
"""Make every Écritoire icon from one logo picture.

Usage:  python3 scripts/make-icons.py [build/logo.png]
Needs:  Pillow and numpy  (python3 -m pip install pillow numpy)

The logo must be a PNG of the dark rounded tile on a transparent background.
Writes:
  build/icon.png, build/icon.ico          desktop app (Windows, macOS, Linux)
  src/icon.png                            logo inside the app (title bar, File tab)
  android-res/res/...                     Android launcher icons (adaptive + legacy)
  android-res/splash-mark.png             Android splash screen
  play-store/icon-512.png                 Google Play icon (full square; Play rounds it)
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'build', 'logo.png')
P = lambda *a: os.path.join(ROOT, *a)


def save(img, *parts):
    path = P(*parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, optimize=True)
    print('  ' + os.path.relpath(path, ROOT), img.size)


def sharp_resize(img, size):
    """Resize with Lanczos; a light unsharp mask keeps enlarged edges crisp."""
    out = img.resize((size, size), Image.LANCZOS)
    if size > img.width:
        rgb = out.convert('RGB').filter(ImageFilter.UnsharpMask(radius=1.2, percent=60, threshold=2))
        out = Image.merge('RGBA', (*rgb.split(), out.getchannel('A')))
    return out


# ---------------------------------------------------------------------------
# 1. the logo tile, square and transparent around the rounded corners
logo = Image.open(SRC).convert('RGBA')
logo = logo.crop(logo.getbbox())
s = max(logo.size)
sq = Image.new('RGBA', (s, s))
sq.paste(logo, ((s - logo.width) // 2, (s - logo.height) // 2))
tile = sharp_resize(sq, 1024)
print('logo:', SRC, '->', tile.size)

# ---------------------------------------------------------------------------
# 2. split the tile into "background gradient" and "artwork" (for Android's
#    adaptive icon, which draws its own background shape)
a = np.asarray(tile).astype(np.float32)
H, W = a.shape[:2]
inside = a[..., 3] > 250
# background colour of every row, sampled from the empty left strip of the tile
strip = a[:, int(W * 0.04):int(W * 0.10), :3]
bg_row = np.zeros((H, 3), np.float32)
for y in range(H):
    m = inside[y, int(W * 0.04):int(W * 0.10)]
    bg_row[y] = np.median(strip[y][m], axis=0) if m.any() else np.nan
valid = ~np.isnan(bg_row[:, 0])
for c in range(3):
    bg_row[:, c] = np.interp(np.arange(H), np.flatnonzero(valid), bg_row[valid, c])
bg = np.repeat(bg_row[:, None, :], W, axis=1)
diff = np.abs(a[..., :3] - bg).max(axis=2) * inside
solid = diff > 28
# fill enclosed holes (the dark "L" sits inside the amber sheet)
holes = Image.fromarray((solid * 255).astype(np.uint8)).convert('RGB')
ImageDraw.floodfill(holes, (0, 0), (255, 0, 0))   # paint everything reachable from the corner
h = np.asarray(holes)
filled = ~((h[..., 0] == 255) & (h[..., 1] == 0))
# soft edge: alpha from colour difference near the border, solid inside
alpha = np.clip((diff - 6) / 30.0, 0, 1)
core = np.asarray(Image.fromarray((filled * 255).astype(np.uint8)).filter(ImageFilter.MinFilter(5))) > 0
alpha = np.where(core, 1.0, np.where(filled, np.maximum(alpha, 0.0), alpha))
alpha *= inside
un = np.where(alpha[..., None] > 0.01, (a[..., :3] - (1 - alpha[..., None]) * bg) / np.maximum(alpha[..., None], 0.01), 0)
art = Image.fromarray(np.dstack([np.clip(un, 0, 255), alpha * 255]).astype(np.uint8), 'RGBA')
abox = art.getbbox()
top_col = tuple(int(v) for v in bg_row[int(H * 0.06)])
bot_col = tuple(int(v) for v in bg_row[int(H * 0.94)])
print('artwork box:', abox, ' tile gradient:', top_col, '->', bot_col)


def gradient(size):
    g = Image.new('RGBA', (size, size))
    d = ImageDraw.Draw(g)
    for y in range(size):
        t = y / max(1, size - 1)
        d.line([(0, y), (size, y)], fill=tuple(int(top_col[i] + (bot_col[i] - top_col[i]) * t) for i in range(3)) + (255,))
    return g


def art_on(canvas_size, art_fraction, bg_img=None):
    """Artwork centred on a canvas; art_fraction = share of the canvas its longest side uses."""
    piece = art.crop(abox)
    k = canvas_size * art_fraction / max(piece.size)
    piece = piece.resize((max(1, round(piece.width * k)), max(1, round(piece.height * k))), Image.LANCZOS)
    c = bg_img.copy() if bg_img is not None else Image.new('RGBA', (canvas_size, canvas_size))
    # keep the artwork's position relative to the tile centre
    cx = (abox[0] + abox[2]) / 2 - W / 2
    cy = (abox[1] + abox[3]) / 2 - H / 2
    ox = round(canvas_size / 2 + cx * k - piece.width / 2)
    oy = round(canvas_size / 2 + cy * k - piece.height / 2)
    c.alpha_composite(piece, (ox, oy))
    return c


# share of the tile that the artwork's longest side uses in the original logo
ART_IN_TILE = max(abox[2] - abox[0], abox[3] - abox[1]) / W

# ---------------------------------------------------------------------------
print('desktop:')
save(tile.resize((512, 512), Image.LANCZOS), 'build', 'icon.png')
ico_sizes = [16, 24, 32, 48, 64, 128, 256]
tile.resize((256, 256), Image.LANCZOS).save(P('build', 'icon.ico'), sizes=[(n, n) for n in ico_sizes])
print('  build/icon.ico', ico_sizes)
save(tile.resize((256, 256), Image.LANCZOS), 'src', 'icon.png')

print('play store:')
full = art_on(1024, ART_IN_TILE, gradient(1024))       # the tile without rounded corners
save(full.resize((512, 512), Image.LANCZOS).convert('RGB'), 'play-store', 'icon-512.png')

print('android:')
DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
for name, f in DENS.items():
    n = round(48 * f)          # legacy icon: 48 dp
    fg = round(108 * f)        # adaptive layer: 108 dp, safe zone 66 dp
    save(tile.resize((n, n), Image.LANCZOS), 'android-res', 'res', 'mipmap-' + name, 'ic_launcher.png')
    circle = Image.new('L', (n * 4, n * 4), 0)
    ImageDraw.Draw(circle).ellipse((0, 0, n * 4 - 1, n * 4 - 1), fill=255)
    rnd = art_on(n * 4, ART_IN_TILE * 0.86, gradient(n * 4))
    rnd.putalpha(circle)
    save(rnd.resize((n, n), Image.LANCZOS), 'android-res', 'res', 'mipmap-' + name, 'ic_launcher_round.png')
    save(art_on(fg, 0.46), 'android-res', 'res', 'mipmap-' + name, 'ic_launcher_foreground.png')

hexc = lambda c: '#%02X%02X%02X' % c
os.makedirs(P('android-res', 'res', 'drawable'), exist_ok=True)
with open(P('android-res', 'res', 'drawable', 'ic_launcher_bg.xml'), 'w', encoding='utf-8') as f:
    f.write(f'''<?xml version="1.0" encoding="utf-8"?>
<!-- Écritoire adaptive icon background: the logo tile's dark gradient (made by scripts/make-icons.py) -->
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient android:angle="270" android:startColor="{hexc(top_col)}" android:endColor="{hexc(bot_col)}" />
</shape>
''')
print('  android-res/res/drawable/ic_launcher_bg.xml', hexc(top_col), hexc(bot_col))
for name in ('ic_launcher.xml', 'ic_launcher_round.xml'):
    with open(P('android-res', 'res', 'mipmap-anydpi-v26', name), 'w', encoding='utf-8') as f:
        f.write('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_bg"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
''')
with open(P('android-res', 'res', 'values', 'ic_launcher_background.xml'), 'w', encoding='utf-8') as f:
    f.write(f'''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">{hexc(bot_col)}</color>
</resources>
''')
save(tile.resize((512, 512), Image.LANCZOS), 'android-res', 'splash-mark.png')
print('done')
