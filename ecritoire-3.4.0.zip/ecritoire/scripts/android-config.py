#!/usr/bin/env python3
"""Customise the generated Capacitor Android project for Écritoire.

Run after `npx cap add android` (the GitHub workflow does this for you):
  - copies the Écritoire launcher icons (android-res/res) into the project
  - redraws every splash.png as a dark screen with the Écritoire mark
  - lets Android 7-10 save into Documents (storage permission, legacy storage)
  - adds `density` to the activity's configChanges (Capacitor 8 recommendation)
  - sets versionName / versionCode from VERSION_NAME / VERSION_CODE
Needs Pillow:  python3 -m pip install pillow
"""
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(ROOT, 'android', 'app')
RES = os.path.join(APP, 'src', 'main', 'res')
MANIFEST = os.path.join(APP, 'src', 'main', 'AndroidManifest.xml')
GRADLE = os.path.join(APP, 'build.gradle')
VARIABLES = os.path.join(ROOT, 'android', 'variables.gradle')
SPLASH_BG = (11, 11, 12)


def fail(msg):
    print('ERROR: ' + msg, file=sys.stderr)
    sys.exit(1)


def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()


def write(path, text):
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)


if not os.path.isdir(RES):
    fail('android/ project not found. Run `npx cap add android` first.')

# 1. launcher icons ----------------------------------------------------------
src = os.path.join(ROOT, 'android-res', 'res')
copied = 0
for folder, _dirs, files in os.walk(src):
    rel = os.path.relpath(folder, src)
    dest = os.path.join(RES, rel)
    os.makedirs(dest, exist_ok=True)
    for name in files:
        shutil.copyfile(os.path.join(folder, name), os.path.join(dest, name))
        copied += 1
# a stale vector foreground would override our PNG foreground
for folder in os.listdir(RES):
    stale = os.path.join(RES, folder, 'ic_launcher_foreground.xml')
    if os.path.exists(stale):
        os.remove(stale)
print(f'icons: {copied} files')

# 2. splash screens ----------------------------------------------------------
try:
    from PIL import Image
except ImportError:
    fail('Pillow is missing: python3 -m pip install pillow')

mark = Image.open(os.path.join(ROOT, 'android-res', 'splash-mark.png')).convert('RGBA')
splashes = 0
for folder, _dirs, files in os.walk(RES):
    for name in files:
        if name != 'splash.png':
            continue
        path = os.path.join(folder, name)
        w, h = Image.open(path).size
        canvas = Image.new('RGBA', (w, h), SPLASH_BG + (255,))
        size = max(1, int(min(w, h) * 0.42))
        m = mark.resize((size, size), Image.LANCZOS)
        canvas.alpha_composite(m, ((w - size) // 2, (h - size) // 2))
        canvas.convert('RGB').save(path)
        splashes += 1
print(f'splash: {splashes} images')

# Android 12+ system splash: dark background + our icon (only when the theme
# is based on the androidx SplashScreen theme, where these attributes exist)
styles = os.path.join(RES, 'values', 'styles.xml')
if os.path.exists(styles):
    s = read(styles)
    m = re.search(r'<style name="AppTheme\.NoActionBarLaunch" parent="([^"]+)">', s)
    if m and 'SplashScreen' in m.group(1) and 'windowSplashScreenBackground' not in s:
        s = s.replace(m.group(0), m.group(0) +
                      '\n        <item name="windowSplashScreenBackground">#0B0B0C</item>'
                      '\n        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>')
        write(styles, s)
        print('splash: Android 12+ theme updated')
colors = os.path.join(RES, 'values', 'colors.xml')
if os.path.exists(colors):
    c = read(colors)
    c = re.sub(r'(<color name="colorPrimary(?:Dark)?">)[^<]*(</color>)', r'\g<1>#0B0B0C\2', c)
    c = re.sub(r'(<color name="colorAccent">)[^<]*(</color>)', r'\g<1>#F59E0B\2', c)
    write(colors, c)

# 3. manifest ----------------------------------------------------------------
man = read(MANIFEST)
if 'WRITE_EXTERNAL_STORAGE' not in man:
    man = man.replace('</manifest>',
                      '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />\n'
                      '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n'
                      '</manifest>')
if 'requestLegacyExternalStorage' not in man:
    man = re.sub(r'<application\b', '<application\n        android:requestLegacyExternalStorage="true"', man, count=1)


def add_density(match):
    values = match.group(1).split('|')
    if 'density' not in values:
        values.append('density')
    return 'android:configChanges="' + '|'.join(values) + '"'


man = re.sub(r'android:configChanges="([^"]*)"', add_density, man)
write(MANIFEST, man)
print('manifest: storage permission (Android 10 and older), legacy storage, configChanges+density')

# 4. version -----------------------------------------------------------------
g = read(GRADLE)
name = os.environ.get('VERSION_NAME')
code = os.environ.get('VERSION_CODE')
if name:
    g = re.sub(r'versionName\s+"[^"]*"', f'versionName "{name}"', g)
if code:
    g = re.sub(r'versionCode\s+\d+', f'versionCode {int(code)}', g)
write(GRADLE, g)
print(f'version: name={name or "(unchanged)"} code={code or "(unchanged)"}')

# 5. target SDK check (Google Play requires API 36 since 31 Aug 2026) --------
if os.path.exists(VARIABLES):
    v = read(VARIABLES)
    t = re.search(r'targetSdkVersion\s*=\s*(\d+)', v)
    if t:
        target = int(t.group(1))
        print(f'targetSdkVersion = {target}')
        if target < 36:
            v = re.sub(r'targetSdkVersion\s*=\s*\d+', 'targetSdkVersion = 36', v)
            v = re.sub(r'compileSdkVersion\s*=\s*(\d+)', lambda mm: f'compileSdkVersion = {max(36, int(mm.group(1)))}', v)
            write(VARIABLES, v)
            print('targetSdkVersion raised to 36 for Google Play')
print('Android project ready.')
