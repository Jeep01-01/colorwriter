#!/usr/bin/env node
'use strict';
/**
 * Builds www/ — the editor packaged for the Android app (Capacitor).
 * The editor in src/, plus:
 *   - browser builds of docx, JSZip, html-to-image and pdf-lib in www/vendor/
 *   - lib/docx-writer.js (works in the browser too)
 *   - src/js/bridge-mobile.js (phone and tablet file access) and pdf-export.js
 */
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const out = path.join(root, 'www');

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const a = path.join(from, entry.name);
    const b = path.join(to, entry.name);
    if (entry.isDirectory()) copyDir(a, b);
    else fs.copyFileSync(a, b);
  }
}

function resolveFile(pkg, candidates) {
  // look in node_modules directly: some packages hide package.json behind "exports"
  const base = path.join(root, 'node_modules', pkg);
  for (const c of candidates) {
    const f = path.join(base, c);
    if (fs.existsSync(f)) return f;
  }
  throw new Error(`Could not find a browser build of ${pkg} (looked for ${candidates.join(', ')})`);
}

fs.rmSync(out, { recursive: true, force: true });
copyDir(path.join(root, 'src'), out);

const vendor = path.join(out, 'vendor');
fs.mkdirSync(vendor, { recursive: true });
const libs = [
  ['jszip', ['dist/jszip.min.js'], 'jszip.min.js'],
  ['docx', ['dist/index.iife.js', 'build/index.iife.js', 'dist/index.umd.cjs', 'build/index.umd.js'], 'docx.js'],
  ['html-to-image', ['dist/html-to-image.js'], 'html-to-image.js'],
  ['pdf-lib', ['dist/pdf-lib.min.js'], 'pdf-lib.min.js']
];
for (const [pkg, candidates, name] of libs) fs.copyFileSync(resolveFile(pkg, candidates), path.join(vendor, name));
// wrapped in its own scope so its names don't clash with the docx global
const writer = fs.readFileSync(path.join(root, 'lib', 'docx-writer.js'), 'utf8');
if (!writer.includes('LbDocxWriter')) {
  throw new Error('lib/docx-writer.js is an old version that only works on the desktop. ' +
    'Use the lib/docx-writer.js that contains "LbDocxWriter" and build again.');
}
fs.writeFileSync(path.join(out, 'js', 'docx-writer.js'), `(function () {\n${writer}\n})();\n`);

// index.html: local vendor paths + Android-only scripts
const indexPath = path.join(out, 'index.html');
let html = fs.readFileSync(indexPath, 'utf8');
html = html.replace('../node_modules/jszip/dist/jszip.min.js', 'vendor/jszip.min.js');
const before = '<script src="js/core.js"></script>';
if (!html.includes(before)) throw new Error('index.html layout changed: core.js script tag not found');
html = html.replace(before, [
  '<script src="vendor/docx.js"></script>',
  '<script src="vendor/html-to-image.js"></script>',
  '<script src="vendor/pdf-lib.min.js"></script>',
  '<script src="js/docx-writer.js"></script>',
  '<script src="js/bridge-mobile.js"></script>',
  before
].join('\n'));
html = html.replace('<script src="js/app.js"></script>', '<script src="js/pdf-export.js"></script>\n<script src="js/app.js"></script>');
fs.writeFileSync(indexPath, html);

// Self-test: load the Android .docx writer the way the phone does and make
// sure it can really create a .docx — so a broken app is never built.
(async () => {
  const vm = require('vm');
  const sandbox = { atob: (s) => Buffer.from(s, 'base64').toString('binary'), btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
    console, setTimeout, clearTimeout, setImmediate, clearImmediate, queueMicrotask, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob, Promise };
  sandbox.window = sandbox; sandbox.self = sandbox; sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  for (const f of ['vendor/docx.js', 'js/docx-writer.js']) vm.runInContext(fs.readFileSync(path.join(out, f), 'utf8'), sandbox, { filename: f });
  if (!sandbox.LbDocxWriter || typeof sandbox.LbDocxWriter.buildDocx !== 'function') throw new Error('Self-test failed: the .docx writer did not load (LbDocxWriter missing).');
  const b64 = await sandbox.LbDocxWriter.buildDocx({ blocks: [{ type: 'p', runs: [{ text: 'Écritoire self-test', b: true }] }] });
  const bytes = Buffer.from(String(b64), 'base64');
  if (bytes.length < 2000 || bytes[0] !== 0x50 || bytes[1] !== 0x4b) throw new Error('Self-test failed: the .docx writer did not produce a valid .docx.');
  console.log(`self-test: Android .docx writer OK (${bytes.length} bytes)`);
})().catch((e) => { console.error('ERROR: ' + e.message); process.exit(1); });

const count = (dir) => fs.readdirSync(dir, { withFileTypes: true }).reduce((n, e) => n + (e.isDirectory() ? count(path.join(dir, e.name)) : 1), 0);
console.log(`www/ ready (${count(out)} files)`);
