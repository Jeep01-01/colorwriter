# Adds Écritoire's privacy manifest (ios-res/PrivacyInfo.xcprivacy) to the Xcode project
# so it is bundled with the app. Safe to run again. Needs the xcodeproj gem
# (gem install xcodeproj; it comes with CocoaPods).
#
#   ruby scripts/ios-privacy.rb

require 'fileutils'

root    = File.expand_path('..', __dir__)
src     = File.join(root, 'ios-res', 'PrivacyInfo.xcprivacy')
app_dir = File.join(root, 'ios', 'App', 'App')
proj    = File.join(root, 'ios', 'App', 'App.xcodeproj')

abort 'ios/App not found: run `npx cap add ios` first.' unless File.directory?(proj)

FileUtils.cp(src, File.join(app_dir, 'PrivacyInfo.xcprivacy'))

begin
  require 'xcodeproj'
  project = Xcodeproj::Project.open(proj)
  target  = project.targets.find { |t| t.name == 'App' } or raise 'App target not found'
  group   = project.main_group['App'] or raise 'App group not found'

  if group.files.any? { |f| f.path == 'PrivacyInfo.xcprivacy' }
    puts 'Privacy manifest already in the project.'
  else
    ref = group.new_reference('PrivacyInfo.xcprivacy')
    target.resources_build_phase.add_file_reference(ref, true)
    project.save
    puts 'Privacy manifest added to the project.'
  end
rescue LoadError, StandardError => e
  # Not fatal: Capacitor and its plugins ship their own manifests.
  warn "Could not add the privacy manifest automatically (#{e.message})."
  warn 'In Xcode: drag ios/App/App/PrivacyInfo.xcprivacy into the App group and tick the App target.'
end
