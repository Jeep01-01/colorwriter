# Écritoire on your iPhone and iPad

GitHub builds the app on a Mac in the cloud and sends it to **TestFlight**, Apple's app for installing your own apps before (or without) publishing them. You don't need a Mac.

**What you need:** an **Apple Developer Program** membership (USD 99 a year). Apple doesn't allow installing your own apps on an iPhone any other way without a Mac. With a Mac and Xcode you could install it free, but it stops working after 7 days.

**Overview**

1. Join the Apple Developer Program.
2. Register the app ID.
3. Make an API key and add it to GitHub as secrets.
4. Create the app in App Store Connect (private, not published).
5. Run the iOS build.
6. Install it with TestFlight.

---

## 1. Join the Apple Developer Program

Enrol at **developer.apple.com/programs**. **Individual** is quickest (usually a day or two). Your Apple Account needs two-factor authentication turned on.

## 2. Register the app ID

developer.apple.com → **Certificates, Identifiers & Profiles → Identifiers → +** → **App IDs** → **App**:

- Description: `Ecritoire`
- Bundle ID (**Explicit**): `com.bluesky.ecritoire`
- Capabilities: leave the defaults.

## 3. API key and GitHub secrets

The key lets GitHub sign the app for you (no certificates to make by hand).

1. appstoreconnect.apple.com → **Users and Access → Integrations → App Store Connect API → Team Keys → +**.
2. Name: `GitHub Ecritoire` · Access: **Admin**.
3. **Download** the `AuthKey_XXXXXXXXXX.p8` file. Apple lets you download it **only once**: keep a backup with your Android key file.
4. Note the **Key ID** (in the list) and the **Issuer ID** (above the list).
5. Your **Team ID** is on developer.apple.com → **Membership details**.

Turn the key file into text. On Windows (PowerShell, in the folder with the file):

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("AuthKey_XXXXXXXXXX.p8")) | Set-Clipboard
```

The text is now on your clipboard. On GitHub: repository → **Settings → Secrets and variables → Actions → New repository secret**:

| Name | Value |
|---|---|
| `APPLE_TEAM_ID` | your 10-character Team ID |
| `APP_STORE_CONNECT_KEY_ID` | the Key ID |
| `APP_STORE_CONNECT_ISSUER_ID` | the Issuer ID |
| `APP_STORE_CONNECT_KEY_BASE64` | the text you just copied |

> If you already made a key for Lembaran, you can use the same key and the same four values here.

## 4. Create the app in App Store Connect

appstoreconnect.apple.com → **Apps → + → New App**:

- Platforms: **iOS**
- Name: `Écritoire` (this also **reserves the name** on the App Store for you)
- Primary language: English
- Bundle ID: `com.bluesky.ecritoire`
- SKU: `ecritoire-ios`
- User access: Full Access

You **don't** fill in the store listing or submit anything for review. The app stays private: only you (and people you invite) can install it.

If Apple says the name is already in use, try `Écritoire – Documents`. The name on your home screen stays "Écritoire" either way.

## 5. Build

Repository → **Actions** → **iOS** → **Run workflow** (leave *Upload* ticked) → **Run workflow**.

It takes about 15–25 minutes. Then Apple processes the build for another 5–30 minutes and emails you when it's ready in TestFlight.

Without the secrets, the workflow only runs a compile check, which is useful to see that everything builds before you pay for the membership.

## 6. Install with TestFlight

1. App Store Connect → your app → **TestFlight**.
2. Under **Internal Testing**, click **+**, create a group (e.g. `Me`) and add yourself. Your own account is already on the team.
3. Add the build to the group. The first time, answer the export compliance question: the app already says it uses no special encryption, so this is usually skipped.
4. On your iPhone or iPad, install **TestFlight** from the App Store, sign in with the same Apple Account, and tap **Install** next to Écritoire.

Internal testing needs **no Apple review**. Each TestFlight build works for **90 days**; before it expires, run the workflow again and install the new build.

Your documents are saved in the **Files** app under **On My iPhone › Écritoire** (or **On My iPad**).

## Things to try on the iPhone

- [ ] Open a `.docx` from Files, iCloud Drive or a Mail attachment (File › Open)
- [ ] Save as `.docx` and PDF, then find them in Files › On My iPhone › Écritoire
- [ ] Share to Mail or Messages; Print (opens the PDF, then Share › Print)
- [ ] Insert a picture from Photos, and with Take Photo
- [ ] A template with a cover page, contents and footnotes, saved as PDF
- [ ] Nothing hidden under the notch, the Dynamic Island or the home bar
- [ ] iPad: rotation and Split View

Tell Claude about anything that doesn't work; a few things (PDF pictures, the keyboard) can only be checked on a real iPhone.

## If the build fails

Open the failed run in the Actions tab, click the red step and copy the last 30 lines of the log. The usual causes:

| Message contains | Fix |
|---|---|
| `No Accounts` / `authentication` | a secret is wrong: check the Key ID, Issuer ID and that the base64 text is complete |
| `No profiles for 'com.bluesky.ecritoire'` | the bundle ID isn't registered (step 2) or the key isn't **Admin** |
| `No suitable application records were found` | create the app in App Store Connect first (step 4) |
| `bundle version must be higher` | run the workflow again; each run gets a higher build number |
| `Xcode 26 or newer` | in `.github/workflows/ios.yml`, change `runs-on: macos-latest` to `runs-on: macos-26` |
