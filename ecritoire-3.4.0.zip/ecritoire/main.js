'use strict';
/**
 * Écritoire — desktop app (Electron), for Windows 11.
 * Owns windows, the menu bar, file dialogs, file I/O, PDF export and printing.
 * The editor itself is the same src/ the phone and tablet apps use; it talks to
 * this process only through preload.js (window.ecritoire).
 */
const { app, BrowserWindow, Menu, dialog, ipcMain, shell, screen } = require('electron');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildDocx } = require('./lib/docx-writer');

const isMac = process.platform === 'darwin';
const NAME = 'Écritoire';
const DOC_EXTS = ['.docx'];
const windows = new Set();
let pendingOpenPath = null; // a file passed before the first window is ready

if (process.platform === 'win32') app.setAppUserModelId('com.bluesky.ecritoire');

/* ------------------------------------------------------------------ */
/* Windows                                                              */
/* ------------------------------------------------------------------ */
// Size, position and maximised state are remembered between sessions, like Word.
const stateFile = () => path.join(app.getPath('userData'), 'window-state.json');
function loadWindowState() {
  try {
    const s = JSON.parse(fs.readFileSync(stateFile(), 'utf8'));
    if (!(s.width >= 900 && s.height >= 600)) return null;
    // only if it is still on a connected screen
    const visible = screen.getAllDisplays().some(({ workArea: a }) =>
      s.x < a.x + a.width - 100 && s.x + s.width > a.x + 100 && s.y >= a.y - 10 && s.y < a.y + a.height - 100);
    return Number.isFinite(s.x) && Number.isFinite(s.y) && visible ? s : { width: s.width, height: s.height, maximized: s.maximized };
  } catch (_) { return null; }
}
function saveWindowState(win) {
  try {
    const b = win.getNormalBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ x: b.x, y: b.y, width: b.width, height: b.height, maximized: win.isMaximized() }));
  } catch (_) { /* not important */ }
}

function createWindow(filePath) {
  // a second window opens a little lower and to the right of the current one
  const current = windows.size ? focusedWindow() : null;
  let bounds = loadWindowState() || { width: 1360, height: 900, maximized: false };
  if (current && !current.isDestroyed()) {
    const b = current.getNormalBounds();
    bounds = { x: b.x + 30, y: b.y + 30, width: b.width, height: b.height, maximized: false };
  }
  const win = new BrowserWindow({
    x: bounds.x,
    y: bounds.y,
    width: bounds.width,
    height: bounds.height,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0b0b0c',
    title: NAME,
    icon: path.join(__dirname, 'build', 'icon.png'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: true
    }
  });
  win.ecritoire = { dirty: false, forceClose: false, initialPath: filePath || null };
  windows.add(win);

  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  win.once('ready-to-show', () => { if (bounds.maximized) win.maximize(); win.show(); });
  if (process.argv.includes('--dev')) win.webContents.openDevTools({ mode: 'detach' });

  // Links open in the system browser; the editor window never navigates away
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());

  win.on('close', (e) => {
    saveWindowState(win);
    if (win.ecritoire.dirty && !win.ecritoire.forceClose) {
      e.preventDefault();
      win.webContents.send('app:request-close');
    }
  });
  win.on('closed', () => windows.delete(win));
  return win;
}

function focusedWindow() {
  return BrowserWindow.getFocusedWindow() || [...windows][0] || null;
}

function sendCommand(cmd, arg) {
  const win = focusedWindow();
  if (win) win.webContents.send('menu:command', cmd, arg);
}

/* ------------------------------------------------------------------ */
/* Menu bar                                                             */
/* ------------------------------------------------------------------ */
function buildMenu() {
  // Shortcuts are handled inside the editor page (the same on every platform);
  // on Windows the menu only *shows* them.
  const c = (label, cmd, accelerator, arg) => ({
    label, accelerator, registerAccelerator: isMac, click: () => sendCommand(cmd, arg)
  });
  const template = [
    ...(isMac ? [{ role: 'appMenu' }] : []),
    {
      label: 'File',
      submenu: [
        c('New', 'new', 'CmdOrCtrl+N'),
        c('New from Template…', 'templates'),
        c('New Window', 'newWindow', 'CmdOrCtrl+Shift+N'),
        c('Open…', 'open', 'CmdOrCtrl+O'),
        { type: 'separator' },
        c('Save', 'save', 'CmdOrCtrl+S'),
        c('Save As…', 'saveAs', 'CmdOrCtrl+Shift+S'),
        c('Export to PDF…', 'exportPdf', 'CmdOrCtrl+Shift+E'),
        { type: 'separator' },
        c('Page Setup…', 'pageSetup'),
        c('Print Preview…', 'printPreview'),
        c('Print…', 'print', 'CmdOrCtrl+P'),
        { type: 'separator' },
        isMac ? { role: 'close' } : { role: 'quit', label: 'Exit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        c('Undo', 'undo', 'CmdOrCtrl+Z'),
        c('Redo', 'redo', isMac ? 'Cmd+Shift+Z' : 'Ctrl+Y'),
        { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' },
        c('Paste as Plain Text', 'pastePlain', 'CmdOrCtrl+Shift+V'),
        { role: 'selectAll' },
        { type: 'separator' },
        c('Find…', 'find', 'CmdOrCtrl+F')
      ]
    },
    {
      label: 'View',
      submenu: [
        c('Item && Layout Menu', 'toggleLeftPane'),
        { type: 'separator' },
        c('Zoom In', 'zoomIn', 'CmdOrCtrl+='),
        c('Zoom Out', 'zoomOut', 'CmdOrCtrl+-'),
        c('Actual Size (100%)', 'zoomReset', 'CmdOrCtrl+0'),
        c('Fit Page Width', 'zoomFit'),
        { type: 'separator' },
        c('Page Break Preview', 'togglePreview', 'CmdOrCtrl+Alt+P'),
        c('Ruler', 'toggleRuler', 'CmdOrCtrl+Alt+R'),
        { type: 'separator' },
        { role: 'togglefullscreen' },
        ...(app.isPackaged ? [] : [{ role: 'toggleDevTools' }])
      ]
    },
    {
      label: 'Item',
      submenu: [
        c('Picture…', 'insertPicture'),
        c('Shape…', 'insertShape'),
        c('Freeform Drawing', 'freeform'),
        c('Table…', 'insertTable'),
        c('Video…', 'insertVideo'),
        c('Page Break', 'pageBreak', 'CmdOrCtrl+Enter'),
        { type: 'separator' },
        c('Cover Page…', 'coverPage'),
        c('Table of Contents…', 'toc'),
        c('Header && Footer…', 'headerFooter'),
        c('Footnote…', 'footnote')
      ]
    },
    {
      label: 'Format',
      submenu: [
        c('Font…', 'fontDialog', 'CmdOrCtrl+D'),
        c('Paragraph…', 'paragraphDialog'),
        { type: 'separator' },
        c('Bullets', 'bullets', 'CmdOrCtrl+Shift+L'),
        c('Numbering', 'numbering')
      ]
    },
    {
      label: 'Help',
      submenu: [
        c('Keyboard Shortcuts', 'shortcuts'),
        c('About ' + NAME, 'about')
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

/* ------------------------------------------------------------------ */
/* File helpers                                                         */
/* ------------------------------------------------------------------ */
function readDocument(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.doc') {
    const e = new Error('Écritoire opens .docx documents. Older .doc files can be saved as .docx in Word or LibreOffice first.');
    e.code = 'DOC';
    throw e;
  }
  if (!DOC_EXTS.includes(ext)) throw new Error('Unsupported file type: ' + (ext || 'no extension'));
  const data = fs.readFileSync(filePath);
  app.addRecentDocument(filePath); // taskbar and Start menu: right-click Écritoire for recent documents
  return { path: filePath, name: path.basename(filePath), ext, data: new Uint8Array(data) };
}

function withExt(p, ext) {
  return path.extname(p).toLowerCase() === ext ? p : p + ext;
}

function contentCss() {
  try { return fs.readFileSync(path.join(__dirname, 'src', 'css', 'content.css'), 'utf8'); } catch (_) { return ''; }
}

const PAPERS = { A4: [210, 297], A5: [148, 210], A3: [297, 420], Letter: [215.9, 279.4] };
/** Page size in mm [width, height] from the document settings. */
function pageSizeMm(settings) {
  const s = settings || {};
  const [w, h] = PAPERS[s.paper] || PAPERS.A4;
  return s.orientation === 'landscape' ? [h, w] : [w, h];
}

function printableHtml(html, settings, paged) {
  const s = Object.assign({ margins: { top: 25.4, right: 25.4, bottom: 25.4, left: 25.4 } }, settings || {});
  const m = s.margins;
  const [pw, ph] = pageSizeMm(s);
  if (paged) {
    // already laid out page by page by the editor (see exporter.pagedHtml)
    return `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(s.title || 'Document')}</title>
<style>${contentCss()}
@page { size: ${pw}mm ${ph}mm; margin: 0; }
html, body { margin: 0; padding: 0; background: #fff; }
.lb-pp { position: relative; width: ${pw}mm; height: ${ph}mm; overflow: hidden; break-after: page; page-break-after: always; }
.lb-pp:last-child { break-after: auto; page-break-after: auto; }
.lb-content .lb-video video { display: none; }
</style></head><body>${html}</body></html>`;
  }
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(s.title || 'Document')}</title>
<style>${contentCss()}
@page { size: ${pw}mm ${ph}mm; margin: ${m.top}mm ${m.right}mm ${m.bottom}mm ${m.left}mm; }
html, body { margin: 0; padding: 0; background: #fff; }
.lb-content { padding: 0 !important; }
</style></head><body><div class="lb-content">${html}</div></body></html>`;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
}

async function withRenderWindow(html, settings, fn, paged) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ecritoire-print-'));
  const file = path.join(dir, 'document.html');
  fs.writeFileSync(file, printableHtml(html, settings, paged), 'utf8');
  const win = new BrowserWindow({
    show: false, width: 900, height: 1200,
    webPreferences: { sandbox: true, contextIsolation: true, javascript: false }
  });
  try {
    await win.loadFile(file);
    return await fn(win);
  } finally {
    if (!win.isDestroyed()) win.destroy();
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

async function exportPdf(html, settings, outPath, paged) {
  const [w, h] = pageSizeMm(settings);
  const buf = await withRenderWindow(html, settings, (win) => win.webContents.printToPDF({
    pageSize: { width: w / 25.4, height: h / 25.4 }, printBackground: true, preferCSSPageSize: true,
    ...(paged ? { margins: { top: 0, bottom: 0, left: 0, right: 0 } } : {})
  }), paged);
  fs.writeFileSync(outPath, buf);
}

/* ------------------------------------------------------------------ */
/* Messages from the editor                                             */
/* ------------------------------------------------------------------ */
ipcMain.handle('dialog:open', async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const res = await dialog.showOpenDialog(win, {
    title: 'Open document',
    properties: ['openFile'],
    filters: [
      { name: 'Word documents', extensions: ['docx'] },
      { name: 'All files', extensions: ['*'] }
    ]
  });
  if (res.canceled || !res.filePaths.length) return { canceled: true };
  try { return readDocument(res.filePaths[0]); } catch (err) { return { error: err.message, code: err.code }; }
});

ipcMain.handle('file:openPath', async (_e, p) => {
  try { return readDocument(p); } catch (err) { return { error: err.message, code: err.code }; }
});

ipcMain.handle('dialog:save', async (e, opts) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const o = opts || {};
  const filters = o.pdfOnly
    ? [{ name: 'PDF', extensions: ['pdf'] }]
    : [{ name: 'Word document', extensions: ['docx'] }, { name: 'PDF', extensions: ['pdf'] }];
  // the editor suggests a bare name ("Report.docx") for new documents: put it in Documents
  let def = o.defaultPath || (o.pdfOnly ? 'Document.pdf' : 'Document.docx');
  if (!path.isAbsolute(def)) def = path.join(app.getPath('documents'), def);
  const res = await dialog.showSaveDialog(win, { title: o.pdfOnly ? 'Export to PDF' : 'Save As', defaultPath: def, filters });
  if (res.canceled || !res.filePath) return null;
  let p = res.filePath;
  if (!path.extname(p)) p += o.pdfOnly ? '.pdf' : '.docx';
  return p;
});

ipcMain.handle('file:save', async (_e, req) => {
  try {
    const ext = path.extname(req.path).toLowerCase();
    if (ext === '.pdf') {
      await exportPdf(req.html, req.settings, req.path, !!req.paged);
      return { ok: true, path: req.path, format: 'pdf' };
    }
    const buf = await buildDocx(req.model);
    const outPath = withExt(req.path, '.docx');
    fs.writeFileSync(outPath, buf);
    app.addRecentDocument(outPath);
    return { ok: true, path: outPath, format: 'docx' };
  } catch (err) {
    return { error: err.message || String(err) };
  }
});

ipcMain.handle('file:print', async (_e, req) => {
  try {
    return await withRenderWindow(req.html, req.settings, (win) => new Promise((resolve) => {
      const s = req.settings || {};
      const [w, h] = pageSizeMm(Object.assign({}, s, { orientation: 'portrait' }));
      win.webContents.print({
        printBackground: true,
        pageSize: { width: Math.round(w * 1000), height: Math.round(h * 1000) }, // microns
        landscape: s.orientation === 'landscape',
        ...(req.paged ? { margins: { marginType: 'none' } } : {})
      }, (success, reason) => {
        resolve(success ? { ok: true } : { ok: false, reason });
      });
    }), !!req.paged);
  } catch (err) {
    return { ok: false, reason: err.message };
  }
});

ipcMain.handle('app:info', () => ({
  version: app.getVersion(),
  platform: process.platform,
  hasLibreOffice: false
}));

ipcMain.handle('app:initialPath', (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const p = win && win.ecritoire ? win.ecritoire.initialPath : null;
  if (win && win.ecritoire) win.ecritoire.initialPath = null;
  return p;
});

ipcMain.on('app:state', (e, state) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  if (!win) return;
  win.ecritoire.dirty = !!state.dirty;
  win.setTitle(`${state.dirty ? '• ' : ''}${state.title || 'Untitled'} — ${NAME}`);
  if (isMac) {
    win.setDocumentEdited(!!state.dirty);
    if (state.path) win.setRepresentedFilename(state.path);
  }
});

ipcMain.on('app:close-confirmed', (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  if (!win) return;
  win.ecritoire.forceClose = true;
  win.close();
});

ipcMain.on('app:new-window', () => createWindow());

ipcMain.on('app:paste', (e, plain) => {
  if (plain) e.sender.pasteAndMatchStyle(); else e.sender.paste();
});

/* ------------------------------------------------------------------ */
/* App lifecycle                                                        */
/* ------------------------------------------------------------------ */
function fileFromArgv(argv) {
  return argv.slice(1).find((a) => DOC_EXTS.includes(path.extname(a).toLowerCase()) && fs.existsSync(a)) || null;
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  // A .docx double-clicked while Écritoire is already open opens in a new window
  app.on('second-instance', (_e, argv) => {
    const f = fileFromArgv(argv);
    if (f) createWindow(f);
    else {
      const w = focusedWindow();
      if (w) { if (w.isMinimized()) w.restore(); w.focus(); }
    }
  });

  // macOS: files opened from Finder
  app.on('open-file', (e, p) => {
    e.preventDefault();
    if (app.isReady()) createWindow(p); else pendingOpenPath = p;
  });

  app.whenReady().then(() => {
    buildMenu();
    createWindow(pendingOpenPath || fileFromArgv(process.argv));
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });

  app.on('window-all-closed', () => { if (!isMac) app.quit(); });
}
