# Écritoire on Windows 11

GitHub builds the Windows app on a Windows machine in the cloud, the same way it builds the Android app. You don't need to install anything to build it, and it's free.

**What you get:** a setup wizard for **Windows 11** (Windows 10 works too), like the ones for Word or WPS Office. Windows 11 on ARM laptops run it through Windows' built-in x64 emulation.

## 1. Upload the code

If the repository already has Écritoire from the Android or iOS steps, upload the new files over it. Otherwise follow step 1–2 of [ANDROID.md](ANDROID.md). Upload **everything inside the `ecritoire` folder**, including the hidden `.github` folder.

## 2. Build

1. Repository → **Actions** → **Windows** → **Run workflow** → **Run workflow**.
2. It takes about 5–10 minutes.
3. Open the run, scroll to **Artifacts** and download **`ecritoire-windows-3.4.0`** (a zip). Inside is **`Ecritoire-Setup-3.4.0.exe`**.

## 3. Install

1. Unzip the download and double-click `Ecritoire-Setup-3.4.0.exe`.
2. Windows shows **"Windows protected your PC"** because the app isn't signed with a paid code-signing certificate. Click **More info → Run anyway**. (See the end of this page for how to remove this.)
3. The setup wizard opens:
   - **Welcome**: click Next.
   - **Licence agreement**: read it, choose *I accept* and click Next.
   - **Who to install for**: *Only for me* (no administrator password needed) or *Anyone who uses this computer* (installs in Program Files and asks for administrator permission).
   - **Install location**: keep the suggested folder or choose another, then click **Install**.
   - **Finish**: leave *Run Écritoire* ticked and click Finish.

Écritoire is added to the **Start menu** and the **desktop**, and appears in **Settings › Apps › Installed apps** with its icon, version and publisher (Bluewater 55 Tech).

### Open .docx files with Écritoire

Right-click a `.docx` → **Open with → Écritoire**. To make it the default, choose **Choose another app**, pick Écritoire and click **Always**. Your `.docx` files then show the Écritoire document icon.

## Using it

- The **menu bar** has File, Edit, View, Item, Format and Help, with the usual Windows shortcuts: **Ctrl+N** new, **Ctrl+O** open, **Ctrl+S** save, **Ctrl+Shift+S** save as, **Ctrl+Shift+E** PDF, **Ctrl+P** print, **Ctrl+Z / Ctrl+Y** undo and redo, **Ctrl+F** find. Help › Keyboard Shortcuts lists them all.
- **Save** shows the normal Windows save dialog; new documents start in your **Documents** folder.
- **PDFs** made on Windows have **selectable text** (on phones they are pictures of the pages).
- **Print** opens the normal Windows print dialog.
- Drag a `.docx` onto the window to open it. **Ctrl+Shift+N** opens another window.
- **Recent documents**: right-click Écritoire in the taskbar or Start menu.
- Écritoire remembers its window size and position, and whether it was maximised.
- If you close a window with unsaved changes, Écritoire asks first.

## Updating

Upload the new version's zip to the repository: the **Update from zip** workflow unpacks it and starts the Windows build by itself (see [UPDATING.md](UPDATING.md)). Then run the new setup. It updates the installed version in place; your documents and settings are kept.

## Uninstalling

Settings → **Apps → Installed apps** → Écritoire → **Uninstall**.

## Later: removing the SmartScreen warning

Word and WPS Office install without this message because they are **signed**: Windows can see who published them. Écritoire gets the same when it's signed with a code-signing certificate (bought yearly from a certificate company, or through Microsoft's Azure signing service), or when it's published in the **Microsoft Store**, which signs it for you. Both are only worth it once you share Écritoire with other people.
