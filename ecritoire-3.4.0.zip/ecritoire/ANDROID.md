# Écritoire on your Android phone

GitHub builds the app for you. You don't need Android Studio.

## 1. Put the code on GitHub

1. On GitHub, create a new **private** repository named `ecritoire`.
2. Unzip `ecritoire-3.4.0.zip` and upload **everything inside the `ecritoire` folder**, including the hidden `.github` folder. Easiest way: **Add file → Upload files**, then drag the folder's contents in.

## 2. Add the signing secrets (recommended)

Use the **same three secrets as Lembaran and Un Dessin**: repository → **Settings → Secrets and variables → Actions → New repository secret**.

| Name | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | the same long text as in the Lembaran repo |
| `ANDROID_KEYSTORE_PASSWORD` | the same password |
| `ANDROID_KEY_ALIAS` | `lembaran` (the alias inside your key file; it doesn't need to match the app name) |

Without the secrets the build still works, but only gives you a **test APK**. Pick one kind and stick to it: Android won't update a signed app with a test build (or the other way round) without uninstalling first.

> Never upload the `.jks` key file itself to GitHub. Only the secrets.

## 3. Build

1. Repository → **Actions** tab → **Android** → **Run workflow** → **Run workflow**.
2. Wait about 10 minutes for the green tick.
3. Open the run, scroll to **Artifacts** and download **`ecritoire-android-3.4.0`**.
4. Unzip it. Inside:
   - `Ecritoire-3.4.0.apk`: **install this one** on your phone (signed)
   - `Ecritoire-3.4.0.aab`: for Google Play later (not needed now)
   - `Ecritoire-3.4.0-test.apk`: test build

## 4. Install on your phone

1. Send `Ecritoire-3.4.0.apk` to your phone (Google Drive, email to yourself, or USB cable).
2. Tap the file. Android asks to allow installing apps from that source (Drive, Files, Gmail…): turn on **Allow from this source** and go back.
3. Tap **Install**. If Play Protect says the app is unrecognised, tap **More details → Install anyway**. This is normal for apps that don't come from the Play Store.
4. Écritoire appears in your app drawer with the amber pen-nib icon. It installs **next to** Lembaran; it does not replace it.

Your documents are saved in **Documents › Ecritoire**.

## Updating

Upload the new version's zip to the repository: the **Update from zip** workflow unpacks it and starts the Android build by itself (see [UPDATING.md](UPDATING.md)). Then install the new APK over the old one. Your documents stay where they are.

## Later: Google Play

When you want to sell the paid edition, the `.aab` from the same workflow is what you upload to a **new app** in Play Console (app ID `com.bluesky.ecritoire`). Ask Claude to add the Pro purchase first.

## If the build fails

Open the failed run, click the red step and copy the last 30 lines of the log to Claude.
