# Écritoire Privacy Policy

*Last updated: 15 November 2026*

Écritoire is a document editor for Windows, Android, iPhone and iPad. This policy explains what happens to your information when you use it.

## The short version

**Écritoire does not collect, store, sell or share any personal data.** It has no accounts, no advertising, no analytics and no tracking. Your documents never leave your device unless you choose to share them.

## Your documents

- Documents you open are read only on your device.
- Documents you save are written to your device's storage: on Android in *Documents › Ecritoire*, on iPhone and iPad in *Files › On My iPhone/iPad › Écritoire*; on Windows wherever you choose in the save dialog.
- When you tap **Share**, Écritoire hands the file to the app you pick (for example email, a cloud drive or a messaging app). What happens next is governed by that app's own privacy policy.
- When you **Print**, Écritoire creates a temporary PDF on your device and opens it so you can print it.

## Permissions

| Permission | Why |
|---|---|
| Storage (Android 10 and older only) | To save your documents in the Documents folder. Newer Android versions don't need this permission. |
| Photos and camera (iPhone and iPad, only when you ask) | To insert a picture you choose, or a photo you take, into your document. |
| Internet | Included by the app framework. Écritoire does not send your documents or any data over the internet. |

Écritoire does not use your location, microphone, contacts or any other personal information.

## Children

Écritoire is suitable for all ages and collects no information from anyone, including children.

## Changes

If this policy changes, the new version will be published at this address with a new date.

## Contact

Questions? Email: **YOUR-EMAIL-HERE**
