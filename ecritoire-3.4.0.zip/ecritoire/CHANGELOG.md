# Changelog

## 3.4.0 — 2026-11-16

- **Print Preview.** Print (Ctrl+P, the File tab, or File › Print Preview on Windows) now shows the pages exactly as they will print: headers, footers, page numbers, pictures and wrapped shapes. Zoom in and out, or Fit; two pages side by side on larger screens.
- **Print chosen pages**: **All pages**, **Current page**, or **Pages** such as `1, 2, 6`, `3-5`, `8-` (to the end) or `-3`. Click a page in the preview to add it or leave it out. Pages left out are shown faded, and the summary says what will print. Page numbers in headers and footers stay those of the whole document.
- **Save as PDF** from the preview uses the same page choice.
- On Windows, Print then opens the Windows print dialog for the chosen pages (printer, copies). On phones, Print makes a PDF of the chosen pages and opens it for printing.
- Fixed: after clicking further down in a document with page breaks, the page-break preview could push a paragraph onto a new page, leaving a blank page in print and PDF (the view scrolled while the pages were being measured).

## 3.3.0 — 2026-11-15

- **More colours for shapes.** **Shape Fill** and **Shape Outline** (Shape Format tab, format pane) open the full palette: theme colours with five shades each, standard colours, your **recent colours**, **More Colors…** (the Windows colour dialog in the desktop app, the Android or iPhone picker in the phone apps) and **Pick from Screen** on Windows. Outline weight from 0.5 to 12 px. Font and highlight colours get the same palette.
- **Text wrapping, like Word**, for pictures and shapes: **In Line with Text**, **Square**, **Tight** (text follows a shape's outline), **Top and Bottom**, **Behind Text** and **In Front of Text**, with Left / Center / Right position.
- **Arrange**: **Bring to Front**, **Bring Forward**, **Send Backward**, **Send to Back**, **Bring in Front of Text**, **Send Behind Text**.
- These are under the new **layout options button** beside the selected picture or shape, in the **Shape Format / Picture Format** tab (Wrap Text, Bring Forward, Send Backward) and in the format pane (**Layout**).
- Floating pictures and shapes are **moved by dragging**; free ones (behind or in front of text) go anywhere on the page and move with their paragraph. A picture behind the text is selected by clicking a blank spot over it.
- Saved in `.docx` as Word floating pictures (Word keeps their position, wrapping and order), and Word's floating pictures now open in their place instead of in line. Shapes stay editable after saving and opening a `.docx`.
- PDF and printing on Windows lay out each page as one piece, so text keeps flowing around floating pictures. The page-break preview moves a floating picture to the next page with its paragraph instead of letting it hang over the page gap.
- Fixed: every picture in a saved `.docx` had the same internal id, which Word can report as unreadable content.

## 3.2.0 — 2026-11-15

- **Écritoire for Windows 11.** A desktop app built on GitHub like the phone apps (see WINDOWS.md), with a setup wizard like Word's or WPS Office's:
  - Écritoire-branded welcome and finish pages, a licence agreement, *Only for me* or *Anyone who uses this computer*, a choice of folder, Start menu and desktop shortcuts, and *Run Écritoire* at the end.
  - Listed in Settings › Apps with its icon, version and publisher (Bluewater 55 Tech); a matching uninstaller.
  - `.docx` files opened with Écritoire show an Écritoire document icon.
  - Remembers the window size, position and maximised state; recent documents in the taskbar and Start menu jump list.
  - Menu bar (File, Edit, View, Item, Format, Help) with the usual Ctrl shortcuts, including Freeform drawing, Video and the Item & Layout menu.
  - Windows open, save and print dialogs; new documents are suggested in Documents.
  - `.docx` files open with Écritoire (Open with), by drag-and-drop or from the menu; several windows; a warning before closing with unsaved changes.
  - PDFs are made from the laid-out pages and keep selectable text. Videos appear in PDFs and printouts as their still picture with a play badge.
- The desktop app comes from Lembaran 1.6.0's, without the older .doc format: opening a .doc explains how to convert it.
- **Update from zip.** After this version is on GitHub, a new version is one upload: drop the zip into the repository and the *Update from zip* workflow unpacks it, removes the zip, commits the change and starts the Windows and Android builds (see UPDATING.md).
- Fixed: New Window could open two windows (Ctrl+Shift+N was handled twice).
- The Android, iOS and CI builds skip downloading Electron, so they stay as fast as before.

## 3.1.1 — 2026-11-01

- **Compact layout for phones.** On phones (and short landscape screens such as a Fold opened sideways) the left menu is about half as wide, and its buttons, headings, icons and number boxes are about half the size, so the whole Item section fits on one screen. The title bar, tabs and ribbon are smaller too, which leaves more room for the page. Tablets and computers keep the full size.
- The table picker in the left menu is smaller on phones.
- The empty strip under the ribbon on short landscape screens is gone.

## 3.1.0 — 2026-10-31

- **Left menu for Item and Layout.** Item and Layout are no longer ribbon tabs: they live in a menu on the left with sections you open and close (Item › Document, Illustrations, Media; Layout › Page, Paragraph). On tablets it sits beside the page and can be hidden; on phones it slides in with the **menu button** at the top left and closes after you pick something. The top bar keeps File, Home and View.
- **Freeform shapes.** Item › Freeform (or Shapes › Freeform) opens a drawing box: draw with a finger, pen or mouse, as a filled shape or an open line. It becomes a normal shape you can resize, fill, outline and colour-adjust; saved as a picture in .docx and PDF.
- **Videos in documents.** Item › Video adds an MP4 (or WebM/MOV) video that plays right in the page, with the usual play, pause and seek controls. Resize it like a picture. The video file is saved inside the .docx and comes back when Écritoire opens the file; other editors and PDFs show a still picture with a play button. Videos up to 100 MB.
- Fix: the page count no longer drops by one after saving a PDF.

## 3.0.0 — 2026-10-30

First release of **Écritoire**, the full edition of the Lembaran editor for Android, iPhone and iPad.

- **Everything included:** saving and sharing as .docx and PDF, the four templates (Technical Report, Job Application, Business Letter, Meeting Minutes), cover pages, table of contents, header & footer with page numbers, and footnotes. No purchase and no locked features.
- **iPhone and iPad:** new iOS build (GitHub builds it on a Mac in the cloud and sends it to TestFlight). Saved files appear in the Files app under *On My iPhone › Écritoire*; Print opens the PDF with the iOS share sheet.
- **New name, new logo:** an amber fountain-pen nib writing on a line. App ID `com.bluesky.ecritoire`, so it installs next to Lembaran without replacing it.
- Android files are saved in *Documents › Ecritoire*.
- Phone and tablet only: the Windows, macOS and Linux app, the older .doc format (which needed LibreOffice) and the in-app purchase code are not part of this edition.

Everything else comes from Lembaran 1.6.0: real pages in A4, A5, A3 and Letter (portrait or landscape), fonts and paragraph formatting, lists, tables, pictures with colour correction, 50 shapes, rulers, zoom, find, and the phone clipboard.
