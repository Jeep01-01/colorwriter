<p align="center">
  <img src="build/icon.png" width="96" alt="Écritoire icon">
</p>

<h1 align="center">Écritoire</h1>

<p align="center">
  The full edition of the document editor, for <b>Windows 11</b>, <b>Android</b>, <b>iPhone</b> and <b>iPad</b>.<br>
  Opens <b>.docx</b> · saves to <b>.docx</b> and <b>PDF</b> · templates, cover pages, contents, headers and footnotes.
</p>

*Écritoire* is French for a writing desk.

**Version 3.4.0 · full edition for personal use: every feature is unlocked, nothing to buy.**

---

## Features

| Area | What you get |
|---|---|
| **Files** | New, Open, Save, Save As, Save as PDF, Share and Print. Opens `.docx` from the phone, iCloud Drive or any cloud app, or from any folder on Windows. Saves `.docx` and PDF. |
| **Print Preview** | Print (Ctrl+P) first shows the pages exactly as they print, with headers, footers and page numbers. Print **all pages**, the **current page**, or chosen pages such as `1, 2, 6`, `3-5` or `8-`, or click pages to pick them. **Save as PDF** uses the same choice. On Windows the print dialog then picks the printer and copies; on phones a PDF of those pages opens for printing. |
| **Windows** | Menu bar with the usual shortcuts, Windows open/save/print dialogs, several windows, drag-and-drop, `.docx` files open with Écritoire, and PDFs with selectable text. |
| **Page** | Paper sizes **A4, A5, A3 and Letter** in **portrait or landscape** (Layout › Orientation and Size). **Page break preview** with real page gaps, margin corner marks and page numbers, manual page breaks, margin presets and custom page setup. |
| **Rulers** (tablets) | Horizontal and vertical rulers in centimetres that follow zoom and scrolling. Drag them to change page margins and the current paragraph’s left / first-line / right indents. |
| **Zoom** | 25 %–400 %: pinch to zoom, ribbon buttons, status-bar slider, Page Width and Whole Page. |
| **Font** | Font family (with installed-font detection and live previews), size, grow/shrink, bold, italic, underline, strikethrough, sub/superscript, font color, highlight, clear formatting and a full **Font dialog** (style, color, effects, all/small caps, character spacing, live preview). |
| **Paragraph** | Alignment, indent left/right, first-line & hanging indent, spacing before/after, line spacing (single, 1.15, 1.5, double, multiple, exactly) via the **Paragraph dialog**, Layout tab or ruler. Styles: Normal, Heading 1–3, Quote. |
| **Numbering & points** | Numbering: 1. 2. 3. · a. b. c. · A. B. C. · i. ii. iii. · I. II. III. Bullets: ● ○ ■ – ✓ ➢. Multi-level lists with Tab / Shift+Tab. |
| **Templates** | **Technical Report** (cover, contents, numbered sections, tables, footnotes), **Job Application** (cover, cover letter and CV), **Business Letter** and **Meeting Minutes**. File › Templates. |
| **Left menu** | **Item** and **Layout** are an expandable menu on the left: cover pages, table of contents, header & footer, footnotes, page breaks, pictures, shapes, freeform drawing, tables and videos; margins, orientation, paper size and paragraph spacing. Beside the page on tablets, sliding in on phones. |
| **Video** | Videos (MP4, WebM, MOV, up to 100 MB) play inside the document. Saved inside the .docx; PDFs show a still with a play button. |
| **Document parts** | **Cover pages** in three designs and six colours. A **table of contents** from Heading 1–3 with page numbers that updates by itself. **Header & footer** with left / centre / right text, page numbers and a blank cover page. **Footnotes** at the bottom of their page. All saved as the real thing in `.docx`. |
| **Tables** | Grid picker or dialog, Tab to move between cells (adds a row at the end), insert rows/columns, delete row/column/table, merge & split cells, cell shading, border color. |
| **Pictures** | Insert from file, paste or drag-and-drop. Resize with 8 handles (aspect-ratio lock, Shift to toggle) or exact centimetres. **Color correction**: brightness, contrast, saturation, hue, temperature, grayscale, transparency, plus presets (Grayscale, Sepia, Warm, Cool, Vivid, Washout, Contrast). |
| **Shapes** | **50 shapes** in 7 groups (basic, symbols, arrows, stars, callouts, flowchart, lines), plus **freeform** shapes you draw yourself. Resize like pictures, change shape type, **Shape Fill** and **Shape Outline** (colour and weight) from the full palette: theme colours with shades, standard and recent colours, **More Colors** (the Windows or Android colour picker) and **Pick from Screen** on Windows. Same color adjustments as pictures. |
| **Layout options** | For pictures and shapes, from the button beside the selected object, the Format tab or the format pane: **text wrapping** In Line with Text, Square, Tight, Top and Bottom, Behind Text and In Front of Text, with left/centre/right position; **Bring to Front / Forward, Send Backward / to Back**. Floating objects are moved by dragging. Saved in `.docx` as Word floating pictures, and Word's own floating pictures open in place. |
| **Editing** | Unlimited-feeling undo/redo (150 steps), find, Paste, Copy and Cut with the phone's clipboard (text and pictures), live word and character count. |

What you see is what you save: headers, footers, footnotes and the table of contents become the real thing in `.docx`, colour corrections and shapes are stored as high-resolution pictures, lists keep their numbering style, and every PDF matches the chosen paper size and orientation.

## Install it

GitHub builds the apps for you, so you need neither Android Studio, Visual Studio nor a Mac.

- **Windows 11:** see **[WINDOWS.md](WINDOWS.md)**: run the Windows workflow, download `Ecritoire-Setup-3.4.0.exe` and run the setup.
- **Android:** see **[ANDROID.md](ANDROID.md)**: run the Android workflow, download `Ecritoire-3.4.0.apk` and install it.
- **iPhone and iPad:** see **[IOS.md](IOS.md)**: the iOS workflow sends the app to **TestFlight**, and you install it from there.

**New versions:** upload the zip itself to the repository and the **Update from zip** workflow puts it in place and starts the builds. See **[UPDATING.md](UPDATING.md)**.

Écritoire has its own app ID, `com.bluesky.ecritoire`, so it installs **next to** Lembaran and never replaces it.

## Working on the code

Requirements: **Node.js 22+** and npm.

```bash
npm install
npm test             # unit tests
npm run serve        # builds www/ and shows the editor at http://localhost:8080
npm start            # runs the Windows desktop app (npm run dev opens developer tools)
npm run dist:win     # builds the Windows installer into dist/ (on Windows)
```

Native projects (only if you build on your own computer):

```bash
npm run android:add && npm run android:open    # needs Android Studio and JDK 21
npm run ios:add && npm run ios:open            # needs a Mac with Xcode 26
```

After changing `src/`, run `npm run android:sync` or `npm run ios:sync`.

To change the logo, replace `build/logo.png` (dark rounded tile, transparent corners) and `ios-res/AppIcon-1024.png` (full square), then run `python3 scripts/make-icons.py`.

## Project structure

```
ecritoire/
├── src/
│   ├── index.html          Ribbon UI, workspace, status bar
│   ├── css/app.css         Amber & black theme
│   ├── css/content.css     Document styles shared by the editor and PDF
│   └── js/
│       ├── core.js         Namespace, selection & block helpers
│       ├── history.js      Undo/redo
│       ├── ui.js           Popovers, menus, dialogs, colour palette, toasts
│       ├── layout.js       Zoom, paper size, pages, footnote space, rulers
│       ├── format.js       Font, paragraph, lists, styles + their dialogs
│       ├── objects.js      Pictures & shapes
│       ├── wrap.js         Text wrapping, layering, moving; shape fill and outline
│       ├── printpreview.js Print Preview and choosing pages
│       ├── pagerange.js    Page ranges such as 1, 2, 6 or 3-5
│       ├── tables.js       Tables
│       ├── shapes.js       The 50-shape library (SVG)
│       ├── docx-reader.js  .docx → editor (incl. headers, footnotes, contents)
│       ├── exporter.js     Editor → document model
│       ├── docparts.js     Header & footer, footnotes, table of contents, cover pages
│       ├── leftpane.js     The left menu (Item and Layout)
│       ├── freeform.js     Drawing your own shapes
│       ├── media.js        Videos: insert, play, save in .docx
│       ├── templates.js    The four templates
│       ├── icons.js        UI icon set
│       ├── bridge-mobile.js Files, share, print, clipboard on Android and iOS
│       ├── pdf-export.js   PDF export (html-to-image + pdf-lib)
│       └── app.js          Commands, file handling, status
├── main.js                 Windows desktop app: window, menu bar, dialogs, saving, PDF, printing
├── preload.js              The bridge between the desktop app and the editor
├── lib/docx-writer.js      Document model → .docx
├── build/                  The Écritoire logo (source of all icons), Windows icons, setup artwork and licence
├── ios-res/                iPhone/iPad icon and privacy manifest
├── android-res/            Android launcher icons and splash mark
├── capacitor.config.json   App ID, name, colours
├── scripts/
│   ├── build-web.js        Builds www/ (the editor inside the apps)
│   ├── android-config.py   Icons, splash and settings for the Android project
│   ├── ios-config.py       Icon, splash and settings for the iOS project
│   ├── ios-privacy.rb      Adds the privacy manifest to the Xcode project
│   └── make-icons.py       Makes every icon from build/logo.png
├── test/                   Unit tests
└── .github/workflows/      update.yml (update from zip), windows.yml, android.yml, ios.yml, ci.yml
```

## Later: a paid edition

The code is ready for a purchase check: when a `Lb.pro` module is added, saving as .docx, the templates and the document parts ask it first. Without it (this edition) everything is unlocked.

## Known limitations

- On phones and tablets PDFs are built from page images, so their text isn't selectable (on Windows it is).
- Older `.doc` files can't be opened; save them as `.docx` in another editor first.
- Paper sizes are A4, A5, A3 and Letter; one size applies to the whole document.
- Comments, tracked changes, text boxes and charts inside opened documents are simplified.
- Tight wrapping is saved in `.docx` as square for other editors (Écritoire keeps it tight for its own shapes). Videos stay in line with the text.

## Licence

© 2026 Bluewater 55 Tech. All rights reserved. See [LICENSE](LICENSE) and [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).
