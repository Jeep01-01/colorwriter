'use strict';
const test = require('node:test');
const assert = require('node:assert');
const shapes = require('../src/js/shapes.js');

test('library has exactly 50 shapes with unique ids', () => {
  assert.strictEqual(shapes.list.length, 50);
  assert.strictEqual(new Set(shapes.list.map((s) => s.id)).size, 50);
});

test('every shape renders a sized SVG', () => {
  for (const s of shapes.list) {
    const svg = shapes.svg(s.id, { w: 120, h: 80, fill: '#f59e0b', stroke: '#111111', strokeWidth: 3 });
    assert.match(svg, /^<svg [^>]*width="120" height="80"/, s.id);
    assert.match(svg, /viewBox="/, s.id);
    assert.ok(svg.endsWith('</svg>'), s.id);
    assert.ok(!/NaN|undefined/.test(svg), `${s.id} has invalid numbers`);
  }
});

test('no-fill and no-line options are honoured', () => {
  const svg = shapes.svg('rectangle', { noFill: true, noStroke: true });
  assert.match(svg, /fill="none"/);
  assert.match(svg, /stroke="none"/);
});

test('data URLs are encoded SVG', () => {
  assert.match(shapes.dataUrl('heart', {}), /^data:image\/svg\+xml;charset=utf-8,%3Csvg/);
});
