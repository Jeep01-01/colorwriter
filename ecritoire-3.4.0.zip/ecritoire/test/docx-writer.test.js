'use strict';
const test = require('node:test');
const assert = require('node:assert');
const JSZip = require('jszip');
const { buildDocx } = require('../lib/docx-writer.js');

// 1×1 PNG
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

const model = {
  settings: { margins: { top: 30, right: 30, bottom: 30, left: 40 }, title: 'Test' },
  blocks: [
    { type: 'p', style: 'h1', runs: [{ text: 'Title', b: true, size: 20 }] },
    {
      type: 'p', align: 'justify', lineHeight: 1.5, spacingBefore: 6, spacingAfter: 12, indentLeft: 36, firstLine: -18,
      runs: [
        { text: 'Bold ', b: true }, { text: 'italic ', i: true }, { text: 'under', u: true }, { text: 'strike', s: true },
        { text: 'x', sup: true }, { text: 'y', sub: true }, { text: 'red', color: '#dc2626' },
        { text: 'mark', highlight: '#fde047' }, { text: 'Times', font: 'Times New Roman', size: 14 },
        { tab: true }, { br: true }, { image: { base64: PNG, type: 'png', width: 32, height: 16 } }
      ]
    },
    { type: 'pagebreak' },
    { type: 'p', list: { fmt: 'decimal', level: 0, instance: 1 }, runs: [{ text: 'one' }] },
    { type: 'p', list: { fmt: 'square', level: 1, instance: 2 }, runs: [{ text: 'nested' }] },
    {
      type: 'table', colWidths: [100, 100, 100],
      rows: [
        { cells: [{ blocks: [{ type: 'p', runs: [{ text: 'A' }] }], rowspan: 2, fill: '#fde68a' }, { blocks: [], colspan: 2 }] },
        { cells: [{ blocks: [] }, { blocks: [] }] }
      ]
    }
  ]
};

test('builds a valid .docx with all features', async () => {
  const buf = await buildDocx(model);
  assert.ok(Buffer.isBuffer(buf) && buf.length > 2000);
  const zip = await JSZip.loadAsync(buf);
  const xml = await zip.file('word/document.xml').async('string');
  const expect = [
    '<w:pStyle w:val="Heading1"/>', '<w:jc w:val="both"/>', 'w:line="360"', '<w:b/>', '<w:i/>', '<w:u w:val="single"/>',
    '<w:strike/>', 'w:val="superscript"', 'w:val="subscript"', '<w:color w:val="DC2626"/>', 'w:fill="FDE047"',
    'Times New Roman', '<w:tab/>', '<w:br/>', '<w:drawing>', '<w:pageBreakBefore/>', '<w:numPr>',
    '<w:gridSpan w:val="2"/>', '<w:vMerge w:val="restart"/>', '<w:vMerge w:val="continue"/>', 'w:fill="FDE68A"'
  ];
  for (const e of expect) assert.ok(xml.includes(e), `document.xml should contain ${e}`);
  // A4 page with the requested margins
  assert.match(xml, /<w:pgSz w:w="11906" w:h="16838"/);
  assert.match(xml, /w:left="2268"/); // 40 mm
  const media = Object.keys(zip.files).filter((f) => f.startsWith('word/media/') && !f.endsWith('/'));
  assert.strictEqual(media.length, 1);
});

test('empty documents still produce a valid file', async () => {
  const buf = await buildDocx({ blocks: [] });
  const zip = await JSZip.loadAsync(buf);
  assert.ok(zip.file('word/document.xml'));
});

test('landscape pages keep their orientation', async () => {
  const buf = await buildDocx({ settings: { pageWidthMm: 297, pageHeightMm: 210 }, blocks: [] });
  const zip = await JSZip.loadAsync(buf);
  const xml = await zip.file('word/document.xml').async('string');
  assert.match(xml, /<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/);
});
