'use strict';
// Header & footer, footnotes and table of contents in the .docx writer, and the templates' wiring
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');
const { buildDocx } = require('../lib/docx-writer.js');

const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

async function unzip(model) {
  const zip = await JSZip.loadAsync(await buildDocx(model));
  const get = async (p) => (zip.file(p) ? zip.file(p).async('string') : null);
  return { zip, get };
}

test('header and footer with page numbers, nothing on the cover page', async () => {
  const { zip, get } = await unzip({
    settings: { hf: { header: ['Report', '', 'ACME'], footer: ['', 'Page {page} of {pages}', ''], firstDifferent: true } },
    blocks: [{ type: 'p', runs: [{ text: 'Body' }] }]
  });
  const doc = await get('word/document.xml');
  assert.match(doc, /<w:titlePg\/>/);
  assert.match(doc, /w:headerReference w:type="default"/);
  assert.match(doc, /w:footerReference w:type="first"/);
  const headers = await Promise.all(Object.keys(zip.files).filter((f) => /^word\/header\d+\.xml$/.test(f)).map(get));
  assert.ok(headers.some((x) => x.includes('>Report<') && x.includes('>ACME<')));
  const footers = await Promise.all(Object.keys(zip.files).filter((f) => /^word\/footer\d+\.xml$/.test(f)).map(get));
  const pageFooter = footers.find((x) => x.includes('PAGE'));
  assert.ok(pageFooter, 'footer has a PAGE field');
  assert.match(pageFooter, /NUMPAGES/);
});

test('no header or footer parts when they are empty', async () => {
  const { get } = await unzip({ settings: { hf: { header: ['', '', ''], footer: ['', '', ''] } }, blocks: [{ type: 'p', runs: [{ text: 'x' }] }] });
  const doc = await get('word/document.xml');
  assert.doesNotMatch(doc, /headerReference|footerReference|titlePg/);
});

test('footnotes become real footnotes, numbered in order', async () => {
  const { get } = await unzip({
    blocks: [{ type: 'p', runs: [{ text: 'One' }, { footnote: 'First note' }, { text: ' two' }, { footnote: 'Second note' }] }]
  });
  const doc = await get('word/document.xml');
  assert.match(doc, /w:footnoteReference w:id="1"/);
  assert.match(doc, /w:footnoteReference w:id="2"/);
  const notes = await get('word/footnotes.xml');
  assert.ok(notes.indexOf('First note') > 0 && notes.indexOf('Second note') > notes.indexOf('First note'));
});

test('footnote numbering starts again for every document', async () => {
  const model = { blocks: [{ type: 'p', runs: [{ text: 'a' }, { footnote: 'n' }] }] };
  await buildDocx(model);
  const { get } = await unzip(model);
  assert.match(await get('word/document.xml'), /w:footnoteReference w:id="1"/);
});

test('table of contents: named styles, dot leaders and page numbers', async () => {
  const { get } = await unzip({
    blocks: [{ type: 'toc', title: 'Contents', entries: [{ text: '1 Introduction', level: 1, page: '3' }, { text: '1.1 Scope', level: 2, page: '4' }] }]
  });
  const doc = await get('word/document.xml');
  assert.match(doc, /w:pStyle w:val="TOCHeading"/);
  assert.match(doc, /w:pStyle w:val="TOC1"/);
  assert.match(doc, /w:pStyle w:val="TOC2"/);
  assert.match(doc, /w:leader="dot"/);
  assert.ok(doc.includes('1 Introduction') && doc.includes('>4<'));
  assert.match(await get('word/styles.xml'), /w:name w:val="toc 1"/);
});

test('templates and document parts are loaded, with nothing locked', () => {
  const html = read('src/index.html');
  for (const f of ['js/docparts.js', 'js/templates.js']) assert.ok(html.includes(f), f);
  assert.ok(html.indexOf('js/docparts.js') < html.indexOf('js/templates.js'));
  assert.ok(html.indexOf('js/templates.js') < html.indexOf('js/app.js'));
  for (const c of ['templates', 'coverPage', 'toc', 'headerFooter', 'footnote']) assert.ok(html.includes(`data-cmd="${c}"`), c);
  const tpl = read('src/js/templates.js');
  for (const id of ["id: 'report'", "id: 'job'", "id: 'letter'", "id: 'minutes'"]) assert.ok(tpl.includes(id), id);
  assert.ok(!fs.existsSync(path.join(root, 'src/js/pro.js')), 'this edition has no purchase: everything is unlocked');
  assert.ok(!read('scripts/build-web.js').includes('pro.js'));
});
