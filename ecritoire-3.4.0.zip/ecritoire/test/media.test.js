'use strict';
// Videos in .docx, freeform shapes and the left-pane menu
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');
const { buildDocx } = require('../lib/docx-writer.js');
const Shapes = require('../src/js/shapes.js');

const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

test('a video is stored inside the .docx next to its still picture', async () => {
  const video = Buffer.from('not really a video, just bytes').toString('base64');
  const buf = await buildDocx({
    blocks: [{ type: 'p', runs: [{ image: { base64: PNG, type: 'png', width: 320, height: 180 }, video: { name: 'ecritoire-video1.mp4' } }] }],
    media: [{ name: 'ecritoire-video1.mp4', base64: video, mime: 'video/mp4' }]
  });
  const zip = await JSZip.loadAsync(buf);
  assert.ok(zip.file('word/media/ecritoire-video1.mp4'), 'video file stored');
  assert.strictEqual(await zip.file('word/media/ecritoire-video1.mp4').async('base64'), video);
  assert.match(await zip.file('[Content_Types].xml').async('string'), /Extension="mp4" ContentType="video\/mp4"/);
  assert.match(await zip.file('word/document.xml').async('string'), /descr="ecritoire-video:ecritoire-video1\.mp4"/);
});

test('documents without videos are unchanged', async () => {
  const zip = await JSZip.loadAsync(await buildDocx({ blocks: [{ type: 'p', runs: [{ text: 'x' }] }] }));
  assert.ok(!Object.keys(zip.files).some((f) => /ecritoire-video/.test(f)));
});

test('freeform shapes: smooth closed outline or open line, hidden from the gallery', () => {
  const pts = '0,50;30,0;70,10;100,60;50,100';
  const closed = Shapes.svg('freeform', { w: 200, h: 160, path: pts, closed: true });
  assert.match(closed, /<path d="M0 50Q30 0 50 5/);
  assert.match(closed, /Z"\/>/);
  const open = Shapes.svg('freeform', { w: 200, h: 160, path: pts, closed: false });
  assert.match(open, /fill="none"\/>/);
  assert.ok(!Shapes.list.some((s) => s.id === 'freeform'), 'not in the shape gallery');
  assert.strictEqual(Shapes.list.length, 50);
  assert.deepStrictEqual(Shapes.parsePoints('1,2;bad;3,4'), [[1, 2], [3, 4]]);
});

test('Item and Layout live in the left pane, not in the ribbon', () => {
  const html = read('src/index.html');
  assert.ok(!/data-tab="insert"|data-tab="layout"|data-panel="insert"|data-panel="layout"/.test(html));
  const pane = html.slice(html.indexOf('id="leftPane"'), html.indexOf('id="lpScrim"'));
  for (const c of ['coverPage', 'toc', 'headerFooter', 'footnote', 'pageBreak', 'insertPicture', 'freeform', 'insertVideo', 'pageSetup', 'paragraphDialog']) assert.ok(pane.includes(`data-cmd="${c}"`), c);
  for (const m of ['shapeMenu', 'tableMenu', 'marginMenu', 'orientationMenu', 'paperMenu']) assert.ok(pane.includes(`data-menu="${m}"`), m);
  for (const id of ['lyIndLeft', 'lyIndRight', 'lySpBefore', 'lySpAfter', 'pageSizeLabel']) assert.ok(pane.includes(`id="${id}"`), id);
  assert.match(html, /media-src 'self' data: blob:/, 'videos are allowed to play');
  for (const f of ['js/leftpane.js', 'js/freeform.js', 'js/media.js']) assert.ok(html.indexOf(f) > 0 && html.indexOf(f) < html.indexOf('js/app.js'), f);
});
