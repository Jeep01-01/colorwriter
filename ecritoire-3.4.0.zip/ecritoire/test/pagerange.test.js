'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { parse, format } = require('../src/js/pagerange.js');

test('single pages and ranges', () => {
  assert.deepEqual(parse('1, 2, 6', 8).pages, [1, 2, 6]);
  assert.deepEqual(parse('3-5', 8).pages, [3, 4, 5]);
  assert.deepEqual(parse('1-3, 6', 8).pages, [1, 2, 3, 6]);
  assert.deepEqual(parse('6, 1, 2, 2', 8).pages, [1, 2, 6]);
  assert.deepEqual(parse('1 2;6', 8).pages, [1, 2, 6]);
  assert.deepEqual(parse('2–4', 8).pages, [2, 3, 4]); // en dash
  assert.equal(parse('1, 2, 6', 8).error, null);
});

test('open ranges and reversed ranges', () => {
  assert.deepEqual(parse('6-', 8).pages, [6, 7, 8]);
  assert.deepEqual(parse('-3', 8).pages, [1, 2, 3]);
  assert.deepEqual(parse('5-3', 8).pages, [3, 4, 5]);
});

test('pages outside the document are left out with a note', () => {
  const r = parse('1, 9', 8);
  assert.deepEqual(r.pages, [1]);
  assert.match(r.error, /9/);
  assert.deepEqual(parse('7-12', 8).pages, [7, 8]);
  const none = parse('10-12', 8);
  assert.deepEqual(none.pages, []);
  assert.match(none.error, /pages 1 to 8/);
});

test('mistakes are explained', () => {
  assert.match(parse('', 5).error, /pages to print/);
  assert.match(parse('one', 5).error, /isn’t a page number/);
  assert.match(parse('1-2-3', 5).error, /isn’t a page number/);
  assert.match(parse('-', 5).error, /isn’t a page number/);
});

test('format makes the shortest text', () => {
  assert.equal(format([1, 2, 3, 6]), '1-3, 6');
  assert.equal(format([1, 2, 6]), '1, 2, 6');
  assert.equal(format([6, 2, 1]), '1, 2, 6');
  assert.equal(format([4]), '4');
  assert.equal(format([]), '');
});
