'use strict';
// Text wrapping for pictures and shapes in .docx (3.3.0)
const test = require('node:test');
const assert = require('node:assert');
const JSZip = require('jszip');
const { buildDocx } = require('../lib/docx-writer.js');

const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const img = (extra) => Object.assign({ image: { base64: PNG, type: 'png', width: 100, height: 50 } }, extra);

async function documentXml(runs) {
  const buf = await buildDocx({ settings: { margins: { top: 25.4, right: 25.4, bottom: 25.4, left: 25.4 } }, blocks: [{ type: 'p', runs }] });
  const zip = await JSZip.loadAsync(buf);
  return zip.file('word/document.xml').async('string');
}

test('in-line pictures stay inline', async () => {
  const xml = await documentXml([img(), { text: 'x' }]);
  assert.match(xml, /<wp:inline/);
  assert.doesNotMatch(xml, /<wp:anchor/);
});

test('each wrap mode is written as Word expects', async () => {
  const cases = {
    square: /<wp:wrapSquare wrapText="bothSides"/,
    tight: /<wp:wrapSquare/, // saved as square: Word needs an outline polygon for tight
    topbottom: /<wp:wrapTopAndBottom/,
    behind: /behindDoc="1"[\s\S]*<wp:wrapNone\/>/,
    front: /behindDoc="0"[\s\S]*<wp:wrapNone\/>/
  };
  for (const [wrap, re] of Object.entries(cases)) {
    const xml = await documentXml([img({ float: { wrap, x: 40, y: 10, z: 2 } }), { text: 'x' }]);
    assert.match(xml, re, wrap);
    // measured from the text column and the paragraph, in EMU (1 px = 9525)
    assert.match(xml, /<wp:positionH relativeFrom="column"><wp:posOffset>381000<\/wp:posOffset>/, wrap);
    assert.match(xml, /<wp:positionV relativeFrom="paragraph"><wp:posOffset>95250<\/wp:posOffset>/, wrap);
  }
});

test('behind-text objects layer below in-front objects', async () => {
  const xml = await documentXml([img({ float: { wrap: 'behind', x: 0, y: 0, z: 3 } }), img({ float: { wrap: 'front', x: 0, y: 0, z: 1 } })]);
  const heights = [...xml.matchAll(/relativeHeight="(\d+)"/g)].map((m) => +m[1]);
  assert.equal(heights.length, 2);
  assert.ok(heights[0] < heights[1]);
});

test('every picture gets its own drawing id', async () => {
  const xml = await documentXml([img(), img({ float: { wrap: 'square', x: 0, y: 0 } }), img({ float: { wrap: 'front', x: 0, y: 0 } })]);
  const ids = [...xml.matchAll(/<wp:docPr id="(\d+)"/g)].map((m) => m[1]);
  assert.deepEqual(ids, ['1', '2', '3']);
});

test('a shape keeps its settings in the description', async () => {
  const shape = { shape: 'heart', fill: '#ff0000', stroke: '#000000', sw: '3', tight: '1' };
  const xml = await documentXml([img({ shape, float: { wrap: 'tight', x: 0, y: 0 } })]);
  const m = /descr="ecritoire-shape:([A-Za-z0-9+/=]+)"/.exec(xml);
  assert.ok(m, 'description present');
  assert.deepEqual(JSON.parse(Buffer.from(m[1], 'base64').toString('utf8')), shape);
});
