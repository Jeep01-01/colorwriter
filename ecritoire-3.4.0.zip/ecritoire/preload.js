'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');

/**
 * The only bridge between the editor (renderer) and the system in the desktop
 * app. Exposed as window.ecritoire, the same API bridge-mobile.js gives the
 * phone and tablet apps.
 */
contextBridge.exposeInMainWorld('ecritoire', {
  platform: 'desktop',
  openDialog: () => ipcRenderer.invoke('dialog:open'),
  openPath: (p) => ipcRenderer.invoke('file:openPath', p),
  saveDialog: (opts) => ipcRenderer.invoke('dialog:save', opts),
  save: (req) => ipcRenderer.invoke('file:save', req),
  print: (req) => ipcRenderer.invoke('file:print', req),
  info: () => ipcRenderer.invoke('app:info'),
  initialPath: () => ipcRenderer.invoke('app:initialPath'),
  setState: (state) => ipcRenderer.send('app:state', state),
  confirmClose: () => ipcRenderer.send('app:close-confirmed'),
  newWindow: () => ipcRenderer.send('app:new-window'),
  paste: (plain) => ipcRenderer.send('app:paste', !!plain),
  pathForFile: (file) => { try { return webUtils.getPathForFile(file); } catch (_) { return null; } },
  onCommand: (cb) => ipcRenderer.on('menu:command', (_e, cmd, arg) => cb(cmd, arg)),
  onRequestClose: (cb) => ipcRenderer.on('app:request-close', () => cb())
});
