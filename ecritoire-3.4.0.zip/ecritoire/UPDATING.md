# Updating Écritoire on GitHub with just the zip

Once this version is on GitHub, a new version is one upload: the **Update from zip** workflow unpacks the zip into the repository, deletes the zip, saves the change as "Update to Écritoire x.y.z" and starts the Windows and Android builds.

## One time: put this version on GitHub

The workflow has to be in the repository before it can work, so this first time upload the files the usual way (see [ANDROID.md](ANDROID.md), step 2): unzip, show hidden files, and upload **everything inside the `ecritoire` folder**, including `.github`.

Check that **Actions** now lists **Update from zip** next to Windows, Android, iOS and CI.

## Every update after that

1. On GitHub, open the repository's main page.
2. **Add file → Upload files**, drag in the zip as it is (for example `ecritoire-3.2.1.zip`), and click **Commit changes**.
3. Open the **Actions** tab. **Update from zip** runs for about half a minute, then **Windows** and **Android** start by themselves (and **iOS**, once its signing secrets are set up).
4. When they finish, download the new installer and APK from those runs as usual.

The run's summary (click the run) shows the new version and which builds were started.

Good to know:
- **Don't unzip it.** Upload the `.zip` file itself.
- **The repository becomes exactly what's in the zip.** Files that a new version no longer has are removed. Your secrets (signing keys, passwords) are kept in Settings, not in the files, so they are never touched.
- **A wrong zip changes nothing.** If the zip isn't an Écritoire project, the run stops with an error and the repository stays as it was. Delete the zip from the repository afterwards.
- **To run it again** without uploading: Actions → Update from zip → Run workflow.
- **Older versions are still there.** Every update is saved in the repository's history (the clock icon, *Commits*), so you can always go back.

## When a version changes the build workflows

GitHub doesn't let a workflow change the files in `.github/workflows` (the build instructions themselves) with its built-in permission. If a new zip changes one of them, the update still goes ahead for everything else, and the run's summary shows **"Upload these files by hand"** with the list. Upload those files into the `.github/workflows` folder (open that folder on GitHub, then **Add file → Upload files**), and run the builds again.

This is rare. To make even these automatic, give the workflow its own key, once:

1. GitHub → your picture (top right) → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**.
2. Name: `Ecritoire update`. Expiration: your choice (for example one year). **Repository access:** *Only select repositories* → your Écritoire repository.
3. **Permissions → Repository permissions:** **Contents: Read and write** and **Workflows: Read and write**.
4. **Generate token** and copy it (GitHub shows it only once).
5. In the repository: **Settings → Secrets and variables → Actions → New repository secret**. Name: `UPDATE_TOKEN`, value: the token. **Add secret**.

When the token expires, updates stop with an error: generate a new one and replace the secret's value, or delete the secret to go back to uploading workflow files by hand.
