# Third-party software in Écritoire

Écritoire's own code (the editor, the templates, the cover-page artwork, the
shapes, the icons, the .docx reader and the build scripts) was written for it.
It does not copy code from other projects.

Écritoire uses these open-source libraries unchanged. Their licences allow use
in free and paid apps; each licence asks that its notice is kept, which this
file does.

| Library | Used for | Licence | Source |
|---|---|---|---|
| [docx](https://github.com/dolanmiu/docx) | Writing .docx files | MIT | github.com/dolanmiu/docx |
| [JSZip](https://github.com/Stuk/jszip) | Reading .docx files (zip) | MIT (dual-licensed MIT or GPL-3.0; Écritoire uses it under MIT) | github.com/Stuk/jszip |
| [html-to-image](https://github.com/bubkoo/html-to-image) | PDF export | MIT | github.com/bubkoo/html-to-image |
| [pdf-lib](https://github.com/Hopding/pdf-lib) | Building PDF files | MIT | github.com/Hopding/pdf-lib |
| [Electron](https://github.com/electron/electron) | The Windows app | MIT | github.com/electron/electron |
| [Capacitor](https://github.com/ionic-team/capacitor) (Android and iOS) and its App, Clipboard, Filesystem and Share plugins | The Android and iPhone/iPad app | MIT | github.com/ionic-team/capacitor, github.com/ionic-team/capacitor-plugins |
| [Capawesome File Opener](https://github.com/capawesome-team/capacitor-plugins) | Opening PDFs for printing | MIT | github.com/capawesome-team/capacitor-plugins |

**Build tools** such as the Capacitor CLI (MIT), electron-builder (MIT), Pillow (HPND) and the
xcodeproj gem (MIT) are used only to make the apps and are not part of them.

The full licence texts are included with each library in `node_modules/` when
the project is built.
